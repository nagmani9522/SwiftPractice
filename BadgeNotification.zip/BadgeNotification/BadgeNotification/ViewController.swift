//
//  ViewController.swift
//  BadgeNotification
//
//  Created by mac on 29/11/21.
//

import UIKit
import UserNotifications
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.badgeNotification()
    }
    func badgeNotification(){
        let notificationNumber:Int = 12
        let application = UIApplication.shared
        let notificationCenter = UNUserNotificationCenter.current()
        notificationCenter.requestAuthorization(options: [.badge,.alert,.sound]){(success,error) in
            if error == nil{
                print("successNotification")
            }
        }
        application.applicationIconBadgeNumber = notificationNumber
        application.registerForRemoteNotifications()
    }

}

