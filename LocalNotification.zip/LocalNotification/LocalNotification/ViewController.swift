//
//  ViewController.swift
//  LocalNotification
//
//  Created by mac on 30/11/21.
//

import UIKit
import UserNotifications
class ViewController: UIViewController,UNUserNotificationCenterDelegate{
    let userNotificationCenter = UNUserNotificationCenter.current()
    var badgeNumber = 0
    override func viewDidLoad() {
        super.viewDidLoad()
       // UIApplication.shared.applicationIconBadgeNumber = 0

        userNotificationCenter.delegate = self
//        userNotificationCenter.requestAuthorization(options: [.badge,.alert,.sound]){(success,error) in
//            if error == nil{
//                print("Authorization Success")
//            }
//        }
        
    }

    @IBAction func btnLocalNotificationCenter(_ sender: UIButton) {
        badgeNumber = badgeNumber + 1
       // badgeNumber += 1
        let content = UNMutableNotificationContent()
        content.categoryIdentifier = "localNotification"
        content.title = "Local Notification"
        content.badge = NSInteger(badgeNumber) as NSNumber
       // content.sound = UNNotificationSound.default
        content.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: "Untitled.caf"))
        content.userInfo = ["name":"Nagmani","email":"abc@gmail.com"]
        //Content Image
        let url = Bundle.main.url(forResource: "cat", withExtension: "jpeg")
        let attachement = try! UNNotificationAttachment.init(identifier: "image", url: url!, options: [:])
        content.attachments = [attachement]
       // Trigger Time
        let trigger = UNTimeIntervalNotificationTrigger.init(timeInterval: 5, repeats: false) // for timming
        let identifire = "Local Identifire"
        let request = UNNotificationRequest.init(identifier: identifire, content: content, trigger: trigger)
        userNotificationCenter.add(request){(error) in
            print(error?.localizedDescription ?? "")
            //MARK: notification Action
            let like = UNNotificationAction.init(identifier: "Like", title: "Like", options: .foreground)
            let delete = UNNotificationAction.init(identifier: "Delete", title: "Delete", options: .destructive)
            let category = UNNotificationCategory.init(identifier: content.categoryIdentifier, actions: [like,delete], intentIdentifiers: [], options: [])
            self.userNotificationCenter.setNotificationCategories([category])
        }
    }
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.alert,.badge,.sound])
    }
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        if let dict = response.notification.request.content.userInfo as? [AnyHashable: Any]{
        secondVC.strText = dict["name"] as! String
    }
        self.navigationController?.pushViewController(secondVC, animated: true)
    }
}

