//
//  SecondViewController.swift
//  ApplicationAndVuewControllerLifeCycle
//
//  Created by mac on 31/10/21.
//

import UIKit
class SecondViewController: UIViewController {

    @IBOutlet weak var lbl1: UILabel!
    @IBOutlet weak var lbl2: UILabel!
    var txtname:String! = nil
    var txtname2:String! = nil
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }
    

    override func viewWillAppear(_ animated: Bool) {
        print("s1 viewWillAppear")
        lbl1.text = txtname
    }
    override func viewWillDisappear(_ animated: Bool) {
        print("s3 viewWillDisappear")
    }
    override func viewDidAppear(_ animated: Bool) {
        print("s2 viewDidAppear")
        lbl2.text = txtname2
    }
    override func viewDidDisappear(_ animated: Bool) {
        print("s4 viewDidDisappear")
    }
    @IBAction func btn(_ sender: UIButton) {
        let vc1:ViewController = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        
        //self.navigationController?.pushViewController(vc1, animated: true)
        self.navigationController?.popViewController(animated: true)

    }
}
