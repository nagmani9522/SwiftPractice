//
//  ViewController.swift
//  ApplicationAndVuewControllerLifeCycle
//
//  Created by mac on 31/10/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ftxt: UITextField!
    @IBOutlet weak var ftxt1: UITextField!
    fileprivate let application = UIApplication.shared
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        print("f1 viewWillAppear")
        ftxt.text = "viewWillAppear"
    }
    override func viewWillDisappear(_ animated: Bool) {
        print("f3 viewWillDisappear")
    }
    override func viewDidAppear(_ animated: Bool) {
        print("f2 viewDidAppear")
        ftxt1.text = "view"
//        let vc:SecondViewController = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
//        SecondViewController.self
//        vc.txtname = ftxt.text
//        vc.txtname2 = ftxt1.text
//        self.navigationController?.pushViewController(vc, animated: true)
    }
    override func viewDidDisappear(_ animated: Bool) {
        print("f4 viewDidDisappear")
    }
    
    @IBAction func save(_ sender: UIButton) {
        let vc:SecondViewController = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        SecondViewController.self
        vc.txtname = ftxt.text
        vc.txtname2 = ftxt1.text
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

