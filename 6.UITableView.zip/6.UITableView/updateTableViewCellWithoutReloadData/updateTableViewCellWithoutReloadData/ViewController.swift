//
//  ViewController.swift
//  updateTableViewCellWithoutReloadData
//
//  Created by mac on 02/11/21.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var tableView: UITableView!
    var arrData = [String]()
    var index = IndexPath()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        arrData = ["lbl1","lbl2","lbl3","lbl4","lbl5","lbl6","lbl7","lbl8"]
        
    }
    
    @IBAction func btnUpdate(_ sender: UIButton) {
        if index != []{
            print(index.row)
            if let cell = tableView.cellForRow(at: index){
                cell.textLabel?.text = txtName.text
            }
        }
    }
    @IBAction func editingChange(_ sender: UITextField) {
        if index != []{
            if let cell = tableView.cellForRow(at: index){
                cell.textLabel?.text = txtName.text
                cell.backgroundColor = .red
            }
        }
    }
}
extension ViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell",for: indexPath)
        if cell != nil{
            cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        }
        cell.textLabel?.text = arrData[indexPath.row]
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        index = indexPath
        txtName.text = arrData[indexPath.row]
    }
    
}
