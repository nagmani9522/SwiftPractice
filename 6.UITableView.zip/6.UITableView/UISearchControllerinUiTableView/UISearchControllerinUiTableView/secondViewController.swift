//
//  secondViewController.swift
//  UISearchControllerinUiTableView
//  Created by mac on 01/11/21.
//

import UIKit

class secondViewController: UIViewController,UISearchBarDelegate,UISearchControllerDelegate {
    struct DataModel {
        var fname:String = ""
        var lname:String = ""
    }
    let searchController = UISearchController(searchResultsController: nil)
    var arrData = [DataModel]()
    var tableVIew:UITableView = UITableView()
    
    @IBOutlet weak var searchText: UISearchBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let mainScreen = UIScreen.main.bounds
        let screenWidth = mainScreen.width
        let screenHeight = mainScreen.height
        self.getData()
        tableVIew.frame = CGRect(x: 0, y: 200, width: screenWidth, height: screenHeight)
        tableVIew.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        view.addSubview(tableVIew)
        tableVIew.dataSource = self
        tableVIew.delegate = self
       // self.tableVIew.backgroundColor = #colorLiteral(red: 0.8901960784, green: 0.01568627451, blue: 0.4196078431, alpha: 1)
        searchBarSetup()
        searchText.searchTextField.autocapitalizationType = .none
        
        // Do any additional setup after loading the view.
        searchText.autocapitalizationType = .none
    }
    //MARK: SearchBarCode
    private func searchBarSetup(){
        searchController.searchResultsUpdater = self
        searchController.searchBar.delegate = self
        navigationItem.searchController = searchController
        
    }
    func getData() {
     arrData = [DataModel(fname: "Yogesh", lname: "Patel"),
                DataModel(fname: "rahul", lname: "Patel"),
                DataModel(fname: "ram", lname: "kumar"),
                DataModel(fname: "subham", lname: "mishra"),
                DataModel(fname: "Yogesh", lname: "Patel"),
                DataModel(fname: "rahul", lname: "Patel"),
                DataModel(fname: "ram", lname: "kumar"),
                DataModel(fname: "subham", lname: "mishra"),
                DataModel(fname: "Yigesh", lname: "mishra")]
    }
}
extension secondViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell.init(style: .value2, reuseIdentifier: "cell")
        cell.textLabel?.text = arrData[indexPath.row].fname
        cell.detailTextLabel?.text = arrData[indexPath.row].lname
        
        return cell
    }
    
    
}
extension secondViewController: UISearchResultsUpdating{
    func updateSearchResults(for searchController: UISearchController) {
        searchController.searchBar.autocapitalizationType = .none
        guard let searchTexts = searchController.searchBar.text else{return}
        if searchTexts == ""{
            getData()
        }else{
            //searchTexts.capitalized(with: .none)
            //searchTextField.autocapitalizationType = .none
            getData()
            arrData = arrData.filter{
                $0.fname.contains(searchTexts)
            }
        }
        tableVIew.reloadData()
    }
    
    
}
