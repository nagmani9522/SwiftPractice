//
//  CodingViewController.swift
//  pullToRefreshTableView
//
//  Created by mac on 02/11/21.
//

import UIKit

class CodingViewController: UIViewController,UITableViewDataSource {
 var arrData = [String]()
    @IBOutlet weak var tableVIew: UITableView!
    var refreshController = UIRefreshControl()
    override func viewDidLoad() {
        super.viewDidLoad()
        tableVIew.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        refreshController.attributedTitle = NSAttributedString(string: "Loding...")
        refreshController.addTarget(self, action: #selector(pullToRefresh(sender: )), for: .valueChanged)
        tableVIew.refreshControl = refreshController
    
        // Do any additional setup after loading the view.
    }
    @objc func pullToRefresh(sender: UIRefreshControl){
        let Element = arrData.count
        arrData.append("Element\(Element)")
        refreshController.endRefreshing()
        tableVIew.reloadData()
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return arrData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let  cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = arrData[indexPath.row]
        return cell!
    }
}
