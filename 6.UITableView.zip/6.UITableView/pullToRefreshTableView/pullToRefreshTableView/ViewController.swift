//
//  ViewController.swift
//  pullToRefreshTableView
//
//  Created by mac on 02/11/21.
//

import UIKit

class ViewController: UITableViewController {
var arrData = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
    }

    @IBAction func refreshAction(_ sender: UIRefreshControl) {
        let Element = arrData.count
        arrData.append("Element\(Element)")
        sender.endRefreshing()
        tableView.reloadData()
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        arrData.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        cell.textLabel?.text = arrData[indexPath.row]
        return cell
    }
}

