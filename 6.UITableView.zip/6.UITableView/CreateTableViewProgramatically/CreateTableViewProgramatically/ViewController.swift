//
//  ViewController.swift
//  CreateTableViewProgramatically
//
//  Created by mac on 01/11/21.
//

import UIKit

class ViewController: UIViewController,UITabBarDelegate, UITableViewDelegate,UITableViewDataSource {
    
    var tblView: UITableView = UITableView()
    var arrData = ["One","Two","Three"]
    var arrData2 = ["Hi","Hello","how"]
    override func viewDidLoad() {
        super.viewDidLoad()
        let mainScreen = UIScreen.main.bounds
        let screenWidth = mainScreen.width
        let screenHeight = mainScreen.height
        tblView.frame = CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight)
        tblView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        tblView.dataSource = self
        tblView.delegate = self
        view.addSubview(tblView)
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell:UITableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell")!
        if cell != nil{
            cell = UITableViewCell(style: .value2, reuseIdentifier: "cell")
        }
        cell.textLabel?.text = arrData[indexPath.row]
        cell.detailTextLabel?.text = arrData2[indexPath.row]
        return cell
    }
    
    @IBAction func didTapView(_ sender: UITapGestureRecognizer) {
        print("did tap view", sender)
    }

}

