//
//  ViewController.swift
//  implementMultipleTableViewOnSingleVC
//
//  Created by mac on 02/11/21.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var segmentTxt: UISegmentedControl!
    @IBOutlet weak var tableVIew: UITableView!
    var ahData = [ahemdabad]()
    var mData = [mumbai]()
    var bData = [banglore]()
    var pData = [pune]()
    override func viewDidLoad() {
        super.viewDidLoad()
        tableVIew.delegate = self
        tableVIew.dataSource = self
        getDataModel()
        // Do any additional setup after loading the view.
    }
    func getDataModel(){
        ahData = [ahemdabad(city: "City :- Ahmedabad", img:#imageLiteral(resourceName: "skype"), title: "Navratri"),
                  ahemdabad(city: "City :- Ahmedabad", img:#imageLiteral(resourceName: "message"), title: "Rann Utsav"),
                  ahemdabad(city: "City :- Ahmedabad", img:#imageLiteral(resourceName: "outlook"), title: "samlija Mehola"),
                  ahemdabad(city: "City :- Ahmedabad", img:#imageLiteral(resourceName: "twitter"), title: "International Kit"),
                  ahemdabad(city: "City :- Ahmedabad", img:#imageLiteral(resourceName: "skype"), title: "Navratri"),
                  ahemdabad(city: "City :- Ahmedabad", img:#imageLiteral(resourceName: "message"), title: "Rann Utsav"),
                  ahemdabad(city: "City :- Ahmedabad", img:#imageLiteral(resourceName: "outlook"), title: "samlija Mehola"),
                  ahemdabad(city: "City :- Ahmedabad", img:#imageLiteral(resourceName: "twitter"), title: "International Kit")
        ]
        mData = [mumbai(city: "City :- Mumbai", img:#imageLiteral(resourceName: "twitter"), title: "Mumbai -Navratri"),
                 mumbai(city: "City :- Mumbai", img:#imageLiteral(resourceName: "26"), title: "Mumbai -Rann Utsav"),
                 mumbai(city: "City :- Mumbai", img:#imageLiteral(resourceName: "whatsapp"), title: "Mumbai -samlija Mehola"),
                 mumbai(city: "City :- Mumbai", img:#imageLiteral(resourceName: "outlook"), title: "Mumbai -International Kit")
        ]
        bData = [banglore(city: "City :- Banglore", img:#imageLiteral(resourceName: "fbMessenger"), title: "Banglore -Navratri"),
                 banglore(city: "City :- Banglore", img:#imageLiteral(resourceName: "gmail"), title: "Banglore -Rann Utsav"),
                 banglore(city: "City :- Banglore", img:#imageLiteral(resourceName: "instagram"), title: "Banglore -samlija Mehola"),
                 banglore(city: "City :- Banglore", img:#imageLiteral(resourceName: "fbMessenger"), title: "Banglore -International Kit")
        ]
        pData = [pune(city: "City :- Pune", img:#imageLiteral(resourceName: "fbMessenger"), title: "Pune -Navratri"),
                 pune(city: "City :- Pune", img:#imageLiteral(resourceName: "gmail"), title: "Pune -Rann Utsav"),
                 pune(city: "City :- Pune", img:#imageLiteral(resourceName: "mail"), title: "Pune -samlija Mehola"),
                 pune(city: "City :- Pune", img:#imageLiteral(resourceName: "fbMessenger"), title: "Pune -International Kit")
        ]
    }
    
    @IBAction func segmentActionBtn(_ sender: UISegmentedControl) {
        tableVIew.reloadData()
    }
}
extension ViewController:UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var value = 0
        switch segmentTxt.selectedSegmentIndex {
        case 0:
            value = ahData.count
            break
        case 1:
            value = mData.count
            break
        case 2:
            value = bData.count
            break
        case 3:
            value = pData.count
            break
        default:
            break
        }
        return value
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: FirstTableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell") as! FirstTableViewCell
        switch segmentTxt.selectedSegmentIndex {
        case 0:
            cell.ahModel = ahData[indexPath.row]
            break
        case 1:
            cell.mhModel = mData[indexPath.row]
            break
        case 2:
            cell.bhModel = bData[indexPath.row]
            break
        case 3:
            cell.lbl1.text = pData[indexPath.row].city
            cell.lbl2.text = pData[indexPath.row].title
            cell.img.image = pData[indexPath.row].img
            break
        default:
            break
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if (segmentTxt.selectedSegmentIndex == 0){
            print("0\(indexPath.row)")
        }
        else if segmentTxt.selectedSegmentIndex == 1{
            print("1\(indexPath.row)")
        }
        else if segmentTxt.selectedSegmentIndex == 2{
            print("2\(indexPath.row)")
        }
        else if segmentTxt.selectedSegmentIndex == 3{
            print("3\(indexPath.row)")
        }
    }
    
}
