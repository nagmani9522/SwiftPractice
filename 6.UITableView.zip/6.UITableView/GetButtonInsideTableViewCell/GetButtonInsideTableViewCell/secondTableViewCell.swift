//
//  secondTableViewCell.swift
//  GetButtonInsideTableViewCell
//
//  Created by mac on 02/11/21.
import UIKit
//protocol secondCelldelegate: AnyObject {
//    func secondcellBtnTapped(tag: Int)
//}
class secondTableViewCell: UITableViewCell {
    @IBOutlet weak var btn: UIButton!
    var index = IndexPath()
    //weak var delegate: secondCelldelegate?
    //MARK: Clouser
    //var tapBlock: (() -> Void)? = nil
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
//    @IBAction func btnCellTapped(_ sender: UIButton) {        //tapBlock?()
    
    //        //delegate?.secondcellBtnTapped(tag: sender.tag)
//    }
    
}
