//
//  secondViewcontroller.swift
//  GetButtonInsideTableViewCell
//
//  Created by mac on 02/11/21.
//
import UIKit

class secondViewController: UIViewController{
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.dataSource = self
        
    }
}
extension secondViewController: UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        20
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? secondTableViewCell
//        cell?.tapBlock = {
//            cell?.backgroundColor = .red
//        }
        //cell?.delegate = self
         cell?.btn.tag = indexPath.row
        cell?.btn.addTarget(self, action: #selector(cellBtnTapped(sender: )), for: .touchUpInside)
        cell?.btn.setTitle("\(indexPath.row)", for: .normal)
        return cell!
    }
    @objc func cellBtnTapped(sender: UIButton){
        let cell = tableView.cellForRow(at: IndexPath(row: sender.tag, section: 0))
        cell?.backgroundColor = .red
        
    }
}
//extension fsecondtViewController: secondCelldelegate{
//    func firstcellBtnTapped(tag: Int) {
//        if let cell = tableView.cellForRow(at: IndexPath(row: tag, section: 0)){
//            cell.backgroundColor = .red
//        }
//    }
//}

