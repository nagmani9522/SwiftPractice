//
//  firstTableViewCell.swift
//  GetButtonInsideTableViewCell
//
//  Created by mac on 02/11/21.
//
import UIKit
//protocol firstCelldelegate: AnyObject {
//    func firstcellBtnTapped(tag: Int)
//}
class firstTableViewCell: UITableViewCell {
var index = IndexPath()
    @IBOutlet weak var btn: UIButton!
    //MARK: Clouser
    var tapBlock: (() -> Void)? = nil
    //weak var delegate: firstCelldelegate?
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBAction func btnCellTapped(_ sender: UIButton) {
        tapBlock?()
        //delegate?.firstcellBtnTapped(tag: sender.tag)
    }
    
}
