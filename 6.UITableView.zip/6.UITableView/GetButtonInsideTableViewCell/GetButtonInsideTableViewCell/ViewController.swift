//
//  ViewController.swift
//  GetButtonInsideTableViewCell
//
//  Created by mac on 02/11/21.
//

import UIKit
class ViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.dataSource = self
    }

}
extension ViewController: UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        20
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? TableViewCell
        cell?.delegate = self
        cell?.btn.tag = indexPath.row
        cell?.btn.setTitle("\(indexPath.row)", for: .normal)
        return cell!
    }
    
}
extension ViewController: Celldelegate{
    func cellBtnTapped(tag: Int) {
        print(tag)
        if let cell = tableView.cellForRow(at: IndexPath(row: tag, section: 0)){
            cell.backgroundColor = .red
        }
    }
}
