//
//  firstViewController.swift
//  GetButtonInsideTableViewCell
//
//  Created by mac on 02/11/21.
//
import UIKit

class firstViewController: UIViewController{
    var arr = ["a","b","q","e","r","t","y","u","i","o","p","k"]
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.dataSource = self
    }
    
}
extension firstViewController: UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        20
        //return arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? firstTableViewCell
        cell?.tapBlock = {
            print(indexPath.row)
            //print(self.arr[indexPath.row])
            //cell?.backgroundColor = .red
        }
        //cell?.delegate = self
        // cell?.btn.tag = indexPath.row
        cell?.btn.setTitle("\(indexPath.row)", for: .normal)
        //cell?.btn.setTitle("\(arr[indexPath.row])", for: .normal)
        return cell!
    }
    
}
//extension firstViewController: firstCelldelegate{
//    func firstcellBtnTapped(tag: Int) {
//        if let cell = tableView.cellForRow(at: IndexPath(row: tag, section: 0)){
//            cell.backgroundColor = .red
//        }
//    }
//}
