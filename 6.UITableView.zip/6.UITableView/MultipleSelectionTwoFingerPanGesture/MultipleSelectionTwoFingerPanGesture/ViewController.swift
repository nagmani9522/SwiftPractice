//
//  ViewController.swift
//  MultipleSelectionTwoFingerPanGesture
//
//  Created by mac on 03/11/21.
//

import UIKit
struct TechModel {
    let name:String
    var isSelected:Bool
}
class ViewController: UIViewController {
    var arrData = [TechModel]()
    @IBOutlet weak var tblView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        getData()
        self.tblView.isEditing = true
        self.tblView.allowsMultipleSelectionDuringEditing = true
        // Do any additional setup after loading the view.
    }

    func getData(){
        arrData = [TechModel(name: "ios", isSelected: false),
                   TechModel(name: "Android", isSelected: false),
                   TechModel(name: "ReactJs", isSelected: false),
                   TechModel(name: "HTML", isSelected: false),
                   TechModel(name: "ios", isSelected: false),
                   TechModel(name: "Rubby", isSelected: false),
                   TechModel(name: "Kotline", isSelected: false),
                   TechModel(name: "WordPress", isSelected: false)
        ]
    }
    
    @IBAction func btnDoneTapped(_ sender: UIBarButtonItem) {
        tblView.setEditing(false, animated: true)
        debugPrint(arrData.filter{
                    $0.isSelected == true
        })
    }
}
extension ViewController: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell",for: indexPath)
        cell.textLabel?.text = arrData[indexPath.row].name
        //cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, shouldBeginMultipleSelectionInteractionAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, didBeginMultipleSelectionInteractionAt indexPath: IndexPath) {
        tableView.setEditing(true, animated: true)
    }
    func tableViewDidEndMultipleSelectionInteraction(_ tableView: UITableView) {
        print("\(#function)")
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       if arrData[indexPath.row].isSelected{
        return
        }
        let cell = tableView.cellForRow(at: indexPath)
        //cell?.selectionStyle = .none
        cell!.backgroundColor = .red
        arrData[indexPath.row].isSelected.toggle()
    }
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        //tableView.isEditing = true
//        if tableView.isEditing{
//
//        }
//        else{
//
//        }
        if !arrData[indexPath.row].isSelected{
            return
        }
        let cell = tableView.cellForRow(at: indexPath)
        cell?.backgroundColor = .green
        arrData[indexPath.row].isSelected.toggle()
    }
}
