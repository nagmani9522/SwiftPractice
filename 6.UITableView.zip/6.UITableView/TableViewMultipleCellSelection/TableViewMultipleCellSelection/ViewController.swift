//
//  ViewController.swift
//  TableViewMultipleCellSelection
//
//  Created by mac on 01/11/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var tableview: UITableView!
    var arrData = [String]()
    var SelectarrData = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
//        tableview.dataSource = self
//        tableview.delegate = self
//        view.addSubview(tableview)
        self.getData()
        tableview.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        self.tableview.isEditing = true
        self.tableview.allowsMultipleSelectionDuringEditing = true
    }
    func getData(){
        arrData = ["Hello 1","Hello 2","Hello 3","Hello 4","Hello 5","Hello 6","Hello 7","Hello 8","Hello 9","Hello 10"]
    }

    @IBAction func multipleSelection(_ sender: UIButton) {
        if sender.isSelected == false{
            for row in 0...arrData.count{
                self.tableview.selectRow(at: IndexPath(row: row, section: 0), animated: false, scrollPosition: .none)
            }
            
            sender.isSelected = true
            SelectarrData = arrData
        }
        else{
            for row in 0...arrData.count{
                self.tableview.deselectRow(at: IndexPath(row: row, section: 0), animated: false)
            }
            
            sender.isSelected = false
            self.SelectarrData.removeAll()
        }
    }
    
    @IBAction func nextBtn(_ sender: UIButton) {
        print(SelectarrData)
    }
}
extension ViewController: UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        arrData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell",for: indexPath)
        cell.textLabel?.text = arrData[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.SelectarrData.removeAll()
        let arr = tableView.indexPathsForSelectedRows!
        for index in arr {
            SelectarrData.append(arrData[index.row])
        }
    }
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        self.DeselecetdCell(tableViewitem: tableView, indexPathitem: indexPath)
    }
}
extension ViewController{
    func DeselecetdCell(tableViewitem: UITableView, indexPathitem: IndexPath){
        self.SelectarrData.removeAll()
        let cell = tableViewitem.cellForRow(at: indexPathitem)
        cell!.backgroundColor = .green
        if tableViewitem.indexPathsForSelectedRows == nil{
          return
        }
        let arr = tableViewitem.indexPathsForSelectedRows!
            for index in arr {
                SelectarrData.append(arrData[index.row])
            }
    }
}
