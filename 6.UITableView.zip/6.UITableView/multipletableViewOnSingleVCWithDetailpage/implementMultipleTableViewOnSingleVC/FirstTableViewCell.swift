//
//  FirstTableViewCell.swift
//  implementMultipleTableViewOnSingleVC
//
//  Created by mac on 02/11/21.
//

import UIKit

class FirstTableViewCell: UITableViewCell {

    @IBOutlet weak var btnout: UIButton!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lbl1: UILabel!
    @IBOutlet weak var lbl2: UILabel!
    var ahModel: ahemdabad!{
        didSet{
            lbl1.text = ahModel.city
            lbl2.text = ahModel.title
            img.image = ahModel.img
        }
    }
    var mhModel: mumbai!{
        didSet{
            lbl1.text = mhModel.city
            lbl2.text = mhModel.title
            img.image = mhModel.img
        }
    }
    var bhModel: banglore!{
        didSet{
            lbl1.text = bhModel.city
            lbl2.text = bhModel.title
            img.image = bhModel.img
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
