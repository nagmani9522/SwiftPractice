//
//  DetailViewController.swift
//  implementMultipleTableViewOnSingleVC
//
//  Created by mac on 02/11/21.
//

import UIKit

class DetailViewController: UIViewController {
        @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblCity: UILabel!
    var ahdata: ahemdabad?
    var mdata:mumbai?
    var bdata:banglore?
    var pdata:pune?
    override func viewDidLoad() {
        super.viewDidLoad()
        showData()
        // Do any additional setup after loading the view.
    }
    func showData(){
        if (ahdata != nil){
            lblTitle.text = ahdata?.title
            lblCity.text = ahdata?.city
            imageView.image = ahdata?.img
        }
        else if mdata != nil{
            lblTitle.text = mdata?.title
            lblCity.text = mdata?.city
            imageView.image = mdata?.img
        }
        else if bdata != nil{
            lblTitle.text = bdata?.title
            lblCity.text = bdata?.city
            imageView.image = bdata?.img
        }
        else if pdata != nil{
            lblTitle.text = pdata?.title
            lblCity.text = pdata?.city
            imageView.image = pdata?.img
        }
    }
}
