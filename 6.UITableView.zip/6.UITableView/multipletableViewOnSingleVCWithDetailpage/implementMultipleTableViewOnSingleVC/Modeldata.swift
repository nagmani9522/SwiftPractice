//
//  Modeldata.swift
//  implementMultipleTableViewOnSingleVC
//
//  Created by mac on 02/11/21.
//

import Foundation
import UIKit
struct ahemdabad {
    let city:String?
    let img:UIImage?
    let title:String?
}
struct mumbai {
    let city:String?
    let img:UIImage?
    let title:String?
}
struct banglore {
    let city:String?
    let img:UIImage?
    let title:String?
}
struct pune {
    let city:String?
    let img:UIImage?
    let title:String?
}
