//
//  ViewController.swift
//  collapsAndExpandsSectionTableView
//
//  Created by mac on 17/11/21.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var tblView: UITableView!
    var sections = ["Category A", "Category B", "Category C"]
    var itemsA = ["Item","item A","ItemId" ,"1"]
    var itemsB = ["Item", "item B","ItemId", "2"]
    var itemsC = ["Item", "item C","ItemId", "3"]
    var tlView = UIView()
    var hiddenSections = Set<Int>()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return self.sections.count
    }

//    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
////        let label = UILabel()
////        label.text = sections[0]
////        label.textColor = .green
////        label.backgroundColor = .cyan
//
//        return  "Category A"  //label.text
//    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.hiddenSections.contains(section) {
            switch section {
            case 0:
                return itemsA.count
            case 1:
                return itemsB.count
            case 2:
                return itemsC.count
            default:
                print("test")
            }
            
            return sections.count
            }
            return 0
            // 2
      
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell") as! TableViewCell
        
        switch indexPath.section {
        case 0:
            cell.lbltxt.text = itemsA[indexPath.row]
        case 1:
            cell.lbltxt.text = itemsB[indexPath.row]
        case 2:
            cell.lbltxt.text = itemsC[indexPath.row]
        default:
            print("test")
        }
      

        return cell
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 100.0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: 100))

            let label = UILabel()
        label.frame = CGRect.init(x: 20, y: 0, width: UIScreen.main.bounds.size.width - 40.0, height: 100)
            label.text = sections[section]
            label.font = .systemFont(ofSize: 16)
            label.textColor = .red
         label.backgroundColor = .blue
        headerView.backgroundColor = .white

            headerView.addSubview(label)
        
        
        // 1
            let sectionButton = UIButton()
            
            // 2
        //    sectionButton.setTitle(String(section),
         //                          for: .normal)
            
            // 3
            sectionButton.backgroundColor = .clear
            
            // 4
            sectionButton.tag = section
            
        
        
        sectionButton.frame = CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: 100)
            // 5
            sectionButton.addTarget(self,
                                    action: #selector(self.hideSection(sender:)),
                                    for: .touchUpInside)

        headerView.addSubview(sectionButton)

            return headerView
        }
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        return 50
//    }
    @objc
    private func hideSection(sender: UIButton) {
        // Create section let
        let section = sender.tag
//        func indexPathsForSection() -> [IndexPath] {
//                var indexPaths = [IndexPath]()
//
//            for row in 0...2 {
//                    indexPaths.append(IndexPath(row: row,
//                                                section: section))
//                }
//
//                return indexPaths
//            }
            
            if self.hiddenSections.contains(section) {
                self.hiddenSections.remove(section)
                self.tblView.reloadData()
            } else {
                self.hiddenSections.insert(section)
                self.tblView.reloadData()
            }
        // Add indexPathsForSection method
        // Logic to add/remove sections to/from hiddenSections, and delete and insert functionality for tableView
    }
    
}

