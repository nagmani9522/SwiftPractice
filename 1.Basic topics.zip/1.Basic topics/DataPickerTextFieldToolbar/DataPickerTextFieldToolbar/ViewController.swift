//
//  ViewController.swift
//  DataPickerTextFieldToolbar
//
//  Created by mac on 16/04/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var txtDate: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

}
extension ViewController:UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        self.openDatePicker()
    }
}
extension ViewController{
    func openDatePicker(){
        let datePicker = UIDatePicker()
        datePicker.datePickerMode = .date
        datePicker.addTarget(self, action: #selector(self.datePickerHandler(datePicker:)), for: .valueChanged)
        txtDate.inputView = datePicker // Keyboard
        datePicker.preferredDatePickerStyle = UIDatePickerStyle.wheels
        let toolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: 44))
        let cancelBtn = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(self.cancelBtnClick))
        let doneBtn = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(self.doneBtnClick))
        let flexibleBtn = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        toolbar.setItems([cancelBtn, flexibleBtn,doneBtn], animated: false)
        txtDate.inputAccessoryView = toolbar // toolbar
        
    }
    @objc func cancelBtnClick(){
        txtDate.resignFirstResponder()
    }
    @objc func doneBtnClick(){
        let datePicker = txtDate.inputView as? UIDatePicker
        let dateFormate = DateFormatter()
        dateFormate.dateStyle = .medium
        txtDate.text = dateFormate.string(from: datePicker!.date)
        txtDate.resignFirstResponder()
        print(datePicker?.date)
    }
    @objc func datePickerHandler(datePicker:UIDatePicker){
        let dateFormate = DateFormatter()
        dateFormate.dateStyle = .medium
        txtDate.text = dateFormate.string(from: datePicker.date)
    }
}
