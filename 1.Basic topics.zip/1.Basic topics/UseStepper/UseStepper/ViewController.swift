//
//  ViewController.swift
//  UseStepper
//
//  Created by mac on 15/04/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var stepper: UIStepper!
    @IBOutlet var lbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        stepper.setDecrementImage(stepper.decrementImage(for: .normal), for: .normal)
        stepper.setIncrementImage(stepper.incrementImage(for: .normal), for: .normal)


        // Do any additional setup after loading the view.
    }

    @IBAction func valueChange(_ sender: UIStepper) {
        lbl.text = Int(sender.value).description
    }
    
}

