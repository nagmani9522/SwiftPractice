//
//  ViewController.swift
//  UseSegmentedSegmentControl
//
//  Created by mac on 15/04/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var lbl: UILabel!
    @IBOutlet var seg: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()
        let titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.blue]
        seg.setTitleTextAttributes(titleTextAttributes, for: .normal)
        lbl.isHidden = true
        // Do any additional setup after loading the view.
    }

    @IBAction func valueChange(_ sender: UISegmentedControl) {
        seg.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.white], for: .selected)
        if seg.selectedSegmentIndex == 0{
            lbl.text = "First is Selected"
        }else if seg.selectedSegmentIndex == 1{
            lbl.text = "Second is Selected"
        }else if seg.selectedSegmentIndex == 2{
            lbl.text = "Third is Selected"
        }else if seg.selectedSegmentIndex == 3{
            lbl.text = "Four is Selected"
        }
        lbl.isHidden = false
    }
    
}

