//
//  ViewController.swift
//  ActionCollectionCollectonActionIBOutlet
//
//  Created by mac on 15/04/22.
//
 
import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var btnTortise: UIButton?
    @IBOutlet var btns: [UIButton]!
    override func viewDidLoad() {
        super.viewDidLoad()
        btnTortise?.isSelected = false
    }
    
//    @IBAction func btn1Action(_ sender: UIButton) {
//
//        sender.setImage(UIImage(named: "message"), for: .normal)
//    }
    
    @IBAction func btnActionTapped(_ sender: UIButton) {
//        for btn in btns {
//            btn.isSelected = false
//        }
   //     btns.forEach {$0.isSelected = false}
        btns.map {$0.isSelected = false}
        sender.isSelected.toggle()
        imageSet(sender: sender, senderTag: sender.tag, btnStatus: sender.isSelected)
    }
    func imageSet(sender:UIButton,senderTag:Int,btnStatus:Bool){
        switch senderTag{
        case 0:
            sender.setImage(UIImage(named: "message"), for: .selected)
            sender.setImage(UIImage(named: "call"), for: .normal)
            btn1()
            break
        case 1:
            sender.setImage(UIImage(named: "twitter"), for: .selected)
            sender.setImage(UIImage(named: "fbMessenger"), for: .normal)
            btn2()
            break
        case 2:
            sender.setImage(UIImage(named: "mail"), for: .selected)
            sender.setImage(UIImage(named: "whatsapp"), for: .normal)
            btn3()
            break
        case 3:
            sender.setImage(UIImage(named: "gmail"), for: .selected)
            sender.setImage(UIImage(named: "instagram"), for: .normal)
            btn4()
            break
        case 4:
            sender.setImage(UIImage(named: "outlook"), for: .selected)
            sender.setImage(UIImage(named: "skype"), for: .normal)
            btn5()
            break
        default:
            print("😂😂😂😂😂😂")
            break
      }
        //sender.tag == 0 ? btn1():sender.tag == 1 ? btn2():sender.tag == 2 ? btn3():sender.tag == 3 ? btn4():btn5()
    }
    func btn1(){
        print("btn1")
    }
    func btn2(){
        print("btn2")
    }
    func btn3(){
        print("btn3")
    }
    func btn4(){
        print("btn4")
    }
    func btn5(){
        print("btn5")
    }
    
}

