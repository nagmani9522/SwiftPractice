//
//  ViewController.swift
//  CustomSwitchUsingSwiftySwitch
//
//  Created by mac on 16/04/22.
//

import UIKit

class ViewController: UIViewController,SwiftySwitchDelegate {
    
    @IBOutlet var switch1: SwiftySwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        switch1.delegate = self
    }
    func valueChanged(sender: SwiftySwitch) {
        if switch1.isOn{
            self.view.backgroundColor = #colorLiteral(red: 0.1019607857, green: 0.2784313858, blue: 0.400000006, alpha: 1)
        }else{
            self.view.backgroundColor = #colorLiteral(red: 0.1960784346, green: 0.3411764801, blue: 0.1019607857, alpha: 1)
        }
    }

}

