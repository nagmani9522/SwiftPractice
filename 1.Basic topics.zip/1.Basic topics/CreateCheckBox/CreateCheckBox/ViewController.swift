//
//  ViewController.swift
//  CreateCheckBox
//
//  Created by mac on 16/04/22.
//

import UIKit

class ViewController: UIViewController,BEMCheckBoxDelegate {
    @IBOutlet var checkBox1: BEMCheckBox!
    @IBOutlet var checkBox2: BEMCheckBox!
    override func viewDidLoad() {
        super.viewDidLoad()
        checkBox1.delegate = self
        checkBox2.delegate = self
    }
    func didTap(_ checkBox: BEMCheckBox) {
        if checkBox.tag == 0{
            self.view.backgroundColor = UIColor.black
        }else if checkBox.tag == 1{
            self.view.backgroundColor = UIColor.brown
        }
//        self.view.backgroundColor = UIColor.black
    }
}
