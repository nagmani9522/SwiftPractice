import UIKit

class ViewController: UIViewController {
    @IBOutlet var txt1: UITextField!
    @IBOutlet var txt2: UITextField!
    @IBOutlet var txt3: UITextField!
    @IBOutlet var txt4: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
//        txt1.autocapitalizationType = .allCharacters
//     txt2.autocapitalizationType = .sentences
//        txt3.autocapitalizationType = .words
//        txt4.autocapitalizationType = .none
    }
}

