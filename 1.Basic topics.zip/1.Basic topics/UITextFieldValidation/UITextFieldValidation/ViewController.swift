//
//  ViewController.swift
//  UITextFieldValidation
//
//  Created by mac on 16/04/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var txtEmail: UITextField!
    @IBOutlet var txtPassword: UITextField!
    @IBOutlet var txtPhone: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    func isPasswordvalid(yourphoneText:String) -> Bool{
        let passwordTest = NSPredicate(format: "SELF MATCHES %@","^(?=.*[a-z])(?=.*[$@$#!%*?&])[A-Za-z\\d$@$#!%*?&]{8,}")
        return passwordTest.evaluate(with: yourphoneText)
    }
    @IBAction func btnSaveClick(_ sender: UIButton) {
        if (txtEmail.text!.isValidEmail){
            print("Your email is valid")
        }else{
            print("Your email is not valid")
        }
        if (txtPassword.text!.isPasswordValid){
            print("Your password is valid")
        }else{
            print("Your password is not valid")
        }
        if (txtPhone.text!.isPhoneNumber){
            print("Your phoneNumber is valid")
        }else{
            print("Your phoneNumber is not valid")
        }
        if (isPasswordvalid(yourphoneText: txtPassword.text!)){
            print("Your password is valid")
        }else{
            print("Your password is not valid")
        }
    }
}
extension String{
    var isPhoneNumber: Bool{
        do{
            let detector = try NSDataDetector(types: NSTextCheckingResult.CheckingType.phoneNumber.rawValue)
            let matches = detector.matches(in: self, options: [], range: NSMakeRange(0, self.count))
            if let res = matches.first {
                return res.resultType == .phoneNumber && res.range.location == 0 && res.range.length == self.count && self.count == 10
            }else{
                return false
            }
        }catch{
            return false
        }
    }
    var isPasswordValid:Bool{
        do{
            let passwordTest = NSPredicate(format: "SELF MATCHES %@","^(?=.*[a-z])(?=.*[$@$#!%*?&])[A-Za-z\\d$@$#!%*?&]{8,}")
            return passwordTest.evaluate(with: self)
        }
    }
    var isValidEmail:Bool{
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,3}"
        let emailTest = NSPredicate(format: "SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: self)
    }
}
