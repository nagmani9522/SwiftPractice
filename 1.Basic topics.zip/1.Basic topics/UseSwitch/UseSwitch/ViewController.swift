//
//  ViewController.swift
//  UseSwitch
//
//  Created by mac on 15/04/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var lbl: UILabel!
    @IBOutlet var switchState: UISwitch!
    override func viewDidLoad() {
        super.viewDidLoad()
        lbl.isHidden = true
        // Do any additional setup after loading the view.
    }

    @IBAction func valueChang(_ sender: UISwitch) {
        if switchState.isOn{
            lbl.text = "Switch is On"
            self.view.backgroundColor = #colorLiteral(red: 0.1764705926, green: 0.01176470611, blue: 0.5607843399, alpha: 1)
        }else{
            lbl.text = "Switch is Off"
            self.view.backgroundColor = #colorLiteral(red: 0.5725490451, green: 0, blue: 0.2313725501, alpha: 1)
        }
        lbl.isHidden = false
    }
    
}

