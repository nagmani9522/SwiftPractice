//
//  ViewController.swift
//  AlertActionSheet
//
//  Created by mac on 16/04/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func AlertAction(_ sender: UIButton) {
        let alert = UIAlertController(title: "My Tittle", message: "My message", preferredStyle: .alert)
        alert.addTextField { (textField) in
            textField.placeholder = "Enter Your Name"
        }
        let cancel = UIAlertAction(title: "Cancle Buuton", style: .cancel){
            (action) in
            print("cancel")
            print(alert.textFields?.first?.text)
        }
        let done = UIAlertAction(title: "Done Buuton", style: .default){
            (action) in
            print("done")
        }
        let destructive =  UIAlertAction(title: "Destructive Buuton", style: .destructive){
            (action) in
            print("destructive")
        }
        alert.addAction(destructive)
        alert.addAction(cancel)
        alert.addAction(done)
        present(alert, animated: true, completion: nil)
    }
    
    @IBAction func ActionSheetAction(_ sender: UIButton) {
        let alert = UIAlertController(title: "My Tittle", message: "My message", preferredStyle: .actionSheet)
        let cancel = UIAlertAction(title: "Cancle Buuton", style: .cancel){
            (action) in
            print("cancel")
        }
        let done = UIAlertAction(title: "Done Buuton", style: .default){
            (action) in
            print("done")
        }
        let destructive =  UIAlertAction(title: "Destructive Buuton", style: .destructive){
            (action) in
            print("destructive")
        }
        alert.addAction(destructive)
        alert.addAction(cancel)
        alert.addAction(done)
        present(alert, animated: true, completion: nil)
    }
}

