//
//  ViewController.swift
//  NotificationCenter
//
//  Created by mac on 05/12/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var socialTxt: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(skype(notification:)), name: .skype, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(twitter(notification:)), name: .twitter, object: nil)
        // Do any additional setup after loading the view.
    }

    @IBAction func socialMediaAction(_ sender: UIButton) {
        let nextVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    @objc func skype(notification:Notification){
        imgView.image = #imageLiteral(resourceName: "skype")
        socialTxt.text = "Skype"
    }
    @objc func twitter(notification:Notification){
        imgView.image = #imageLiteral(resourceName: "twitter")
        socialTxt.text = "Twitter"
    }
}
extension Notification.Name{
    static let skype = Notification.Name("skype")
    static let twitter = Notification.Name("twitter")
}
