//
//  SecondViewController.swift
//  NotificationCenter
//
//  Created by mac on 05/12/21.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func skypeAction(_ sender: UIButton) {
        NotificationCenter.default.post(name: .skype, object: nil)
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func twitterAction(_ sender: UIButton) {
        NotificationCenter.default.post(name: .twitter, object: nil)
        self.navigationController?.popViewController(animated: true)
    }
}
