//
//  ViewController.swift
//  usingFMDB
//
//  Created by mac on 18/12/21.
//

//
//  ViewController.swift
//  sqliteUsingFMDB
//
//  Created by mac on 12/12/21.
//

import UIKit

class firstViewController: UIViewController {
    
    @IBOutlet weak var txtFname: UITextField!
    @IBOutlet weak var txtLname: UITextField!
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func save(_ sender: UIButton) {
    let modelInfo = SignupModel(fname: txtFname.text!, lname: txtLname.text!, phone: txtPhone.text!, email: txtEmail.text!)
        let isSave = databaseManager.getInstance().saveData(modelInfo)
        print(isSave)
    }
}

