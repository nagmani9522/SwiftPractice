//
//  databaseHelper.swift
//  usingFMDB
//
//  Created by mac on 18/12/21.
//

import Foundation
import FMDB
var shareInstance = databaseManager()
class databaseManager:NSObject{
    var database:FMDatabase? = nil
    
    class func getInstance() -> databaseManager{
        if shareInstance.database == nil{
            shareInstance.database = FMDatabase(path: sqliteFMDB.getPath("login.db"))
        }
        return shareInstance
    }
    func saveData(_ modelInfo:SignupModel) -> Bool{
        shareInstance.database?.open()
        let isSave = shareInstance.database?.executeUpdate("INSERT INTO login (fname,lname,phone,email) VALUES (?,?,?,?)", withArgumentsIn: [modelInfo.fname,modelInfo.lname,modelInfo.phone,modelInfo.email])
        shareInstance.database?.close()
        return isSave!
    }
}

