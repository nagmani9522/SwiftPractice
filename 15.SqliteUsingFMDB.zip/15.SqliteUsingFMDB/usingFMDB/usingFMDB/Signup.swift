//
//  Signup.swift
//  usingFMDB
//
//  Created by mac on 18/12/21.
//

import Foundation
struct SignupModel {
    let fname:String
    let lname:String
    let phone:String
    let email:String
}
