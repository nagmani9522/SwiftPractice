//
//  SignupModel.swift
//  sqliteUsingFMDB
//
//  Created by mac on 12/12/21.
//

import Foundation
struct SignupModel {
    let fname:String
    let lname:String
    let phone:String
    let email:String
}
