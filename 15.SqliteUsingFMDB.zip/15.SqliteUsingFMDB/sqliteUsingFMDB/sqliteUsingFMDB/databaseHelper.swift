//
//  databaseHelper.swift
//  sqliteUsingFMDB
//
//  Created by mac on 12/12/21.
//

import Foundation
var shareInstance = databaseManager()
class databaseManager:NSObject{
    var database:FMDatabase? = nil
    
    class func getInstance() -> databaseManager{
        if shareInstance.database == nil{
            shareInstance.database = FMDatabase(path: sqliteFMDB.getPath("Signup.db"))
        }
        return shareInstance
    }
    func saveData(_ modelInfo:SignupModel) -> Bool{
        shareInstance.database?.open()
        let isSave = shareInstance.database?.executeUpdate("INSERT INTO Signup (fname,lname,phone,email) VALUES (?,?,?,?)", withArgumentsIn: [modelInfo.fname,modelInfo.lname,modelInfo.phone,modelInfo.email])
        shareInstance.database?.close()
        return isSave!
    }
}
