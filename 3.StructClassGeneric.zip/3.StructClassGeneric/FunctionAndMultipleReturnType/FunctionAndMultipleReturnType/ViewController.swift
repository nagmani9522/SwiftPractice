//
//  ViewController.swift
//  FunctionAndMultipleReturnType
//
//  Created by mac on 30/10/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        change()
        print(addValue(value1: 12, value2: 13))
        add(value1: 15, value2: 18)
        print(addvalues())
        print("\(getresult().0) \(getresult().1) \(getresult().2)")
        print("\(getresultanswer().Name) \(getresultanswer().surname) \(getresultanswer().field)")
    }
    // func no parameter no return type
    func change(){
        view.backgroundColor = UIColor.red
    }
    // func with parameter with return type
    func addValue(value1: Int,value2: Int) -> Int{
        let add = value1+value2
        return add
    }
    // func with parameter no return type
    func add(value1: Int,value2: Int) {
        let add = value1+value2
        print(add)
    }
    // func no parameter with return type
    func addvalues() -> String {
        return "Nagmani"
    }
    func getresult() -> (String,String,String){
        return ("Nagmani","kumar","ios")
    }
    // multiple return type
    func getresultanswer() -> (Name:String,surname:String,field:Int){
        return ("Nagmani","kumar",123)
    }
}

