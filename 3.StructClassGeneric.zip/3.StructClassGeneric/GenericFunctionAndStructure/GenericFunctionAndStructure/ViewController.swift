//
//  ViewController.swift
//  GenericFunctionAndStructure
//
//  Created by mac on 30/10/21.
//

import UIKit

class ViewController: UIViewController {
    struct Addition<Element>{
        var items = [Element]()
        mutating func push(_ item: Element){
            items.append(item)
        }
//        mutating func pop() -> Element{
//            items.removeLast()
//        }
        mutating func pop() {
            items.removeLast()
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        print(addOfTwoValues(a1: 12, a2: Int(13.34)))
        print(addOfTwoDoubleValues(a1: 12, a2: 13.34))
        print(additionUsingGeneric(a1: 12, a2: 13.89))
        print(additionUsingGeneric(a1: 12.67, a2: 63.89))
        getData()
    }
   //  MARK: Integer
    func addOfTwoValues(a1: Int,a2: Int) -> Int{
      let answer = a1+a2
        return answer
    }
    func addOfTwoDoubleValues(a1: Double,a2: Double) -> Double{
        return a1+a2
    }
    // MARK: Generic
    func additionUsingGeneric<T:Numeric>(a1:T,a2:T) -> T {
        let answer = a1+a2
          return answer
    }
    // MARK: Structure
    func getData(){
        var add = Addition<Any>()
        add.push(12.78)
        add.push(14)
        add.push(15)
        add.push(15)
        print(add)
        add.pop()
        print(add)
        add.push(123)
        print(add)
        add.push("ram")
        print(add)
    }
}

