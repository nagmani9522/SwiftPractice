//
//  ViewController.swift
//  howToUseEnum
//
//  Created by mac on 29/10/21.
//

import UIKit

class ViewController: UIViewController {
// Enum without type
    enum Collage {
        case studentName
        case CollageName
        case id
    }
    // Enum with type
    enum CollageType:String {
        case StudentName = "nagmani"
        case CollageName = "Accurate"
        case id = "102"
    }
    enum collageFunc {
        case studentName
        case collageName
        case id
        
        func description() -> String{
            switch self{
            case .collageName:
                return "Accurate"
            case .studentName:
                return "Nagmani"
            case .id:
                return "102"
            }
        }
    }
    // with argument
    enum student{
        case studentName(String)
        case marks(String,String,String)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        //enumWithType()
        //enumWithoutType()
        let collageDetails = collageFunc.collageName.description()
        print(collageDetails)
        enumWithArgument()
        enumWithoutType()
       
    }
    func enumWithArgument(){
        let stuName =  student.studentName("Nagmani")
        let stuMarks = student.marks("12", "13", "15")
        switch stuMarks{
        case .studentName(let strName):
            print("my name is \(strName)")
        case .marks(let m1,let m2,let m3):
            print("my marks is \(m1) \(m2) \(m3)")
        }
    }
    func enumWithType(){
        let collageTypeDetail = CollageType.CollageName
        print(collageTypeDetail)
        let collageTypeRaw = CollageType.CollageName.rawValue
        print(collageTypeRaw)
        let collHas = CollageType.CollageName.hashValue
        print(collHas) // error value obtain
            }
    func enumWithoutType(){
            let collageDetail = Collage.studentName
            let indexValue = Collage.id.hashValue
            print(indexValue)// error value obtain
        print(collageDetail.hashValue)
            switch collageDetail{
            case .CollageName:
                print("Accurate collage")
            case .id:
                print("102")
            case .studentName:
                print("Nagmani kumar")
            }
        }
}


