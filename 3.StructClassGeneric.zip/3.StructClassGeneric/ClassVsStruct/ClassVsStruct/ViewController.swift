//
//  ViewController.swift
//  ClassVsStruct
//
//  Created by mac on 29/10/21.
//

import UIKit
class ViewController: UIViewController {
    struct nagmani {
        var name:String
        init(Name:String) {
            self.name = Name
        }
    }
    class mukesh{
        var name:String
        init(Name:String) {
            self.name = Name
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        forStructure()
        forClass()
        
    }
    func forClass(){
        let fname = mukesh(Name: "nagmani Kumar")
        let sname = fname
        sname.name = "bharti kumar"
        print(sname.name)
        print(fname.name)
        
    }
    func forStructure(){
        let fname = nagmani(Name: "nagmani Kumar")
        var sname = nagmani(Name: "nagmani Kumar")
        sname.name = "bharti kumar"
        print(sname.name)
        print(fname.name)
        
    }

}

