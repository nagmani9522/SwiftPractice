//
//  ViewController.swift
//  InAppPurchases
//
//  Created by mac on 31/07/22.
//

import UIKit
import StoreKit
class ViewController: UIViewController,SKProductsRequestDelegate,SKPaymentTransactionObserver {
    enum Product:String,CaseIterable{
        case gems = "com.graminseva.gems"
        case noadspremium = "com.graminseva.premium"
        case monthlysubscription = "com.graminseva.monthly"
    }
    func productsRequest(_ request: SKProductsRequest, didReceive response: SKProductsResponse) {
        if let oProduct = response.products.first{
            print("Product is available")
            self.purchase(aproduct: oProduct)
        }else{
            print("Product is not available")
        }
    }
    
    func paymentQueue(_ queue: SKPaymentQueue, updatedTransactions transactions: [SKPaymentTransaction]) {
        for transaction in transactions{
            switch transaction.transactionState {
            case .purchasing:
                print("Customer is transition Process")
            case .purchased:
                SKPaymentQueue.default().finishTransaction(transaction)
                
                print("Customer is Complete transition")
            case .failed:
                SKPaymentQueue.default().finishTransaction(transaction)
                print("Customer is failed transition")
            case .restored:
                print("Customer is restored transition")
            case .deferred:
                print("Customer is deferred transition")
            default: break
 //           @unknown default: break
//            @unknown default:
//                print("Customer is unknown transition")
            }
        }
    }
    
    func purchase(aproduct:SKProduct){
        let payment = SKPayment(product: aproduct)
        SKPaymentQueue.default().add(self)
        SKPaymentQueue.default().add(payment)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func getGameBtn(_ sender: UIButton) {
        if SKPaymentQueue.canMakePayments(){
            let set: Set<String> = [Product.gems.rawValue]
            let productRequest = SKProductsRequest.init(productIdentifiers: set)
            productRequest.delegate = self
            productRequest.start()
        }
    }
    @IBAction func addFree(_ sender: UIButton) {
        if SKPaymentQueue.canMakePayments(){
            let set: Set<String> = [Product.noadspremium.rawValue]
            let productRequest = SKProductsRequest.init(productIdentifiers: set)
            productRequest.delegate = self
            
            productRequest.start()
        }
    }
    @IBAction func premiumBtn(_ sender: UIButton) {
        if SKPaymentQueue.canMakePayments(){
            let set: Set<String> = [Product.monthlysubscription.rawValue]
            let productRequest = SKProductsRequest.init(productIdentifiers: set)
            productRequest.delegate = self
            productRequest.start()
        }
    }
}

