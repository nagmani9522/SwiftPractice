//
//  ViewController.swift
//  Initializers
//
//  Created by mac on 14/08/22.
//

import UIKit
//import Foundation
enum Gender{
    case male
    case female
    case unknow
}
struct Human{
    /// let and var are stored properties
    var gender:Gender /// this is a stored property.
    init(gender:Gender){
        self.gender = gender
    }
}
class ViewController: UIViewController {
    
    let human = Human(gender: .male)
    let humans = Human.init(gender: .male)
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

}
enum Genders{
    case male
    case female
    case unknow
}
struct Humans{
    /// set the variable a default value at the time of declaration.
    var gender:Genders = .male
}
let human = Humans()
print(human.gender) /// male
/// if you want to use default init the you give store properies as optional or default value
enum Genderss{
    case male
    case female
    case unknow
}
struct Humanss{
    /// set the variable a default value at the time of declaration.
    var genderr:Genderss?
}
var humanss = Humanss()
humanss.genderr = .male
print(human.gender ?? .unknow) /// male
