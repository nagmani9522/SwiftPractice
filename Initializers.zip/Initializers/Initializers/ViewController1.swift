//
//  ViewController1.swift
//  Initializers
//
//  Created by mac on 14/08/22.
//

import UIKit
enum Gendering{
    case male
    case female
    case unknow
}
struct Humaning{
/// we can change the struct to class then same work both have multiple initializer
    var gender:Gendering
    var age:Int = 10
    init(gender:Gendering){  /// initializer 1
        self.gender = gender
    }
    init(age:Int){ /// initializer 2
        self.age = age
        self.gender = .unknow
    }
    init(age:Int,gender:Gendering){  /// initializer 3
        self.age = age
        self.gender = gender
    }
    /// Parameter name is not required init
    init(_ age:Int, _ gender:Gendering){
        self.age = age
        self.gender = gender
    }
}
class ViewController1: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}
/// let's call now...
let human1 = Humaning(gender: .male) /// male, 10
let human2 = Humaning(age: 20) ///unknown, 20
let human3 = Humaning(age: 40, gender: .male) /// male, 40
let human4 = Humaning(40,.male)
/// in class memberWise Initializer are not provide only Structure Can provide MemberWise Initilizer
class Product{
    var name:String?
    var quantity = 1
    var purchased = false
}
let apple = Product()
struct Size{
    var width,height: Double  ///  Stored properties without default  values
}
struct Sizes{
    var width = 10.0,height = 30.0 /// Stored properties with default values
}
let size = Size(width: 2.0, height: 2.0)
let sizes = Sizes()
let sizess = Sizes(width: 23)
struct sizeses{
    var width,height: Double
    init(){
        self.width = 10.0
        self.height = 30.0
    }
}
let sizeObj1 = sizeses(width: 2.0, height: 2.0) /// error:  Argument passed to call that takes no arguments
let sizeObj2 = sizeses() /// Success.
