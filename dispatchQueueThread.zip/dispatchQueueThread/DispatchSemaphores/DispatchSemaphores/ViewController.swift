//
//  ViewController.swift
//  DispatchSemaphores
//
//  Created by mac on 30/07/22.
//

import UIKit

class ViewController: UIViewController {
    // two way array define
    var musics:[String] = []
    //var arr = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let semaphore = DispatchSemaphore(value: 1)
        let queue = DispatchQueue.global()
        queue.async {
            print("before first wait")
            semaphore.wait() // 0
            print("after first wait")
            let music = self.downloadMusic(name: "o humdum suniyo re!")
            self.musics.append(music)
            //semaphore.signal() // value 1
        }
        queue.async {
            print("before second wait")
            semaphore.wait() // value 0  // value -1 // value 0
            print("after second wait")
            self.saveMusics()
            self.musics.remove(at: 0)
            semaphore.signal() // value 1
        }
    }
    func downloadMusic(name:String) -> String{
        sleep(4)
        print("\(name) has been downloaded.")
        return name
    }
    func saveMusics(){
        sleep(2)
        print("Musics has been saved.")
    }
}

