                     Dispatch Semaphores
1. Semaphores gives us the ability to control access to a shared resource by multiple threads. For an easy start, let’s consider the following real-life scenario:
2. A father sits with his three kids at home, then he pulls out an iPad...

Kid 2: I want to play with the iPad!!!

Kid 1: No!, I want to play first…

Kid 3: iPad! iPad! iPad! * sound of claps*

Father:Ok,Kid2, since you asked first and no one is currently using the iPad, take it, but let me know once you are done. Rest of kids, please wait patiently.

Kid 2:(5 min later) I am done father.

Father: Kid 1, the iPad is available, let me know once you are done.

Kid 1:(5 min later) I am done father.

Father: Kid 3, the iPad is available, let me know once you are done.

Kid 3:(5 min later) I am done father.

3. In this scenario above, the father is the semaphore, the iPad is the shared resource, and the kids are the threads. Note how the father make sure that only one kid use the iPad at a time. If we compare this to programming, only one thread has access to  a shared resource at  a time. In addition, note the order of use, the first who asked is the first who get (FIFO).

4. Tip: a shared resource can represent a variable, ora job such as downloading an image from url, reading from a database, etc.

5. What if the father just gave the iPad to the kids? A fight would build up to the point of a probably broken iPad. If we compare this to programming, multiple threads try to access the same resources at the same time and nothing is preventing it. Such behaviour could lead to race conditions, crashes, and obviously, our code won’t be thread safe.

6. Thread safe: code that can be safely called from multiple threads without causing any issues.

                       A Bit  of Theory
1.  A semaphore consist of a threads queue and a counter value (type Int).

2. Threads queue is used by the semaphore to keep track on waiting threads in FIFO order (The first thread entered to the queue will be the first to get access to a shared resource or not. The counter value changes when we call signal() or wait() functions.

3. So, when should we call wait() and signal() functions?

4. Call wait() each time before using the shared resource. We are basically signalling the semaphore that we are done interacting with the shared resource.

                Calling wait() will do the following:
1. Decrement semaphore counter by 1.
2. If the resulting value is less than zero, thread is freezed.
3. If the resulting value is equal or bigger than zero, code will get executed without waiting.

                 Calling signal()will do the following:
1. Increment semaphore counter by 1.
2. If the previous value was less than zero, this function wakes the oldest thread currently waiting in the thread queue.
3. If the previous value is equal or bigger than zero, it mean thread queue is empty, no one is waiting.

                First, let’s create a semaphore instance:
1. Let  semaphore = DispatchSemaphore(value: 1)
2. DispatchSemaphore init function has one parameter called “value”.This is the counter value which represents the amount of threads we want to allow access to a shared resource at a given moment. In this case, we want to allow only one thread (kid) to access the shared resource(iPad), so let’s set it to 1.


