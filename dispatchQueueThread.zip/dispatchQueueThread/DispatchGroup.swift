                     DispatchGroup
1. Sometimes, instead of just tossing a job into a queue, you need to process a group of jobs. They don’t all have to run at the same time, but you need to know when they have all completed.Apple provides dispatch groups for this exact scenario.

2. The aptly named DispatchGroup class is what you will use when you want to track the completion of a group of tasks.

3. You start by initialising a DispatchGroup. Once you have one and want to track a task as part of that group, you can provide the group as an argument to the async method on any dispatch queue.

4.  As seen in the example code above, groups are hardwired to a single dispatch queue. You can use a single group, yet submit jobs to multiple queues, depending on the priority of the task that needs to be run. DispatchGroups provide a notify(queue:)method, which you can use to be notified as soon as every job submitted has finished.

5. Note :- The notification is itself asynchronous, so it is possible to submit more jobs to the group after calling notify, as long as the previously submitted jobs have already completed.

                    Synchronous waiting
1. If , for some reason, you can not respond asynchronously to the group’s completion notification, then you can instead use the Wait method  on the dispatch group. This is a synchronous method that will block the current queue until all the jobs have finished. It takes an optional parameter which specifies how long to wait for the tasks to complete. If not specified then there is an infinite wait time:

2. At this point, calling a synchronous wait method like this should be a code smell to you, potentially pointing out other issues in your architecture. Sure, it is much easier to implement synchronously, but the entire reason you are watching this videos is to learn how to make your app perform as fast as possible. Having a thread just spin and continually ask, “ Is it done yet?” Is not the best use of system resources.

                 Wrapping asynchronous methods
1. A dispatch queue natively knows how to work with dispatch groups, and it takes care of signalling to the system that a job has completed for you. In this case, completed means that a job has completed for you. In this case, completed means that the code block has run its course. Why does that matter? Because if you call an asynchronous method inside of your closure, then the closure will complete before the internal asynchronous method has completed.

2. You have got to somehow tell the task that it is not done until those internal calls have completed as well. In such a case, You can call the provided enter and leave methods on DispatchGroup. Think of them like a simple count of running tasks. Every time you enter, the count goes up by 1. When  you leave, the count goes down by 1:

queue.dispatch(group:group){
// count is 1
group.enter()
// count is 2
someAsyncMethod{
defer {
group.leave()
// Perform your work here,
// count goes back to 1 once complete
}
}
}



