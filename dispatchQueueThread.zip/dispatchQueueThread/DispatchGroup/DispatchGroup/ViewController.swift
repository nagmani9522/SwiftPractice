//
//  ViewController.swift
//  DispatchGroup
//
//  Created by mac on 29/07/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        //notifyDispatchGroup()
        syncWaitingGroup()
    }


}
extension ViewController{
    func notifyDispatchGroup(){
        let group = DispatchGroup()
        let queue = DispatchQueue(label: "com.company.app")
        let someQueue = DispatchQueue(label: "com.company.app1")
        queue.async(group: group) {
            for _ in 0...25{
                print("queue:- Task one running")
            }
        }
        queue.async(group: group) {
            for _ in 0...15{
                print("queue:- Task two running")
            }
        }
        someQueue.async(group: group) {
            for _ in 0...45{
                print("someQueue:- Task two running")
            }
        }
        // Same Group dena hai jiska bhi same group hoga complete hone ke bad aapko notify kar dega
        group.notify(queue: DispatchQueue.main){
            print("All jobs have completed")
        }
    }
}
extension ViewController{
    func syncWaitingGroup(){
        let group = DispatchGroup()
        let queue = DispatchQueue.global(qos: .userInitiated)
        queue.async(group: group) {
            print("Start job 1")
            Thread.sleep(until: Date().addingTimeInterval(10))
            print("End job 1")
        }
        queue.async(group: group) {
            print("Start job 2")
            Thread.sleep(until: Date().addingTimeInterval(2))
            print("End job 2")
        }
        // wait method
//        if group.wait(timeout: .now() + 5) == .timedOut{
        if group.wait(timeout: .now() + 11) == .timedOut{
            print("I got tired of waiting")
        }else{
            print("All the jobs have completed")
        }
    }
}
