//
//  ViewController.swift
//  DispatchQueuePart2
//
//  Created by mac on 26/07/22.
//

import UIKit

class ViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {
    
    var urls = [UIImage]()
    let textLabel = UILabel()
    @IBOutlet var collectionView: UICollectionView!
    let strURL = "https://miro.medium.com/max/1200/1*mk1-6aYaf_Bes1E3Imhc0A.jpeg"
    override func viewDidLoad() {
        super.viewDidLoad()
        for _ in 0...21{
            downloadWithUrlSession()
        }
    }
    private func downloadWithUrlSession(){
        DispatchQueue.global(qos: .utility).async { [weak self] in
            
            // perform your work here
            URLSession.shared.dataTask(with: URL(string: self!.strURL)!){ [weak self] data, response,error in
                guard let self = self,
                        let data = data,
                        let image = UIImage(data: data) else{
                    return
                }
                self.urls.append(image)
                DispatchQueue.main.async {
                    self.collectionView.reloadData()
                }
            }.resume()
        }
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return urls.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath) as! CollectionViewCell
        // This line of code is Cell Smooth run
        cell.layer.shouldRasterize = true
        cell.layer.rasterizationScale = UIScreen.main.scale
        cell.imgCell.image = urls[indexPath.row]
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//        return CGSize(width: collectionView.frame.size.width/2, height: collectionView.frame.size.height/4)
        return CGSize(width: 100, height: 100)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
         0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
         0
    }
}

