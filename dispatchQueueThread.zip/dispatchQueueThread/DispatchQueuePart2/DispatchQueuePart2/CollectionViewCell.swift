//
//  CollectionViewCell.swift
//  DispatchQueuePart2
//
//  Created by mac on 28/07/22.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet var imgCell: UIImageView!
    
}
