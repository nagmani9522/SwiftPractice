//
//  ViewController.swift
//  ConcurrencyPart1
//
//  Created by mac on 12/07/22.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
          queueTesting()
        
    }
    
    // Thread        // Task
    // Serial     +     Sync  - ORDER
    // Serial     +     Async - ORDER
    // Concurrent +     Sync  - ORDER
    // Concurrent +     Async - UNORDER
    
    func queueTesting(/*There is test Queue */){
        // This DispatchQueue is Serial Thread
        let myQueueSerial = DispatchQueue(label: "NagmaniKumar.serial.queue")
        // This DispatchQueue is Concurrent Thread
        let myQueueConcurrent = DispatchQueue(label: "NagmaniKumar.concurrent.queue",attributes: .concurrent)
        // for Testing And UnderStand How it Work
 //       SerialQueueSync()
 //       SerialQueueAsync()
 //       ConcurrentQueueSync()
        ConcurrentQueueAsync()
        // SerialQueueSync Code
        
        func SerialQueueSync(){
            // one Serial Sync Task
            myQueueSerial.sync {
                print("Serial Sync Task 1 started")
                // Do some work..
                for index in 1...5{
                    print("\(index) [TASK-1] time 5 is \(index * 5)")
                }
                print("Serial Sync Task 1 finished")
            }
            //Second Serial Sync Task
            myQueueSerial.sync {
                print("Serial Sync Task 2 started")
                // Do some work..
                for index in 1...3{
                    print("\(index) [TASK-2] time 5 is \(index * 5)")
                }
                print("Serial Sync Task 2 finished")
            }
        }
        // SerialQueueAsync Code
        func SerialQueueAsync(){
            // one Serial Async Task
            myQueueSerial.async {
                print("Serial Async Task 1 started")
                // Do some work..
                for index in 1...5{
                    print("\(index) [TASK-1] time 5 is \(index * 5)")
                }
                print("Serial Async Task 1 finished")
            }
            //Second Serial Async Task
            myQueueSerial.async {
                print("Serial Async Task 2 started")
                // Do some work..
                for index in 1...3{
                    print("\(index) [TASK-2] time 5 is \(index * 5)")
                }
                print("Serial Async Task 2 finished")
            }
        }
        // ConcurrentQueueSync Code
        func ConcurrentQueueSync(){
            // one Concurren Sync Task
            myQueueConcurrent.sync {
                print("Concurrent Sync Task 1 started")
                // Do some work..
                for index in 1...5{
                    print("\(index) [TASK-1] time 5 is \(index * 5)")
                }
                print("Concurrent Sync Task 1 finished")
            }
            //Second Concurren Sync Task
            myQueueConcurrent.sync {
                print("Concurrent Sync Task 2 started")
                // Do some work..
                for index in 1...3{
                    print("\(index) [TASK-2] time 5 is \(index * 5)")
                }
                print("Concurrent Sync Task 2 finished")
            }
        }
        // ConcurrentQueueAsync Code
        func ConcurrentQueueAsync(){
            // one Concurren Async Task
            myQueueConcurrent.async {
                print("Concurrent Async Task 1 started")
                // Do some work..
                for index in 1...5{
                    print("\(index) [TASK-1] time 5 is \(index * 5)")
                }
                print("Concurrent Async Task 1 finished")
            }
            //Second Concurren Async Task
            myQueueConcurrent.async {
                print("Concurrent Async Task 2 started")
                // Do some work..
                for index in 1...3{
                    print("\(index) [TASK-2] time 5 is \(index * 5)")
                }
                print("Concurrent Async Task 2 finished")
            }
            //Third Concurren Async Task
            myQueueConcurrent.async {
                print("Concurrent Async Task 3 started")
                // Do some work..
//                for index in 1...3{
//                    print("\(index) [TASK-3] time 5 is \(index * 5)")
//                }
                print("Concurrent Async Task 3 finished")
            }
        }
    }
}

