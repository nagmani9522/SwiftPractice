                                               THREADS
1.  You are probably heard the term multithreading at  some point, yes? A thread is really short for thread of execution, and it is how a running process splits takes across resources on the system. Your iOS app is a process that runs multiple tasks by utilising multiple threads. You can have as many threads executing at once as you have cores in your device’s CPU.

2. There are many advantages to splitting your app’s work into multiple threads:

3. Faster execution: By running tasks threads,  it is possible for work to be done concurrently, which will allow it to finish faster than running everything serially.

4. Responsiveness: if you only perform user-visible work on the main UI thread, then users will not notice that the app slows down or freezes up periodically due to work that could be performed on another thread.

5. Optimised resource consumption: Threads are highly optimised (to make the best possible use) by the OS.

6. Sounds great, right?More cores, more threads, faster app. I bet you are ready to learn how to create one, right? Too bad! In reality, you should never find yourself needing to create a thread explicitly. The  OS will handle all thread creation for you using higher abstractions.

Dispatch queues
1. The way you work with threads is by creating a DispatchQueue. When you create a queue, the OS will potentially create and assign one or more threads to the queue. If existing threads are available, they can  be reused; if not, then the OS will Create them as necessary.

2. Creating a dispatch queue is pretty simple on your part, as you can see in the example below:

                     let label =  “com. Company.app”
                     let queue = DispatchQueue(label: label)
3. The label argument simply needs to be any unique value for identification purposes. While you could simply use a UUID to guarantee uniqueness, it is best use a reverse- DNS style name, as shown above(e.g. com.company.app), since the label is what you will see when debugging and it is helpful to assign it meaningful text.

                                          The main queue
1. When your app starts, a main dispatch queue is automatically created for you. It is serial queue that is responsible for your UI. Because it is used so often, Apple has made it available as a class  variable, which you  access via DispatchQueue.main. You never want to execute something synchronously against the main queue, unless it is related to actual UI work. Otherwise, you will lock up your UI which Could potentially degrade your app performance.

2. If you recall from  the previous video, there are two types of dispatch queues: serial or concurrent. The default initialiser, as shown in the code above, will create a serial queue wherein each task must complete before the next task is able to start.

3. In order to create a concurrent queue, simply pass in the .concurrent attribute, like so:

4. Concurrent queues are so common that Apple has provided six different global concurrent queues, depending on the Quality of service (QoS) the queue should have.

                   let label =  “com. Company.app”
                   let queue = DispatchQueue(label: label, attributes: .concurrent)

                                       Quality of service(QoS)
1. When using a concurrent dispatch queue, you will need to know important the tasks are that get sent to the queue so that it can properly prioritise the work that needs to be done against all the other tasks that are clamouring for resources. Remember that higher-priority work has to be performed faster, likely taking more system resources to complete and requiring more energy than lower-priority work.

2. If you just need a concurrent queue but do not want to manage your own, you can use the global class method on DispatchQueue to get one of the pre-defined global queues:

            let queue = DispatchQueue.global(qos: .userInteractive)
1.  .userInteractive :-
The .userInteractive QoS is recommended for tasks that the user directly interacts with. UI-updating calculations, animations or anything needed to keep the UI responsive and fast. If the work does not happen quickly, things may appear to freeze. Tasks submitted to this queue should complete virtually instantaneously.

2. .userInitiated :-
The .userInitiated queue should be used when the user kicks off a task from the UI that needs to happen immediately, but can be done asynchronously. For example, you may need to open a document or read from a local database. If the user clicked a button, this is probably the queue you want.  Tasks performed in this queue should task a few seconds or less to complete.

3.  .utility :-
You will want want to use the .utility dispatch queue for tasks that would typically include a progress indicator such as long-running computations, I/O, networking or continuous data feeds. The system tries to balance responsiveness and performance with energy efficiency. Tasks can take a few seconds to a few minutes in this queue.

4.  .background :-
For tasks that the user is not directly aware of you should use the .background queue. They does not require user interaction and are not time sensitive. Prefetching, database maintenance, synchronising remote servers and performing backups are all great examples. The OS will focus on energy efficiency instead of speed. You  will want to use this queue for work that will take significant time, on the order of minutes or more.

(5. ,6.) .default and .unspecified (Never USE)
There are two other possible choice that exist, but you  should not use explicitly. There are a .default option, which falls between  .userInitiated and .utility and is the default value of the qos argument. It is not intended for you to directly use. The second option is .unspecified, and exists to support legacy APIs that may opt the thread out of a quality of service. It is good to know they exist, but if you are using them , you are almost certainly doing something wrong.

Note: Global queues are always concurrent and first-in, first-out.(FIFO)
——>.      if you create your own concurrent dispatch queue, you can tell the system what the QoS is via its initialiser:

        let queue = DispatchQueue(label: label, qos: .userInitiated, attributes: .concurrent)

                                       Adding task to queues
1. DispatchQueues provide both sync and async methods to add a task to a queue. Remember that, by task, I simply mean, “Whatever block of code you need to run. “ When your app starts, for example, you may need to contact your server to update the apps’s state. That’s not user initiated, doesn’t need to happen immediately and depends on networking I/O, so you should send it to the global utility queue:

DispatchQueue.global(qos: .utility).async { [weak self] in
guard let self = self else { return }
// Perform your work here
// ...
// Switch back to the main queue to
// update your UI
DispatchQueue.main.async {
self.textLabel.text = "Next Music available!"
}
}
