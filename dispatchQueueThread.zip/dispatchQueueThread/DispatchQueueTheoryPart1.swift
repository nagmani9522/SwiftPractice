
                      What is Concurrency?

1. Logic of Your app to determine which pieces can run at the same time , and possibly in  a random order ,yet still result  in a correct implementation of your data flow.

2. Moderns devices almost always have more than a single CPU, and Apple’s iPhones have been dual core since 2011. Having more than one core means they are capable of running more than a single task at the same time. By splitting your app into logical “chunks” of code you enable the iOS  device to run multiple parts of your program at the same time, thus improving overall performance.

                    Why use Concurrency?
1. It is Critical to ensure that your app runs as smoothly as possible and that end user is Not Ever Forced to Wait for something to happen.

2. However, if a human has to wait a second to see a response after taking an action on a device like an iPhone, it feels like an eternity. “It is too slow” is one of the main contributors to your app being uninstalled. It is true right?

3. Scrolling through a table of image is one of the more common situations where in the end user will be Impacted by the lack of concurrency.  If You need to download an image from the network, or perform some type of image processing before
Displaying it, the scrolling will stutter and you’ll be forced to display multiple “busy” indicators instead of the expected image.

4. A beneficial side effect to using concurrency is that it helps you to spend a bit more time thinking about your app’s overall architecture. Instead of just writing massive methods to “get the job done” you’ll find yourself naturally writing smaller, more manageable methods that can run concurrently.

                  How to use Concurrency?

1. I will  focus on the two main ways that iOS provides you with the ability to run code concurrently. First  is Grand Central Dispatch(GCD) will cover the common scenarios where you will find yourself being able to implement  concurrency.  You will learn how to run tasks in background, how to group tasks together and how to handle restricting the number of tasks that can run at once.
The Dispatch Queue and it’s quality of services are included in GCD

2. alternatively the Second you will focus on the Operation class. Built on top of GCD, operations allow for the handling of more complex scenarios such as reusable code to be run on a background thread, having one thread depend on another, and even canceling an operation before it is started or completed.


                Synchronous and asynchronous tasks

1. Work placed into the queue may either run synchronously or asynchronously. When running a task synchronously, your app will wait and block the current run loop until execution finishes before moving on to the next task. Alternatively, a task that is run asynchronously  will start, but return execution to your app immediately. This way, the app is free to run other tasks while the first one is executing.

2.  Note: it is important to keep in mind that, while the queues are FIFO based, that does not ensure that tasks will finish in the order you submit them. The FIFO procedure applies to when the task starts, not when it finishes.


                Serial and concurrent queues

1. The queue to which your task is submitted also has a characteristic of being either serial or concurrent. Serial queues only  have a single thread associated with them and thus only allow a single task to be executed at any given time. A concurrent queue, on the other hand, is able to utilise as many threads as the system has resources for. Threads will be created and released as necessary on a concurrent queue.
Serial is only one Thread Concurrent has Multiple Thread

2. Note:  while you can tell iOS that you could like to use a concurrent queue, remember that there is no guarantee that more than one task will run at a time. If your iOS device is completely bogged down and your app is completing for resources, it may only be capable of running a single task.


Asynchronous does not mean concurrent

1. While the difference seems subtle at first, just because your tasks are asynchronous does not mean they will run concurrently. You are actually  able to submit asynchronous tasks to either a serial queue or a concurrent queue. Being synchronous or asynchronous simply identifies whether or not the queue on which you are running the task must wait for the task to complete before it can spawn the next task.

2. On the other hand , categorizing something as serial versus concurrent identifies whether the queue has a single thread or multiple threads available to it. If you think about it, submitting three asynchronous tasks to a serial queue means that each task has to completely finish before the next task is able to start as there is only one thread available.

3. In other words, a task being synchronous or not speaks to the source of the task Being serial or concurrent speaks to the destination of the task.


