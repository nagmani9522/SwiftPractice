//
//  CollageFormViewController.swift
//  saveAndGetCollegeDataUsingCoreData
//
//  Created by mac on 21/11/21.
//

import UIKit

class CollageFormViewController: UIViewController {
    //MARK: outlets
    @IBOutlet weak var txtCollageName: UITextField!
    @IBOutlet weak var txtCollageUniversity: UITextField!
    @IBOutlet weak var txtCollageCity: UITextField!
    @IBOutlet weak var txtCollageAddress: UITextField!
    //mark: ViewLifecycles
    override func viewDidLoad() {
        super.viewDidLoad()
        _ = DatabaseHelper.Instance.getAllCollageData()
        // Do any additional setup after loading the view.
    }
}
//MARK: Action
extension CollageFormViewController{
    @IBAction func bnCollageSaveClick(_ sender: UIButton) {
        self.collageSaveData()
        self.navigationController?.popViewController(animated: true)
        
    }
}
//MARK: Method
extension CollageFormViewController{
    func collageSaveData(){
        guard txtCollageName.text != nil else{ return }
        guard txtCollageAddress.text != nil else{ return }
        guard txtCollageCity.text != nil else{ return }
        guard txtCollageUniversity.text != nil else{ return }
        let collageDict = ["collageName":txtCollageName.text,"collageAddress":txtCollageAddress.text,"collageCity":txtCollageCity.text,"collageUniversity":txtCollageUniversity.text]
        DatabaseHelper.Instance.saveCollageData(collagedict: collageDict as! [String:String])
    }
}
