//
//  collagedetailViewController.swift
//  saveAndGetCollegeDataUsingCoreData
//
//  Created by mac on 21/11/21.
//

import UIKit

class collagedetailViewController: UITableViewController{
    
    @IBOutlet weak var lblCollageName: UILabel!
    @IBOutlet weak var lblCollageAddress: UILabel!
    @IBOutlet weak var lblCollageCity: UILabel!
    @IBOutlet weak var lblCollageUniversity: UILabel!
    var collageDetail: Collage?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        lblCollageName.text = collageDetail?.name ?? ""
        lblCollageAddress.text = collageDetail?.address ?? ""
        lblCollageCity.text = collageDetail?.city ?? ""
        lblCollageUniversity.text = collageDetail?.university ?? ""
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
}
