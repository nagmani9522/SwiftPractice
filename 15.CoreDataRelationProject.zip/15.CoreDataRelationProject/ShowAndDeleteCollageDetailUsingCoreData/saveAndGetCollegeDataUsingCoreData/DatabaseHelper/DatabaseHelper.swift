//
//  DatabaseHelper.swift
//  saveAndGetCollegeDataUsingCoreData
//
//  Created by mac on 21/11/21.
//

import UIKit
import CoreData
class DatabaseHelper: NSObject {
     static let Instance = DatabaseHelper()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    func saveCollageData(collagedict:[String:String]){
        let collage = NSEntityDescription.insertNewObject(forEntityName: "Collage", into: context) as! Collage
        collage.name = collagedict["collageName"]
        collage.address = collagedict["collageAddress"]
        collage.city = collagedict["collageCity"]
        collage.university = collagedict["collageUniversity"]
        do{
            try context.save()
        }catch let error{
            print(error.localizedDescription)
        }
    }
    func getAllCollageData() -> [Collage]{
        var arrCollage = [Collage]()
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Collage")
        do{
            arrCollage = try context.fetch(fetchRequest) as! [Collage]
        }catch let error{
            print(error.localizedDescription)
        }
        return arrCollage
    }
    func deleteData(index: Int) -> [Collage]{
        var arrCollage = getAllCollageData() // getdata
        context.delete(arrCollage[index])  // remove from core data
        arrCollage.remove(at: index)  // remove in array collage
        do{
            try context.save()
        }catch let error{
            print("delete collage data :- \(error.localizedDescription)")
        }
        return arrCollage
    }
}
