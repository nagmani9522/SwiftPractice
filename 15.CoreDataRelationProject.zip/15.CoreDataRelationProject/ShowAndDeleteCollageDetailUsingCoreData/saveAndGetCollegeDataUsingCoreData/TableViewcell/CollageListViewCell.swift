//
//  CollageListViewCell.swift
//  saveAndGetCollegeDataUsingCoreData
//
//  Created by mac on 21/11/21.
//

import UIKit

class CollageListViewCell: UITableViewCell {

    @IBOutlet weak var lblCollageName: UILabel!
    @IBOutlet weak var lblCollageAddress: UILabel!
    @IBOutlet weak var lblCollageCity: UILabel!
    @IBOutlet weak var lblCollageUniversity: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    //MARK: DataSave
    var Collagelist: Collage?{
        didSet{
            lblCollageName.text = "Name: \(Collagelist?.name ?? "")"
            lblCollageAddress.text = "Address: \(Collagelist?.address ?? "")"
            lblCollageCity.text = "City: \(Collagelist?.city ?? "")"
            lblCollageUniversity.text = "University: \(Collagelist?.university ?? "")"
        }
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
