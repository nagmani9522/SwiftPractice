//
//  Collage+CoreDataClass.swift
//  saveAndGetCollegeDataUsingCoreData
//
//  Created by mac on 21/11/21.
//
//

import Foundation
import CoreData

@objc(Collage)
public class Collage: NSManagedObject {

}
