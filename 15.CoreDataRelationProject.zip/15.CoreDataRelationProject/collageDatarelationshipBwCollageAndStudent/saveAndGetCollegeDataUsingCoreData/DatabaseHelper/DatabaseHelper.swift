//
//  DatabaseHelper.swift
//  saveAndGetCollegeDataUsingCoreData
//
//  Created by mac on 21/11/21.
//

import UIKit
import CoreData
class DatabaseHelper: NSObject {
     static let Instance = DatabaseHelper()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    //MARK: CollageData
    func saveCollageData(collagedict:[String:String]){
        let collage = NSEntityDescription.insertNewObject(forEntityName: "Collage", into: context) as! Collage
        collage.name = collagedict["collageName"]
        collage.address = collagedict["collageAddress"]
        collage.city = collagedict["collageCity"]
        collage.university = collagedict["collageUniversity"]
        do{
            try context.save()
        }catch let error{
            print(error.localizedDescription)
        }
    }
    func getAllCollageData() -> [Collage]{
        var arrCollage = [Collage]()
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Collage")
        do{
            arrCollage = try context.fetch(fetchRequest) as! [Collage]
        }catch let error{
            print(error.localizedDescription)
        }
        return arrCollage
    }
    func deleteData(index: Int) -> [Collage]{
        var arrCollage = getAllCollageData() // getdata
        context.delete(arrCollage[index])  // remove from core data
        arrCollage.remove(at: index)  // remove in array collage
        do{
            try context.save()
        }catch let error{
            print("delete collage data :- \(error.localizedDescription)")
        }
        return arrCollage
    }
    func editData(collagedict:[String:String],index:Int){
        let collage = self.getAllCollageData()
        collage[index].name = collagedict["collageName"]
        collage[index].address = collagedict["collageAddress"]
        collage[index].city = collagedict["collageCity"]
        collage[index].university = collagedict["collageUniversity"]
        do{
            try context.save()
        }catch let error{
            print(error.localizedDescription)
        }
    }
    //MARK: StudentData
    func saveStudentData(studentdict:[String:String],collage:Collage){
        let student = NSEntityDescription.insertNewObject(forEntityName: "Student", into: context) as! Student
        student.name = studentdict["studentName"]
        student.email = studentdict["studentEmail"]
        student.phone = studentdict["studentPhone"]
        student.universities = collage
        do{
            try context.save()
        }catch let error{
            print(error.localizedDescription)
        }
    }
    func getAllstudenteData() -> [Student]{
        var arrStudent = [Student]()
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Student")
        do{
            arrStudent = try context.fetch(fetchRequest) as! [Student]
        }catch let error{
            print(error.localizedDescription)
        }
        return arrStudent
    }
}
