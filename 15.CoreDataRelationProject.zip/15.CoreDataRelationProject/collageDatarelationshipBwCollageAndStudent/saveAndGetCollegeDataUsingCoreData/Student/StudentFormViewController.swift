//
//  StudentFormViewController.swift
//  saveAndGetCollegeDataUsingCoreData
//
//  Created by mac on 21/11/21.
//

import UIKit

class StudentFormViewController: UIViewController {
    //MARK: Outlets
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPhone: UITextField!
    //MARK: Properties
    var collage:Collage?
    //MARK: LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    //MARK: ButtonAction
    @IBAction func btnSaveclick(_ sender: UIButton) {
        guard let name = txtName.text else {return}
        guard let email = txtEmail.text else {return}
        guard let phone = txtPhone.text else {return}
        guard let maincollage = collage else {return}
        let studentDict = [
            "studentName":name,
            "studentEmail":email,
            "studentPhone":phone
        ]
        DatabaseHelper.Instance.saveStudentData(studentdict: studentDict, collage: maincollage)
    }
  
}
