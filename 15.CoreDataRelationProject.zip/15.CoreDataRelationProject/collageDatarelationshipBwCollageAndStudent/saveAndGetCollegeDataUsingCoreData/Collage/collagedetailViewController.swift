//  collagedetailViewController.swift
//  saveAndGetCollegeDataUsingCoreData
//
//  Created by mac on 21/11/21.

import UIKit
class collagedetailViewController: UITableViewController{
    //MARK: Outlets
    @IBOutlet weak var lblCollageName: UILabel!
    @IBOutlet weak var lblCollageAddress: UILabel!
    @IBOutlet weak var lblCollageCity: UILabel!
    @IBOutlet weak var lblCollageUniversity: UILabel!
    @IBOutlet weak var lblStudents: UILabel!
    // MARK: Property
    var collageDetail: Collage?
    var indexRow = Int()
    //MARK: ViewControllerLifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        lblCollageName.text = collageDetail?.name ?? ""
        lblCollageAddress.text = collageDetail?.address ?? ""
        lblCollageCity.text = collageDetail?.city ?? ""
        lblCollageUniversity.text = collageDetail?.university ?? ""
        if let arrstudents = collageDetail?.students?.allObjects as? [Student]{
            lblStudents.text = "\(arrstudents.count)"
        }else{
            lblStudents.text = "0"
        }
    }
    //MARK: Action
    @IBAction func btnEdit(_ sender: UIBarButtonItem) {
        let FormVC = self.storyboard?.instantiateViewController(withIdentifier: "CollageFormViewController") as! CollageFormViewController
        FormVC.isUpdate = true
        FormVC.collageDetails = collageDetail
        FormVC.IndexRow = indexRow
        self.navigationController?.pushViewController(FormVC, animated: true)
    }
    //MARK: TableView
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 4{
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let studentListVC = storyboard.instantiateViewController(withIdentifier: "StudentListViewController") as! StudentListViewController
            studentListVC.collage = collageDetail
            self.navigationController?.pushViewController(studentListVC, animated: true)
            
        }
    }
}
