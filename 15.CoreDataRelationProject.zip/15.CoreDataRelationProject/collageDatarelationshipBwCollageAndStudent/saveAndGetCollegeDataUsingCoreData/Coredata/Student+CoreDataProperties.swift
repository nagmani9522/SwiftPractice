//
//  Student+CoreDataProperties.swift
//  saveAndGetCollegeDataUsingCoreData
//
//  Created by mac on 27/11/21.
//
//

import Foundation
import CoreData


extension Student {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Student> {
        return NSFetchRequest<Student>(entityName: "Student")
    }

    @NSManaged public var email: String?
    @NSManaged public var name: String?
    @NSManaged public var phone: String?
    @NSManaged public var universities: Collage?

}

extension Student : Identifiable {

}
