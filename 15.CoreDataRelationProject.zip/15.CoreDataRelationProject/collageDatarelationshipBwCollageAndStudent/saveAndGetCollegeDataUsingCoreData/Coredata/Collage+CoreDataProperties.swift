//
//  Collage+CoreDataProperties.swift
//  saveAndGetCollegeDataUsingCoreData
//
//  Created by mac on 21/11/21.
//
//

import Foundation
import CoreData


extension Collage {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Collage> {
        return NSFetchRequest<Collage>(entityName: "Collage")
    }

    @NSManaged public var name: String?
    @NSManaged public var address: String?
    @NSManaged public var city: String?
    @NSManaged public var university: String?
    @NSManaged public var students: NSSet?
}

extension Collage : Identifiable {

}
