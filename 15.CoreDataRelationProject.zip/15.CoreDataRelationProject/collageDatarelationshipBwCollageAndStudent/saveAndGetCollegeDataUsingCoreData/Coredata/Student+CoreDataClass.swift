//
//  Student+CoreDataClass.swift
//  saveAndGetCollegeDataUsingCoreData
//
//  Created by mac on 27/11/21.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {

}
