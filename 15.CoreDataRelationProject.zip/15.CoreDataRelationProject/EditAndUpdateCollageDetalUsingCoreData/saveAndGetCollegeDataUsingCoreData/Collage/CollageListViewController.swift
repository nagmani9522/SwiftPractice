//
//  ViewController.swift
//  saveAndGetCollegeDataUsingCoreData
//
//  Created by mac on 21/11/21.
//

import UIKit

class CollageListViewController: UIViewController {
    //MARK: Outlet
    @IBOutlet weak var collageListTblView: UITableView!
    //MARK: Property(
    var data = [Collage]()
    //MARK: LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        let data = DatabaseHelper.Instance.getAllCollageData()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        self.data = DatabaseHelper.Instance.getAllCollageData()
            self.collageListTblView.reloadData()
    }
// MARK: Action
    @IBAction func btnCollageAndClick(_ sender: UIBarButtonItem) {
        let collageForm = self.storyboard?.instantiateViewController(withIdentifier: "CollageFormViewController") as! CollageFormViewController
        self.navigationController?.pushViewController(collageForm, animated: true)
    }
    
}
//MARK: TableView
extension CollageListViewController: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CollageListViewCell") as! CollageListViewCell
        cell.Collagelist = data[indexPath.row]
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 140
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            data = DatabaseHelper.Instance.deleteData(index: indexPath.row)
            self.collageListTblView.deleteRows(at: [indexPath], with: .automatic)
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let CollageDetail = self.storyboard?.instantiateViewController(withIdentifier: "collagedetailViewController") as! collagedetailViewController
        CollageDetail.collageDetail = data[indexPath.row]
        CollageDetail.indexRow = indexPath.row
        self.navigationController?.pushViewController(CollageDetail, animated: true)
    }
}

