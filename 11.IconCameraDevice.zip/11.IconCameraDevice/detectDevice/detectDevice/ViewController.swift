//
//  ViewController.swift
//  detectDevice
//
//  Created by mac on 29/10/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        detectDevice()
        // Do any additional setup after loading the view.
    }
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        if UIDevice.current.orientation.isLandscape{
            print("landscape")
            imageView.image = #imageLiteral(resourceName: "outlook")
        }
        else{
            print("protrate mode")
            imageView.image = #imageLiteral(resourceName: "gmail")
        }
    }
    func detectDevice(){
        if UIDevice().userInterfaceIdiom == .phone{
            switch UIScreen.main.nativeBounds.height{
            case 1136:
                print("iphone 5 or 5s or 5c")
            case 1334:
                print("iphone 6/6s/7/8")
            case 1920, 2208:
                print("iphone Plus")
            case 2436:
                print("iphone X")
            default:
                print("unknow iphone")
            }
        }
        else if UIDevice().userInterfaceIdiom == .pad{
            switch UIScreen.main.nativeBounds.height{
            case 2048:
                print("ipad mini 4 or 9.7''ipad")
            case 2224:
                print("10.5''ipad pro")
            case 2732:
                print("12.9'' ipad pro ")
            default:
                print("unknow ipad")
            }
        }
    }
}

