//
//  ViewController.swift
//  DetectpermissionofCamera
//
//  Created by mac on 28/10/21.
//

import UIKit
import AVFoundation
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttion(_ sender: UIButton) {
        self.checkcamerapermission()
    }
    
}
extension ViewController: UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    func PresentCamaraSetting(){
        let alertController = UIAlertController(title: "error", message: "camera access denied", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "cancle", style: .default))
        alertController.addAction(UIAlertAction(title: "Setting", style: .cancel){_ in
            if let url = URL(string: UIApplication.openSettingsURLString){
                UIApplication.shared.open(url,options: [:],completionHandler: {_ in })
            }
        })
        present(alertController, animated: true)
        print("camera")
    }
    func checkcamerapermission(){
        let authststus = AVCaptureDevice.authorizationStatus(for: .video)
       switch authststus {
       case .denied:
        print("denied")
        self.PresentCamaraSetting()
        break
       case .authorized:
        print("authorised")
        self.callCamera()
        break
       case .restricted:
        print("restricted")
        break
       case .notDetermined:
        AVCaptureDevice.requestAccess(for: .video){(success) in
            if success{
                print("pemission granted")
            }
            else{
                print("permission not granted")
            }
        }
        break
       }
    }
    func callCamera(){
        let mypickerController = UIImagePickerController()
        mypickerController.delegate = self;
        mypickerController.sourceType = UIImagePickerController.SourceType.camera
        self.present(mypickerController,animated: true,completion:nil)
    }
}
