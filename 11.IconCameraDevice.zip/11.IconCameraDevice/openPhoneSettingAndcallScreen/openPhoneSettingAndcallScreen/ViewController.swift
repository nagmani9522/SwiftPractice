//
//  ViewController.swift
//  openPhoneSettingAndcallScreen
//
//  Created by mac on 28/10/21.
//

import UIKit
import MessageUI
class ViewController: UIViewController, MFMailComposeViewControllerDelegate {
    
    var i = 1
    fileprivate let application = UIApplication.shared
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
    }
    override func viewWillDisappear(_ animated: Bool) {
        
    }
    override func viewDidAppear(_ animated: Bool) {
        
            if let settingURL = URL(string: UIApplication.openSettingsURLString){
                //application.open(settingURL, options: [:], completionHandler: nil)
                application.open(settingURL,options: [:]){_ in
                    
                }
            }
    }
    @IBAction func settingBtn(_ sender: UIButton) {
        while i == 1 {
        if let settingURL = URL(string: UIApplication.openSettingsURLString){
            //application.open(settingURL, options: [:], completionHandler: nil)
            application.open(settingURL,options: [:]){_ in
              //code here
            }
        }
    }
    }
    @IBAction func callBtn(_ sender: UIButton) {
            if let phoneUrl = URL(string: "tel://0123456789"){
               application.open(phoneUrl, options: [:], completionHandler: nil)
               if application.canOpenURL(phoneUrl){
                   application.open(phoneUrl, options: [:], completionHandler: nil)
               }
               else{
                   print("alert not phone facilitty")
               }
        }
    }
    
    @IBAction func smsBtn(_ sender: AnyObject) {
        
    }
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
            controller.dismiss(animated: true)
        }
}
