//
//  MapApp.swift
//  MapApplication
//
//  Created by mac on 28/10/21.
import Foundation
import UIKit
import CoreLocation
import  MapKit
public enum PazNavigationApp {
    case AppleMaps
    case GoogleMaps
    case Waze
    
    // shortcut to access every value of possible navigation app
    public static let AllValues: [PazNavigationApp] = [.AppleMaps, .GoogleMaps, .Waze]
    
    // property that returns only navigation apps that the user has installed
    public static var AvailableServices: [PazNavigationApp] {
        return self.AllValues.filter { app in app.available }
    }
    
    // name of each app as it will appear on the Alert's options
    public var name: String {
        switch self {
        case .AppleMaps:
            return "Apple Maps"
        case .GoogleMaps:
            return "Google Maps"
        case .Waze:
            return "Waze"
        }
    }
    
    // base of URL used to open the navigation app
    public var urlString: String {
        switch self {
        case .AppleMaps:
            return "http://maps.apple.com"
        case .GoogleMaps:
           
            return "comgooglemaps://"
        case .Waze:
           // return "waze://"
            return "https://waze.com/"
        }
    }
    
    // auxiliar property to transform a string into an URL
    public var url: URL? {
        return URL(string: self.urlString)
    }
    
    // property that checks if a given app is installed
    public var available: Bool {
        guard let url = self.url else {
            return false
        }
        return UIApplication.shared.canOpenURL(url)
    }
    
    /* func to get the full URL (in string version)
     necessary to open the navigation app on the desired coordinates */
    public func directionsUrlString(address: String) -> String {
        
        var urlString = self.urlString
        
        switch self {
        case .AppleMaps:
            urlString.append("?q=\(address)")
            
        case .GoogleMaps:
            urlString.append("?q=\(address)")
            
        case .Waze:
            urlString.append("ul?q=\(address)")
        }
        
        let urlwithPercentEscapes =
            urlString.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? urlString
        
        return urlwithPercentEscapes
    }
    
    // wrapper func to turn a string into an URL object
    public func directionsUrl(address: String) -> URL? {
        let urlString = self.directionsUrlString(address: address)
        return URL(string: urlString)
    }
    
    /* func that tries to open a navigation app on a specific set of coordinates
     and informs it's callback if it was successful */
    public func openWithDirections(address: String,
                                   completion: ((Bool) -> Swift.Void)? = nil) {
        
        // Apple Maps can be opened differently than other navigation apps
        
        guard let url = self.directionsUrl(address: address) else {
            completion?(false)
            return
        }
        
        // open the app with appropriate method for your target iOS version
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(url, options: [:], completionHandler: {
                (success) in
                print("Open \(url.absoluteString): \(success)")
                completion?(success)
            })
        } else {
            let success = UIApplication.shared.openURL(url)
            completion?(success)
        }
    }
    
    
    
}


class MapAppFinder: NSObject{
    
   static let shareInstance = MapAppFinder()
    
    /* func to create an Alert where the options
     are the available navigation apps on the user's device.
     The callback informs if the operation was successful */
     @objc func directionsAlertController(address: String,
                                                 completion: ((Bool) -> ())? = nil)
        -> UIAlertController {
            
            let directionsAlertView = UIAlertController(title: nil,
                                                        message: nil,
                                                        preferredStyle: .actionSheet)
            
            for navigationApp in PazNavigationApp.AvailableServices {
                
                let action = UIAlertAction(title: navigationApp.name,
                                           style: UIAlertAction.Style.default,
                                           handler: { action in
                                            navigationApp.openWithDirections(address: address,
                                                                             completion: completion)
                })
                
                directionsAlertView.addAction(action)
            }
            
            let cancelAction = UIAlertAction(title: "Cancel",
                                             style: UIAlertAction.Style.cancel,
                                             handler: { action in completion?(false) })
            
            directionsAlertView.addAction(cancelAction)
            
            return directionsAlertView
    }
    
}
