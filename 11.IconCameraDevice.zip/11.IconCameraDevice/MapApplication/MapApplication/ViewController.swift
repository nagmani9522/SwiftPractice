//
//  ViewController.swift
//  MapApplication
//
//  Created by mac on 28/10/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtAddress: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func btnMapClick(_ sender: UIButton) {
        self.present(MapAppFinder.shareInstance.directionsAlertController(address: txtAddress.text!, completion: nil), animated: true,completion: nil)
    }
    
}

