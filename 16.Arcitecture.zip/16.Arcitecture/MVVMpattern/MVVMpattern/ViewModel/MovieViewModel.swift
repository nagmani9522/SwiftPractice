//
//  MovieViewModel.swift
//  MVVMpattern
//
//  Created by mac on 03/04/22.
//

import UIKit

class MovieViewModel: NSObject {
    var artistName: String?
    var trackName: String?
    
    //MARK: Dependency Injuction (DI)
    
    init(movie:MoveModel){
        self.artistName = movie.artistName
        self.trackName = movie.trackName
    }
}
