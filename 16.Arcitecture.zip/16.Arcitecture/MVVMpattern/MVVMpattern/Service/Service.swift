//
//  Service.swift
//  MVVMpattern
//
//  Created by mac on 03/04/22.
//

import UIKit

class Service: NSObject {
    static let shareInstance =  Service()
    func getAllMoveData(completion:@escaping([MoveModel]?,Error?) -> ()){
       let urlString = "https://itunes.apple.com/search?media=music&term=bollywood"
        guard let url = URL(string: urlString)else {return}
        URLSession.shared.dataTask(with: url){ (data,response,error) in
            if let err = error{
                print("Loding data error: \(err.localizedDescription)")
            }else{
                guard let data =  data else{return}
                do{
                    var arrMovieData = [MoveModel]()
                    
                    let results = try JSONDecoder().decode(resultsModel.self, from: data)
                    for movie in results.results{
                        arrMovieData.append(MoveModel(artistName: movie.artistName ?? "", trackName: movie.trackName ?? ""))
                    }
                    completion(arrMovieData, nil)
                }catch let jsonError{
                    print("Json error \(jsonError.localizedDescription)")
                }
            }
        }.resume()
       
    }
}
