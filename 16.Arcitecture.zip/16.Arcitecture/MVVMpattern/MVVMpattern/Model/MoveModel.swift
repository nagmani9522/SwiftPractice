//
//  MoveModel.swift
//  MVVMpattern
//
//  Created by mac on 03/04/22.
//

import UIKit

class MoveModel: NSObject,Decodable {
    var artistName: String?
    var trackName: String?
    init(artistName:String,trackName:String){
        self.artistName = artistName
        self.trackName = trackName
    }
}
class resultsModel:NSObject,Decodable{
    var results = [MoveModel]()
    init(results:[MoveModel]){
        self.results = results
    }
}
