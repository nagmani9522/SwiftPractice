//
//  ViewController.swift
//  MVVMpattern
//
//  Created by mac on 03/04/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var tblView: UITableView!
    var arrMoveVM = [MovieViewModel]()
    override func viewDidLoad() {
        super.viewDidLoad()
        getData()
    }
    func getData(){
        Service.shareInstance.getAllMoveData{(movies,error) in
            if error == nil{
                self.arrMoveVM = movies?.map({ return MovieViewModel(movie: $0)}) ?? []
                DispatchQueue.main.async {
                    self.tblView.reloadData()
                }
            }
        }
    }
}
extension ViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrMoveVM.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let MVM = arrMoveVM[indexPath.row]
        cell.textLabel?.text = MVM.artistName ?? ""
        cell.detailTextLabel?.text = MVM.trackName ?? ""
        return cell
    }
    
    
}
