//
//  UserCell.swift
//  MVVMAlamofireJson
//
//  Created by mac on 02/01/22.
//

import UIKit

class UserCell: UITableViewCell {
    @IBOutlet weak var lblId: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblStatus: UILabel!
    var modelUser: UserModel?{
        didSet{
            userConfiguration()
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func userConfiguration(){
        let status = modelUser?.getStatusAndColor()
        lblStatus.text = status?.0
        lblStatus.backgroundColor = status?.1
        //backgroundColor = status?.1
        lblId.text = "\((modelUser?.id)!)"
        lblTitle.text =  modelUser?.title
    }
}
