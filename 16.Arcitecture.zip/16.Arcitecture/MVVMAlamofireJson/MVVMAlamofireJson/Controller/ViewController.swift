//
//  ViewController.swift
//  MVVMAlamofireJson
//
//  Created by mac on 02/01/22.

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var tblView: UITableView!
    var ViewModelUser = UserViewModel()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //tblView.register(UserCell.self, forCellReuseIdentifier: "UserCell")
        tblView.register(UINib(nibName: "UserCell", bundle: nil), forCellReuseIdentifier: "UserCell")
        ViewModelUser.vc = self
        //MARK: without Alamofire Using Data
//        ViewModelUser.getAllUserData()
        //MARK: with Alamofire Using Data
        ViewModelUser.getAllUserDataAF()
    }
}
extension ViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        ViewModelUser.arrUsers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "UserCell",for: indexPath) as! UserCell
        let modelUser = ViewModelUser.arrUsers[indexPath.row]
//        let status = modelUser.getStatusAndColor()
//        cell.lbllblStatus.text = status.0
//        cell.lbllblStatus.backgroundColor = status.1
//        //cell.backgroundColor = status.1
//        cell.lblId.text = "\(modelUser.id!)"
//        cell.lblTitle.text =  modelUser.title
        cell.modelUser = modelUser
        //cell.userConfiguration()
        return cell
    }
    
    
}
