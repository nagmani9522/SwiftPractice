//
//  ViewController.swift
//  MVCpattern
//
//  Created by mac on 02/04/22.
//

import UIKit

class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    var arrdata = [AmazonModel]()
    override func viewDidLoad() {
        super.viewDidLoad()
        arrdata = AmazonData.getAllAmazonData()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        arrdata.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        // MARK: SimpleCollectionView cell
//        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:"AmazonwAppell", for: indexPath) as! AmazonwAppell
//        cell.img.image = arrdata[indexPath.row].img
//        cell.lbl.text = arrdata[indexPath.row].tittleStr
        // MARK: CollectionView cell same as cell identifire
//        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:AmazonwAppell.identifire, for: indexPath) as! AmazonwAppell
//        cell.AmazonData = arrdata[indexPath.row]
        // MARK: CollectionView cell identifireConstant As DifferentModule
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:Identifire.Collectioncell, for: indexPath) as! AmazonwAppell
        cell.AmazonData = arrdata[indexPath.row]
        return cell
    }
   

}
