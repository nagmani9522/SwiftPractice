//
//  AmazonModel.swift
//  MVCpattern
//
//  Created by mac on 02/04/22.
//

import Foundation
import UIKit
struct AmazonModel{
    let img: UIImage
    let tittleStr:String
    
}
