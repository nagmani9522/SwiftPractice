//
//  Constant.swift
//  MVCpattern
//
//  Created by mac on 03/04/22.
//

import Foundation
import UIKit
// MARK: Identifire
struct Identifire{
    static let Collectioncell = "AmazonwAppell"
}
