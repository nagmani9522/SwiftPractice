//
//  AmazonData.swift
//  MVCpattern
//
//  Created by mac on 02/04/22.
//

import Foundation
import UIKit
class AmazonData{
    static func getAllAmazonData() -> [AmazonModel]{
        var arrData = [AmazonModel]()
        arrData = [
            AmazonModel.init(img: #imageLiteral(resourceName: "whatsapp"),tittleStr: "WhatsApp"),
            AmazonModel.init(img: #imageLiteral(resourceName: "fbMessenger"),tittleStr: "Messanger"),
            AmazonModel.init(img: #imageLiteral(resourceName: "instagram"),tittleStr: "Instagram"),
            AmazonModel.init(img: #imageLiteral(resourceName: "message"),tittleStr: "Chat")
        ]
        return arrData

    }
}
