//
//  AmazonwAppell.swift
//  MVCpattern
//
//  Created by mac on 02/04/22.
//

import UIKit

class AmazonwAppell: UICollectionViewCell {
    @IBOutlet var img: UIImageView!
    @IBOutlet var lbl: UILabel!
    var AmazonData:AmazonModel?{
        didSet{
            img.image = AmazonData?.img
            lbl.text = AmazonData?.tittleStr
        }
    }
}
// MARK: CollectionView identifire name As collectionView name
//extension UICollectionViewCell{
//    static var identifire:String{
//        return String(describing: self)
//    }
//}
//MARK: CollectionView identifire name notAS collectionView name
//extension AmazonwAppell{
//    static var identifire:String{
//        return String(describing: "AmazonwAppell")
//    }
//}
