//
//  Extension+UI_Collection.swift
//  ReduceCodeExtension
//
//  Created by mac on 03/04/22.
//

import Foundation
import UIKit
extension UIViewController{
    func popupAlert(title:String,message:String,actionTitle:[String],action:[((UIAlertAction) -> Void)]){
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        for(index,title) in actionTitle.enumerated(){
            let action = UIAlertAction(title: title, style: .default, handler: action[index])
            alert.addAction(action)
            
        }
        self.present(alert, animated: true,completion: nil)
    }
    func hideKeyboardTappedAround(){
        let tap = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    @objc func dismissKeyboard(){
        view.endEditing(true)
    }
}
