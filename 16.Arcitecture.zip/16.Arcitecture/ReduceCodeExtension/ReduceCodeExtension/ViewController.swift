//
//  ViewController.swift
//  ReduceCodeExtension
//
//  Created by mac on 03/04/22.
//

import UIKit
struct Person{
    let first:String
    let last:String
}
class ViewController: UIViewController {
    @IBOutlet var btnAlert: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        var dict = [String:String]()
//        dict["first"] = "Nagmani"
//        dict["last"] = "Kumar"
//        let Name = Person(dictionary:dict)
//        print(Name.last)
        let Name = Person(dictionary:dict)
        print(Name.last)
        hideKeyboardTappedAround()
        let newString = "the old bike".replace(target: "old", withString: "New")
        print(newString)
    }
    @IBAction func btnAlertAction(_ sender: UIButton) {
        popupAlert(title: "iDispatch", message: "This user is not verified User", actionTitle: ["OK","Cancle"], action: [
            { ok in
                print("ok")
                
            },{ cancle in
                print("cancle")
                
            }
        
        ])
        
    }
    
}
extension Person{
    init(dictionary:[String:String]){
        self.first = dictionary["first"] ?? "defaultfirstname"
        self.last = dictionary["last"] ?? "defaultlastname"
    }
}
extension String{
    func replace(target:String,withString:String) -> String{
        return self.replacingOccurrences(of: target, with: withString)
    }
}
