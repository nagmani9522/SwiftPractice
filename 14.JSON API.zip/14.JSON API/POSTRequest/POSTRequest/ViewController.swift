//
//  ViewController.swift
//  POSTRequest
//
//  Created by mac on 19/12/21.
//

import UIKit
class ViewController: UIViewController {
    @IBOutlet weak var TxtUID: UITextField!
    @IBOutlet weak var TxtTittle: UITextField!
    @IBOutlet weak var TxtBody: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func setupPostMethod(_ sender: UIButton) {
        setupPostMethod()
    }
    
}
extension ViewController{
    func setupPostMethod(){
        guard let uid = self.TxtUID.text else{return}
        guard let tittle = self.TxtTittle.text else{return}
        guard let body = self.TxtBody.text else{return}
        if let url = URL(string: "https://dl.dropboxusercontent.com/s/p57gxwqm84zkp96/demo_api.json"){
            var request = URLRequest(url: url)
      //MARK: POST API
        
        //https://jsonplaceholder.typicode.com/posts/
//            request.httpMethod = "POST"
//            let parameters: [String:Any] = [
//                "userId": uid,
//                "tittle": tittle,
//                "body": body
//            ]
//            request.httpBody = parameters.percentEscaped().data(using: .utf8)
            //MARK: GET API
            request.httpMethod = "GET"
            URLSession.shared.dataTask(with: request){ (data, response, error) in
                guard let data = data else {
                    if error == nil{
                        print(error?.localizedDescription ?? "Unknown Error")
                    }
                    return
                }
                if let response = response as? HTTPURLResponse{
                    guard(200 ... 299) ~= response.statusCode else{
                        print("Status code :- \(response.statusCode)")
                        print(response)
                        return
                    }
                }
                do{
                    let json = try JSONSerialization.jsonObject(with: data, options: [])
                    print(json)
                }catch let error{
                    print(error.localizedDescription)
                }
            }.resume()
        }
    }
    
}
extension Dictionary {
    func percentEscaped() -> String {
        return map { (key, value) in
            let escapedKey = "\(key)".addingPercentEncoding(withAllowedCharacters: .urlQueryValueAllowed) ?? ""
            let escapedValue = "\(value)".addingPercentEncoding(withAllowedCharacters: .urlQueryValueAllowed) ?? ""
            return escapedKey + "=" + escapedValue
        }
        .joined(separator: "&")
    }
}
extension CharacterSet {
    static let urlQueryValueAllowed: CharacterSet = {
    let generalDelimitersToEncode = ":#[]@" // dose not include "?" or "/" due to  RFC 3986 - Section 3.4
    let subDelimitersToEncode = "!$&'()*+,;="
        var allowed = CharacterSet.urlQueryAllowed
        allowed.remove(charactersIn: "\(generalDelimitersToEncode)\(subDelimitersToEncode)")
        return allowed
    }()
}
