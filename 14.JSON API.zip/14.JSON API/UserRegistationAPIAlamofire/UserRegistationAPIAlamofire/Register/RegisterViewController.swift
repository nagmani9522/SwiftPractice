//
//  SignUpController.swift
//  UserRegistationAPIAlamofire
//
//  Created by mac on 08/01/22.
//

import UIKit
class RegisterViewController: UIViewController {
    //MARK:Outlet
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var txtFname: UITextField!
    @IBOutlet weak var txtLname: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    //MARK:AppLife Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.roundCorners(view: topView, corners: [.topLeft, .topRight], radius: 40.0)
    }
    //MARK: Function
    func roundCorners(view :UIView, corners: UIRectCorner, radius: CGFloat){
        let path = UIBezierPath(roundedRect: view.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        view.layer.mask = mask
    }
}
//MARK: Extension
extension RegisterViewController{
    @IBAction func signUpAction(_ sender: UIButton) {
        guard let fname = self.txtFname.text else {return}
        guard let lname = self.txtLname.text else {return}
        guard let email = self.txtEmail.text else {return}
        guard let password = self.txtPassword.text else {return}
//        let register = RegisterModel.init(name: fname+lname,email: email, password: password)
        let register = RegisterModel(name: fname+lname,email: email, password: password)
        APIManager.shareInstance.callingRegisterAPI(register: register)
        //Common.showError(.success, Appname, Message)
        let alertController = UIAlertController(title: Appname, message: Message, preferredStyle: UIAlertController.Style.alert)
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default,handler: { action in
            
        }))
        self.present(alertController, animated: true, completion: nil)
    }
    @IBAction func loginAction(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
        
    }
}
extension RegisterViewController{
    static func sharedInstance() -> RegisterViewController{
       return RegisterViewController.instantiateFromStoryboard("Register")
    }
}
//extension RegisterViewController:UIImagePickerControllerDelegate,UINavigationControllerDelegate{
//    func imageTapped(){
//        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary){
//            let imgPicker = UIImagePickerController()
//            imgPicker.delegate = self
////            imgPicker.sourceType = sourceType
////                    self.imgPicker = imgPicker
//                    DispatchQueue.main.async {
//                        self.present(imgPicker, animated: true, completion: nil)
//                    }
//        }
//    }
//}
