//
//  Constant.swift
//  UserRegistationAPIAlamofire
//
//  Created by mac on 09/01/22.
//

import Foundation
//MARK: Api Common
let  app_id = "47B92CED-275A-8BE2-FF85-10F38F91EF00"
let rest_key = "B07DF822-133F-4761-B1E8-1735D5C5B254"
let base_url = "https://xxxx.backendless.com/\(app_id)/\(rest_key)/users"
//let base_url = "https://xxxx.backendless.app/\(app_id)/\(rest_key)/users"
let registation_url = "\(base_url)/register"
