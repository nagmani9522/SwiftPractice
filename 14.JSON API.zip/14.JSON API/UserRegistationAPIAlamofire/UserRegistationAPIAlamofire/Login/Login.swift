//
//  ViewController.swift
//  UserRegistationAPIAlamofire
//
//  Created by mac on 04/01/22.
//

import UIKit

class Login: UIViewController {
    
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var topView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
//        topView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        self.roundCorners(view: topView, corners: [.topLeft, .topRight], radius: 40.0)
    }
    func roundCorners(view :UIView, corners: UIRectCorner, radius: CGFloat){
            let path = UIBezierPath(roundedRect: view.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
            let mask = CAShapeLayer()
            mask.path = path.cgPath
            view.layer.mask = mask
    }
    @IBAction func forgotPasswordAction(_ sender: UIButton) {
        
    }
    @IBAction func dontHaveAccountAction(_ sender: UIButton) {
//        let authenticationStoryboard = UIStoryboard(name: "Register", bundle: nil)
//        let viewController =  authenticationStoryboard.instantiateViewController(withIdentifier: "RegisterViewController") as! RegisterViewController
       
        let registerVC = RegisterViewController.sharedInstance()
        
//        self.navigationController?.pushViewController(registerVC, animated: true)
        self.navigationController?.pushViewController(registerVC, animated: true)
//        let sb = UIStoryboard(name: "Main", bundle: nil)
//        let homeVC = sb.instantiateViewController(withIdentifier: "TabBarController")
//        let appDelegate = UIApplication.shared.delegate as! AppDelegate
//        appDelegate.window?.rootViewController = homeVC
    }
    @IBAction func loginAction(_ sender: UIButton) {
        
    }
}
extension Login{
    static func sharedInstance() -> Login{
        return Login.instantiateFromStoryboard("Login")
    }
}
