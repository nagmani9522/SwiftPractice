//
//  RegisterModel.swift
//  UserRegistationAPIAlamofire
//
//  Created by mac on 09/01/22.
//

import Foundation
struct RegisterModel:Encodable{
    let name:String
    let email:String
    let password:String
}
