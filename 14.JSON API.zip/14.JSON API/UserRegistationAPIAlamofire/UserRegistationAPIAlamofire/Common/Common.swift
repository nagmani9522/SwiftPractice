//
//  Common.swift
//  UserRegistationAPIAlamofire
//
//  Created by mac on 09/01/22.
//

import Foundation
import UIKit
//MARK: Global variable
var Appname = "Alert User Authontication"
var Message = "User Registation Successfully"
//class Common: NSObject {
//
////    class func showError(_ theme: Theme,_ title: String,_ message: String) {
////        if theme == .error{
////
////        }
////    }
//
//
//}
extension UIViewController{
    class func instantiateFromStoryboard (_ name:String) -> Self
    {
    return instantiateFromStoryboardHelper(name)
    }
    fileprivate class func instantiateFromStoryboardHelper<T>(_ name:String) -> T{
        let storyboard = UIStoryboard(name: name, bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "\(self.self)") as! T
        return controller
    }
}
