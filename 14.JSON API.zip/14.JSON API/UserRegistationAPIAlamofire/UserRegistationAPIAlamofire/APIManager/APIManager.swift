//
//  APIManager.swift
//  UserRegistationAPIAlamofire
//
//  Created by mac on 09/01/22.
//

import Foundation
import  Alamofire
class APIManager{
    static let shareInstance = APIManager()
    func callingRegisterAPI(register: RegisterModel){
        let header : HTTPHeaders = [
            .contentType("application/json")
        ]
        AF.request(registation_url, method: .post, parameters: register, encoder: JSONParameterEncoder.default, headers: header).response{ response in
            debugPrint(response)
            switch response.result{
            case .success(let data):
                do{
                    let json = try JSONSerialization.jsonObject(with: data!, options: [])
                    print(json)
                }catch let error{
                    print(error.localizedDescription)
                }
            case .failure(let err):
                print(err .localizedDescription)
            }
            
        }
   }
}
