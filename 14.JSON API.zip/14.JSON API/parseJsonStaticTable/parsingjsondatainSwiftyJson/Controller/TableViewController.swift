//
//  TableViewController.swift
//  parsingjsondatainSwiftyJson
//
//  Created by mac on 28/12/21.
//

import UIKit
import  AVFoundation

class TableViewController: UITableViewController {
    @IBOutlet var artistId: UILabel!
    @IBOutlet var artistName: UILabel!
    @IBOutlet var collectionCensoredName: UILabel!
    @IBOutlet var  trackCensoredName: UILabel!
    @IBOutlet var country: UILabel!
    @IBOutlet var imageView: UIImageView!
    @IBOutlet weak var players: UIButton!
    var player : AVPlayer?
    var modelData = JsonModel()
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.tableView.tableFooterView = UIView()
    }
    override func viewWillAppear(_ animated: Bool) {
        artistName.text = "artist Name :- " + modelData.artistName
        trackCensoredName.text = "trackCensored Name :- " + modelData.trackCensoredName
        artistId.text = "artist Id :- " + modelData.artistId
        collectionCensoredName.text = "acollectionCensored Name :- " + modelData.collectionCensoredName
        country.text = "country :- " + modelData.country
        imageView.kf.setImage(with: URL(string: modelData.artworkUrl100))
        
    }
    @IBAction func musicBtnAction(_ sender: UIButton) {
        let url = NSURL(string: "https://argaamplus.s3.amazonaws.com/eb2fa654-bcf9-41de-829c-4d47c5648352.mp3")
            print("the url = \(url!)")
        play(url: url!)
        
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func play(url:NSURL) {
        print("playing \(url)")
        
        do {
            let playerItem = AVPlayerItem.init(url: url as URL)
                    player = AVPlayer.init(playerItem: playerItem)
            player?.volume = 1.0
            player?.play()
        } catch let error as NSError {
           
            print(error.localizedDescription)
        } catch {
            print("AVAudioPlayer init failed")
        }
        
    }
}
