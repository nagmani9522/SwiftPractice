//
//  JsonModel.swift
//  parsingjsondatainSwiftyJson
//
//  Created by mac on 26/12/21.
//

import Foundation
class  JsonModel{
    var artistName: String = ""
    var  trackCensoredName: String = ""
    var artworkUrl100: String = ""
    var trackViewUrl: String = ""
    var artistId: String = ""
    var collectionCensoredName: String = ""
    var country:String = ""
    init() {
    }
    init(json:JSON) {
        artistName = json["artistName"].stringValue
        trackCensoredName = json["trackCensoredName"].stringValue
        artworkUrl100 = json["artworkUrl100"].stringValue
        artistId = json["artistId"].stringValue
        collectionCensoredName = json["collectionCensoredName"].stringValue
        country = json["country"].stringValue
    }
}
