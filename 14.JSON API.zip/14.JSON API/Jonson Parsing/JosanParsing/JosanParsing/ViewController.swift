//
//  ViewController.swift
//  JosanParsing
//
//  Created by mac on 18/09/21.
//

import UIKit
import  Kingfisher
struct jsonModel: Decodable {
    let name: String
    let capital: String
}
class ViewController: UIViewController {
    var arrData = [jsonModel]()
    override func viewDidLoad() {
        super.viewDidLoad()
        jsonParsing()
        // Do any additional setup after loading the view.
    }
    func jsonParsing(){
        let base_url = URL(string: "https://restcountries.eu/rest/v2/all")
        URLSession.shared.dataTask(with: base_url!){(data, response,error) in
            do{ if error == nil{
                self.arrData = try JSONDecoder().decode([jsonModel].self, from: data!)
                for  mainArr in self.arrData{
                    print(mainArr.name,":",mainArr.capital)
                }
            }
                
            } catch{
                print("Error in JSON Data")
            }
        }.resume()
}
}
