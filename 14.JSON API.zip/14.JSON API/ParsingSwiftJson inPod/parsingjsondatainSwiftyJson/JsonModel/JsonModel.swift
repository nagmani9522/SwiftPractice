//
//  JsonModel.swift
//  parsingjsondatainSwiftyJson
//
//  Created by mac on 26/12/21.
//

import Foundation
class  JsonModel{
    var artistName: String = ""
    var  trackCensoredName: String = ""
    var artworkUrl100: String = ""
    
    init(json:NSDictionary) {
        artistName = json["artistName"] as! String
        trackCensoredName = json["trackCensoredName"] as! String
        artworkUrl100 = json["artworkUrl100"] as! String
    }
}

