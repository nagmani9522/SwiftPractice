//
//  ViewController.swift
//  ZoomInOutImginCVcell
//
//  Created by mac on 04/11/21.
//

import UIKit
import GSImageViewerController
class ViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    var arrData = [#imageLiteral(resourceName: "mail"),#imageLiteral(resourceName: "skype"),#imageLiteral(resourceName: "message"),#imageLiteral(resourceName: "call"),#imageLiteral(resourceName: "fbMessenger"),#imageLiteral(resourceName: "twitter"),#imageLiteral(resourceName: "instagram"),#imageLiteral(resourceName: "gmail"),#imageLiteral(resourceName: "whatsapp"),#imageLiteral(resourceName: "outlook")]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}
extension ViewController: UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
//        cell.imgView.layer.borderWidth = 1
//        cell.imgView.layer.masksToBounds = false
//        cell.imgView.layer.borderColor = UIColor.black.cgColor
//        cell.imgView.layer.cornerRadius = cell.imgView.frame.height/2
//        cell.imgView.clipsToBounds = true
        cell.imgView.image = arrData[indexPath.row]
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let imageInfo = GSImageInfo(image: arrData[indexPath.row], imageMode: .aspectFill)
        let transitionInfo = GSTransitionInfo(fromView: collectionView)
        let imageViewer = GSImageViewerController(imageInfo: imageInfo, transitionInfo: transitionInfo)
        imageViewer.dismissCompletion = {
            // any action on image code
            print("Dismiss")
        }
        present(imageViewer, animated: true)
    }
    
}
