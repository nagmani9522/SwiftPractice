//
//  ViewController.swift
//  MultipleCVinOneVC
//
//  Created by mac on 03/11/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var bgCollectionView: UICollectionView!
    
    @IBOutlet weak var frontCollectionView: UICollectionView!
    var arrImgDictData = [String : [UIImage]]()
    override func viewDidLoad() {
        super.viewDidLoad()
        arrImgDictData = [
            "bgImg":[#imageLiteral(resourceName: "whatsapp"),#imageLiteral(resourceName: "fbMessenger"),#imageLiteral(resourceName: "instagram"),#imageLiteral(resourceName: "skype"),#imageLiteral(resourceName: "twitter"),#imageLiteral(resourceName: "whatsapp"),#imageLiteral(resourceName: "fbMessenger"),#imageLiteral(resourceName: "instagram"),#imageLiteral(resourceName: "skype"),#imageLiteral(resourceName: "twitter"),#imageLiteral(resourceName: "whatsapp"),#imageLiteral(resourceName: "fbMessenger"),#imageLiteral(resourceName: "instagram"),#imageLiteral(resourceName: "skype"),#imageLiteral(resourceName: "twitter")],
            "fgImg":[#imageLiteral(resourceName: "call"),#imageLiteral(resourceName: "message"),#imageLiteral(resourceName: "gmail"),#imageLiteral(resourceName: "mail"),#imageLiteral(resourceName: "outlook"),#imageLiteral(resourceName: "call"),#imageLiteral(resourceName: "message"),#imageLiteral(resourceName: "gmail"),#imageLiteral(resourceName: "mail"),#imageLiteral(resourceName: "outlook"),#imageLiteral(resourceName: "call"),#imageLiteral(resourceName: "message"),#imageLiteral(resourceName: "gmail"),#imageLiteral(resourceName: "mail"),#imageLiteral(resourceName: "outlook"),#imageLiteral(resourceName: "call"),#imageLiteral(resourceName: "message"),#imageLiteral(resourceName: "gmail"),#imageLiteral(resourceName: "mail"),#imageLiteral(resourceName: "outlook"),#imageLiteral(resourceName: "call"),#imageLiteral(resourceName: "message"),#imageLiteral(resourceName: "gmail"),#imageLiteral(resourceName: "mail"),#imageLiteral(resourceName: "outlook")]
        ]
        // Do any additional setup after loading the view.
    }

}
extension ViewController: UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == collectionView.viewWithTag(1){
            if let arrImg = arrImgDictData["bgImg"]{
                return arrImg.count
            }
        }
        // without tag
//        if collectionView == self.bgCollectionView{
//            if let arrImg = arrImgDictData["bgImg"]{
//                return arrImg.count
//            }
//        }
        else{
            if let arrImg = arrImgDictData["fgImg"]{
                return arrImg.count
            }
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
        if collectionView == collectionView.viewWithTag(1){
            if let arrimg = arrImgDictData["bgImg"]{
                cell.bgImgView.image = arrimg[indexPath.row]
            }
        }
        // without tag
//        if collectionView == self.bgCollectionView{
        // cell dque
//            if let arrimg = arrImgDictData["bgImg"]{
        // bg img arr
//                cell.bgImgView.image = arrimg[indexPath.row]
//            }
//        }
        else{
            // cell deque
            if let arrimg = arrImgDictData["fgImg"]{
                // front img arr
                cell.bgImgView.image = arrimg[indexPath.row]
            }
        }
        return cell
    }
    
}
extension ViewController: UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        //With Tag
        if collectionView == collectionView.viewWithTag(1){
            return CGSize(width: collectionView.frame.width, height: collectionView.frame.height)
        }
//        //WithOut Tag
//        if collectionView == self.bgCollectionView{
//            return CGSize(width: collectionView.frame.width, height: collectionView.frame.height)
//        }
        else{
            return CGSize(width: collectionView.frame.width/3, height: collectionView.frame.height)
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
}
