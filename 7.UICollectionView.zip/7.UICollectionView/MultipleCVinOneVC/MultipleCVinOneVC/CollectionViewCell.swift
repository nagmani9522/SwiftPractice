//
//  CollectionViewCell.swift
//  MultipleCVinOneVC
//
//  Created by mac on 03/11/21.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var bgImgView: UIImageView!
}
