//
//  CollectionViewCell.swift
//  CustomCVWithDataPassing
//
//  Created by mac on 03/11/21.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var lbl: UILabel!
}
