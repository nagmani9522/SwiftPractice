//
//  firstViewController.swift
//  CustomCVWithDataPassing
//
//  Created by mac on 03/11/21.
//

import UIKit
class firstViewController: UIViewController {
    var showData:DataModel!
    @IBOutlet weak var titleShow: UILabel!
    @IBOutlet weak var imgShow: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        titleShow.text = showData.lblTitle
        imgShow.image = showData.imgView
        
    }
    

   
}
