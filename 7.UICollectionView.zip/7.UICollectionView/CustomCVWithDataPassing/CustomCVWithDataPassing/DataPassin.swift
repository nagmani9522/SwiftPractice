//
//  DataPassin.swift
//  CustomCVWithDataPassing
//
//  Created by mac on 03/11/21.
//

import Foundation
import UIKit
struct  DataModel {
    var lblTitle:String
    var imgView:UIImage
}
