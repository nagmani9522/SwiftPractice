//
//  ViewController.swift
//  CustomCVWithDataPassing
//
//  Created by mac on 03/11/21.
//

import UIKit
class ViewController: UIViewController {
    var arrData = [DataModel]()
    @IBOutlet weak var collectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        getData()
        // Do any additional setup after loading the view.
    }
    func getData(){
        arrData = [DataModel(lblTitle: "Phone Icon", imgView: #imageLiteral(resourceName: "call")),
                   DataModel(lblTitle: "Gmail Icon", imgView: #imageLiteral(resourceName: "gmail")),
                   DataModel(lblTitle: "WhatsApp Icon", imgView: #imageLiteral(resourceName: "whatsapp")),
                   DataModel(lblTitle: "Skype Icon", imgView: #imageLiteral(resourceName: "skype")),
                   DataModel(lblTitle: "Messanger Icon", imgView: #imageLiteral(resourceName: "fbMessenger")),
                   DataModel(lblTitle: "Twitter Icon", imgView: #imageLiteral(resourceName: "twitter")),
                   DataModel(lblTitle: "Instagram Icon", imgView: #imageLiteral(resourceName: "instagram")),
                   DataModel(lblTitle: "Chat Icon", imgView: #imageLiteral(resourceName: "message")),
                   DataModel(lblTitle: "Outlook Icon", imgView: #imageLiteral(resourceName: "outlook")),
                   DataModel(lblTitle: "Email Icon", imgView: #imageLiteral(resourceName: "mail"))
        ]
    }
}
extension ViewController: UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell:CollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
        cell.lbl.text = arrData[indexPath.row].lblTitle
        cell.img.image = arrData[indexPath.row].imgView
        return cell
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let firstVC:firstViewController = self.storyboard?.instantiateViewController(withIdentifier: "firstViewController") as! firstViewController
        firstVC.showData = arrData[indexPath.row]
        self.navigationController?.pushViewController(firstVC, animated: true)
    }
}
