//
//  CollectionViewCell.swift
//  iCarouselEffectCVUsingUPCarouselFlowLayout
//
//  Created by mac on 04/11/21.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        self.mainView.layer.cornerRadius = 13.0
        self.mainView.layer.shadowColor = UIColor.blue.cgColor
        self.mainView.layer.shadowOpacity = 0.5
        self.mainView.layer.shadowOffset = .zero
        self.mainView.layer.shadowPath = UIBezierPath(rect: self.mainView.bounds).cgPath
        self.mainView.layer.shouldRasterize = true
        // Initialization code
    }

}
