//
//  CollectionViewCell.swift
//  UICVLayoutAndFlowLayout
//
//  Created by mac on 04/11/21.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
   
    @IBOutlet weak var imgview: UIImageView!
}
