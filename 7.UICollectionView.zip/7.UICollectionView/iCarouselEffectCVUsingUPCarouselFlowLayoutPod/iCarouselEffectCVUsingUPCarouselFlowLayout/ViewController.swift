//
//  ViewController.swift
//  iCarouselEffectCVUsingUPCarouselFlowLayout
//
//  Created by mac on 04/11/21.
//

import UIKit
import  UPCarouselFlowLayout
struct ModelCollectionFlowlayout {
    var title:String = ""
    var imge:UIImage!
}
class ViewController: UIViewController {
var arrData = [ModelCollectionFlowlayout]()
    @IBOutlet weak var collectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        collectData()
        // Do any additional setup after loading the view.
        
        // MARK: collectionViewRepresent code
        //collectionView.showsHorizontalScrollIndicator = false // scroll is not required
        collectionView.register(UINib.init(nibName: "CollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "cell")
        let floawLayout = UPCarouselFlowLayout()
        floawLayout.itemSize = CGSize(width: UIScreen.main.bounds.size.width - 60.0, height: collectionView.frame.size.height - 100.0)
        floawLayout.scrollDirection = .horizontal
        floawLayout.sideItemScale = 0.8
        floawLayout.sideItemAlpha = 1.0
        floawLayout.spacingMode = .fixed(spacing: 5.0)
        collectionView.collectionViewLayout = floawLayout
    }
    func collectData(){
        arrData = [ModelCollectionFlowlayout(title: "Gmail -Icon", imge: #imageLiteral(resourceName: "gmail")),
                   ModelCollectionFlowlayout(title: "Chat -Icon", imge: #imageLiteral(resourceName: "message")),
                   ModelCollectionFlowlayout(title: "Messanger -Icon", imge: #imageLiteral(resourceName: "fbMessenger")),
                   ModelCollectionFlowlayout(title: "Instagram -Icon", imge: #imageLiteral(resourceName: "instagram")),
                   ModelCollectionFlowlayout(title: "Twitter -Icon", imge: #imageLiteral(resourceName: "twitter")),
                   ModelCollectionFlowlayout(title: "Email -Icon", imge: #imageLiteral(resourceName: "mail")),
                   ModelCollectionFlowlayout(title: "WhatsApp -Icon", imge: #imageLiteral(resourceName: "whatsapp")),
                   ModelCollectionFlowlayout(title: "Skype -Icon", imge: #imageLiteral(resourceName: "skype")),
                   ModelCollectionFlowlayout(title: "Phone -Icon", imge: #imageLiteral(resourceName: "call")),
                   ModelCollectionFlowlayout(title: "Outlook -Icon", imge: #imageLiteral(resourceName: "outlook")),
        ]
    }
    // MARK: scrollView code
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView){
        let layout = self.collectionView.collectionViewLayout as! UPCarouselFlowLayout
        let pageSide = (layout.scrollDirection == .horizontal) ? self.pageSize.width : self.pageSize.height
        let offset = (layout.scrollDirection == .horizontal) ? scrollView.contentOffset.x : scrollView.contentOffset.y
        currentPage = Int(floor((offset - pageSide / 2) / pageSide) + 1)

    }
    fileprivate var currentPage: Int = 0 {
        didSet{
            print("page at center = \(currentPage)")
        }
    }
    fileprivate var pageSize: CGSize {
        let layout = self.collectionView.collectionViewLayout as! UPCarouselFlowLayout
        var pageSize = layout.itemSize
        if layout.scrollDirection == .horizontal{
            pageSize.width += layout.minimumLineSpacing
        }else{
            pageSize.height += layout.minimumLineSpacing
        }
        return pageSize
    }
}
extension ViewController: UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        arrData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
        cell.lblTitle.text = arrData[indexPath.row].title
        cell.img.image = arrData[indexPath.row].imge
        return cell
    }
}
extension ViewController: UICollectionViewDelegateFlowLayout{
    
}
