//
//  ViewController.swift
//  CVwithSaveAndGetImageFromDocumDiectory
//
//  Created by mac on 04/11/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var myImgView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        saveImages()
        // Do any additional setup after loading the view.
    }
    private func saveImages(){
        // MARK: Save image
        let  document = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        print(document)
        let  imagUrl = document.appendingPathComponent("mail@2x.png", isDirectory: true)
        print(imagUrl)
        print(imagUrl.path)
        if !FileManager.default.fileExists(atPath: imagUrl.path){
            do{
                try UIImage(named: "mail@2x.png")!.pngData()?.write(to: imagUrl)
                
                print("image save successfully")
            }catch{
                print("image not added")
            }
        }
        // get image in Document Directory
        myImgView.image = UIImage(contentsOfFile: imagUrl.path)
    }
}

