//
//  ViewController.swift
//  DynamicFormScratch
//
//  Created by mac on 12/02/22.
//

import UIKit

class ViewController: UIViewController {
    var y = 136
    override func viewDidLoad() {
        super.viewDidLoad()
        managedtextfield()
        managedlabel()
        managedbutton()
        // Do any additional setup after loading the view.
    }
    func managedtextfield(){
        for i in 1...5{
        let myfield:UITextField = UITextField(frame: CGRect(x: 23, y: y, width: 340, height: 30))
        myfield.borderStyle = .roundedRect
            myfield.placeholder = "Name"
        self.view.addSubview(myfield)
            y += 52
            if i == 1{
                myfield.placeholder = "FullName"
                myfield.tag = 1
            }else if i == 2{
                myfield.placeholder = "LastName"
                myfield.tag = 2
            }else if i == 3{
                myfield.placeholder = "UserName"
                myfield.tag = 3
            }else if i == 4{
                myfield.placeholder = "Email"
                myfield.tag = 4
            }else if i == 5{
                myfield.placeholder = "Password"
                myfield.tag = 5
            }
        }
    }
    func managedlabel(){
        let mylbl:UILabel = UILabel(frame: CGRect(x: 16, y: 80, width: 343, height: 21))
        mylbl.text = "Registation Form"
        mylbl.textAlignment = .center
        mylbl.textColor = #colorLiteral(red: 0.1019607857, green: 0.2784313858, blue: 0.400000006, alpha: 1)
        self.view.addSubview(mylbl)
    }
    func managedbutton(){
        let mybtn:UIButton = UIButton(frame: CGRect(x: 141, y: 430, width: 93, height: 80))
        mybtn.setTitle("Register", for: .normal)
        mybtn.setTitleColor(#colorLiteral(red: 0.1019607857, green: 0.2784313858, blue: 0.400000006, alpha: 1), for: .normal)
        mybtn.backgroundColor = #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1)
        mybtn.addAction(UIAction(title:"",handler: { _ in
            print("button Action Success")
        }), for: .touchUpInside)
        mybtn.addTarget(self, action: #selector(valuechange), for: .touchUpInside)
        self.view.addSubview(mybtn)
    }
    @objc func valuechange(){
        print("Button is Tapped")
    }
}

