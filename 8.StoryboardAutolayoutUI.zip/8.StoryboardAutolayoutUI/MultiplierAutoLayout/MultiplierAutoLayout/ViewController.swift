//
//  ViewController.swift
//  MultiplierAutoLayout
//
//  Created by mac on 23/01/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

