//
//  ViewController.swift
//  DropDownUsingStackView
//
//  Created by mac on 12/02/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var cities: [UIButton]!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    @IBAction func btnselectcity(_ sender: UIButton) {
        cities.forEach { (Button) in
            UIView.animate(withDuration: 0.3, animations: {
                Button.isHidden = !Button.isHidden
                self.view.layoutIfNeeded()
                self.view.backgroundColor = .white
            })
        }
    }
    @IBAction func btncity1(_ sender: UIButton) {
        self.view.backgroundColor = .brown
    }
    @IBAction func btncity2(_ sender: UIButton) {
        self.view.backgroundColor = UIColor.blue
    }
    @IBAction func btncity3(_ sender: UIButton) {
        self.view.backgroundColor = UIColor.red
    }
}

