//
//  ViewController.swift
//  CustomUIViewWithXIB
//
//  Created by mac on 12/02/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var headerView: TestView!
    override func viewDidLoad() {
        super.viewDidLoad()
        headerView.lblTitle.text = "Festival HUB"
    }


}

