//
//  TestView.swift
//  CustomUIViewWithXIB
//
//  Created by mac on 12/02/22.
//

import UIKit

class TestView: UIView {

    @IBOutlet var containerView: UIView!
    
    @IBOutlet var lblTitle: UILabel!
    //MARK:- Required metod of XIB
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        commitInit()
    }
    //MARK:- Function
    private func commitInit(){
        Bundle.main.loadNibNamed("TestView", owner: self, options: nil)
        addSubview(containerView)
        containerView.frame = self.bounds
        containerView.autoresizingMask = [.flexibleHeight,.flexibleWidth]
    }
}
