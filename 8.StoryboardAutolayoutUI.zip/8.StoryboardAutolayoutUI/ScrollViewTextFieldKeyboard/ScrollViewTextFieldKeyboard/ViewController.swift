//
//  ViewController.swift
//  ScrollViewTextFieldKeyboard
//
//  Created by mac on 23/01/22.
//

import UIKit

class ViewController: UIViewController ,UITextFieldDelegate{
    @IBOutlet weak var txtField1: UITextField!
    @IBOutlet weak var txtField2: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        txtField1.delegate = self
        txtField2.delegate = self
        self.hideKeyboareTapped()
        // Do any additional setup after loading the view.
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
     //   textField.resignFirstResponder()
        self.view.endEditing(true)
        return true
    }
}
extension ViewController{
    func hideKeyboareTapped(){
        let tap:UITapGestureRecognizer = UITapGestureRecognizer(target:self, action: #selector(dismissKeyBoaed))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    @objc func dismissKeyBoaed(){
        view.endEditing(true)
    }
}
