//
//  StackViewController.swift
//  UIStackView
//
//  Created by mac on 26/01/22.
//

import UIKit

class StackViewController: UIViewController {
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var editBtn: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()
        tblView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
    }
    
    @IBAction func btnEditClick(_ sender: UIBarButtonItem) {
    
editBtn.title = "Done"
    editBtn.action = #selector(btnDoneClick)
    self.bottomView.isHidden = true
    //self.bottomViewHeight.constant = 0
}
@objc func btnDoneClick(){
    editBtn.title = "Edit"
    editBtn.action = #selector(btnEditClick(_:))
    self.bottomView.isHidden = false
    //self.bottomViewHeight.constant = 50
}
}
extension StackViewController: UITableViewDelegate,UITableViewDataSource{
func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return 20
}

func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
    cell.textLabel?.text = "\(indexPath.row)"
    return cell
}


}
