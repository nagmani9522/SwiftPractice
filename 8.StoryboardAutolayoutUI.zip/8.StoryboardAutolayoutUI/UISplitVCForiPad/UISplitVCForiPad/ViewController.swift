//
//  ViewController.swift
//  UISplitVCForiPad
//
//  Created by mac on 06/02/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblNumber: UILabel!
    var strText = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        lblNumber.text = strText
        // Do any additional setup after loading the view.
    }


}

