//
//  ViewController.swift
//  NavigateOneVCToOtherVCButtonSegueStorybod
//
//  Created by mac on 19/01/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        //print(self.navigationController!.viewControllers)
        // Do any additional setup after loading the view.
    }

    override func viewWillAppear(_ animated: Bool) {
    }
    override func viewDidAppear(_ animated: Bool) {
    }
    @IBAction func btnDetailVC(_ sender: UIButton) {
        let detailVC = self.storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
//        let detailVC = self.storyboard?.instantiateViewController(withIdentifier: "secondnav") as! UINavigationController
        // in second detail vc with navigation with programatically the remove navigation vc
        let nav = UINavigationController(rootViewController: detailVC)
        nav.modalPresentationStyle = .fullScreen
        //detailVC.modalPresentationStyle = .fullScreen
        self.present(nav, animated: true, completion: nil)
        //self.present(nav, animated: true, completion: nil)
    }
    
    @IBAction func thirdVCBtnAction(_ sender: UIButton) {
        let thirdVC = self.storyboard?.instantiateViewController(withIdentifier: "ThirdViewController") as! ThirdViewController
        self.navigationController?.pushViewController(thirdVC, animated: true)
    }
}

