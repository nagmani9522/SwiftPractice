//
//  DetailViewController.swift
//  NavigateOneVCToOtherVCButtonSegueStorybod
//
//  Created by mac on 19/01/22.
//

import UIKit

class DetailViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewWillDisappear(_ animated: Bool) {
       // print(self.navigationController!.viewControllers)
    }
    override func viewDidDisappear(_ animated: Bool) {
        //print(self.navigationController!.viewControllers)
    }
    @IBAction func btnHomeClick(_ sender: UIButton) {
       self.dismiss(animated: true, completion: nil)
         
    }
    @IBAction func btnThirdVCClick(_ sender: UIButton) {
        let detailVC = self.storyboard?.instantiateViewController(withIdentifier: "ThirdViewController") as! ThirdViewController
       let nav = UINavigationController(rootViewController: detailVC)
               nav.modalPresentationStyle = .fullScreen
               self.present(nav, animated: false, completion: nil)
//        let detailVC = self.storyboard?.instantiateViewController(withIdentifier: "ThirdViewController") as! ThirdViewController
//        self.present(detailVC, animated: true, completion: nil)

}
}
