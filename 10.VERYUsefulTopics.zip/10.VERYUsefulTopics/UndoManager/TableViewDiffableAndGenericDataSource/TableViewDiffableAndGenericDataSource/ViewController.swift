//
//  ViewController.swift
//  TableViewDiffableAndGenericDataSource
//
//  Created by mac on 03/11/21.
//

import UIKit
struct EmployeeData{
    var name = ""
    var designation = ""
    static var arrEmployee : [EmployeeData] = []
}
class ViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var btnUndo: UIButton!
    @IBOutlet weak var btnRedo: UIButton!
    var arrData : [EmployeeData] = []
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func btnAddClick(_ sender: Any) {
        let alertcontroller = UIAlertController(title: nil, message: "Add Employee", preferredStyle: .alert)
        alertcontroller.addTextField { (txtname) in
            txtname.placeholder = "Name"
        }
        alertcontroller.addTextField { (txtDesignation) in
            txtDesignation.placeholder = "Designation"
        }
        alertcontroller.addAction(UIAlertAction(title: "Cancle", style: .cancel, handler: { (cancelAction) in
            self.dismiss(animated: true)
        }))
        alertcontroller.addAction(UIAlertAction(title: "Save", style: .default, handler: { (saveAction) in
            let txtname = alertcontroller.textFields?.first?.text
            let txtdesignation = alertcontroller.textFields?.last?.text
            EmployeeData.arrEmployee.append(EmployeeData(name: txtname!, designation: txtdesignation!))
            let index = self.arrData.count
            self.addNewEmployee(at: index)
            self.addNewEmployeeWithManager(at: index)
            self.enableUndoRedo()
        }))
        self.present(alertcontroller, animated: true)
    }
    @IBAction func btnRedoAction(_ sender: UIButton) {
        self.undoManager?.redo()
        self.enableUndoRedo()
    }
    @IBAction func btnUndoAction(_ sender: UIButton) {
        self.undoManager?.undo()
        self.enableUndoRedo()
    }
    func addNewEmployee(at index: Int){
        let employee = EmployeeData.arrEmployee[index]
        self.arrData.append(employee)
        self.tableView.reloadData()
    }
    func removeNewEmployee(at index: Int){
        self.arrData.remove(at: index)
        self.tableView.reloadData()
    }
    func enableUndoRedo() {
        self.btnUndo.isEnabled = self.undoManager?.canUndo ?? false
        self.btnRedo.isEnabled = self.undoManager?.canRedo ?? false
    }
}
//MARK: UndoManager
extension ViewController{
    func addNewEmployeeWithManager(at index: Int){
        self.undoManager?.registerUndo(withTarget: self, handler: { (selfTarger) in
            selfTarger.removeNewEmployee(at: index)
            selfTarger.removeNewEmployeeWithManager(at: index)
        })
    }
    func removeNewEmployeeWithManager(at index: Int){
        self.undoManager?.registerUndo(withTarget: self, handler: { (selfTarger) in
            self.addNewEmployee(at: index)
            self.addNewEmployeeWithManager(at: index)
        })
    }
}
extension ViewController: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = arrData[indexPath.row].name
        cell?.detailTextLabel?.text = arrData[indexPath.row].designation
        return cell!
    }
}
