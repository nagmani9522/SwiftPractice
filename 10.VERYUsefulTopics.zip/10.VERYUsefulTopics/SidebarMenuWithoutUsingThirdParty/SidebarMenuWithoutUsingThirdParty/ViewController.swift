//
//  ViewController.swift
//  SidebarMenuWithoutUsingThirdParty
//
//  Created by mac on 07/03/22.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var arrdata = ["username","email","password","mobile","logout"]
   var arrimg = [UIImage(named: "call"),UIImage(named: "fbMessenger"),UIImage(named: "gmail"),UIImage(named: "instagram"),UIImage(named: "message")]
    @IBOutlet var sidebar: UITableView!
    @IBOutlet var sideview: UIView!
    var isSideViewOpen:Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()
        sideview.isHidden = true
        sidebar.backgroundColor = UIColor.systemCyan
        isSideViewOpen = false
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrdata.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        cell.img.image = arrimg[indexPath.row]
        cell.lbl.text = arrdata[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0{
            let uname:unameViewController = self.storyboard?.instantiateViewController(withIdentifier: "unameViewController") as! unameViewController
            self.navigationController?.pushViewController(uname, animated: true)
        }
    }
    @IBAction func btnMenu(_ sender: UIButton) {
        sideview.isHidden = false
        sidebar.isHidden = false
        self.view.bringSubviewToFront(sideview)
        if !isSideViewOpen{
            isSideViewOpen = true
            sideview.frame = CGRect(x: 0, y: 88, width: 0, height: 613)
            sidebar.frame = CGRect(x: 0, y: 0, width: 0, height: 613)
//            UIView.animate(withDuration: 3.0, animations: {
//                print("Animation")
//            })
            UIView.animate(withDuration: 1.0, delay: 0.25, usingSpringWithDamping: 0.0, initialSpringVelocity: 0.0, options: [.beginFromCurrentState], animations: {
                self.sideview.center.x = self.view.bounds.width
            }, completion: nil)
            UIView.setAnimationsEnabled(true)
            sideview.frame = CGRect(x: 0, y: 88, width: 256, height: 613)
            sidebar.frame = CGRect(x: 0, y: 88, width: 256, height: 613)
            
        }else{
            sideview.isHidden = true
            sidebar.isHidden = true
            isSideViewOpen = false
            sideview.frame = CGRect(x: 0, y: 88, width: 256, height: 613)
            sidebar.frame = CGRect(x: 0, y: 88, width: 256, height: 613)
//            UIView.animate(withDuration: 3.0, animations: {
//                print("hide")
//            })
            UIView.animate(withDuration: 1.0, delay: 0.25, usingSpringWithDamping: 0.0, initialSpringVelocity: 0.0, options: [.beginFromCurrentState], animations: {
                self.sideview.isHidden = true
            }, completion: nil)
            UIView.setAnimationsEnabled(true)
            sideview.frame = CGRect(x: 0, y: 88, width: 0, height: 613)
            sidebar.frame = CGRect(x: 0, y: 0, width: 0, height: 613)
        }
    }
}

