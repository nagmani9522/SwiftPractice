//
//  unameViewController.swift
//  SidebarMenuWithoutUsingThirdParty
//
//  Created by mac on 10/03/22.
//

import UIKit

class unameViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }


}
