//
//  collectionViewController.swift
//  CVwithSaveAndGetImageFromDocumDiectory
//
//  Created by mac on 04/11/21.
//

import UIKit
// directory dont Save image in coreData use DocumentDirectory
class collectionViewController: UIViewController {
    var arrData = ["mail@2x.png","call@2x.png","fbMessenger@2x.png","twitter@2x.png","whatsapp@2x.png","outlook@2x.png","skype@2x.png","gmail@2x.png","instagram@2x.png","message@2x.png"]
    var imgArr = [String]()
    @IBOutlet weak var myCollectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        saveImages()
        // Do any additional setup after loading the view.
    }
    private func saveImages(){
        // MARK: Save image
        for imagesStr in arrData{
            let  document = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            print(document)
            let  imagUrl = document.appendingPathComponent(imagesStr, isDirectory: true)
            print(imagUrl)
            print(imagUrl.path)
            if !FileManager.default.fileExists(atPath: imagUrl.path){
                do{
                    try UIImage(named: imagesStr)!.pngData()?.write(to: imagUrl)
                    print("image save successfully")
                }catch{
                    print("image not added")
                }
            }
            imgArr.append(imagUrl.path)
        }
        
        // get image in Document Directory
        //myImgView.image = UIImage(contentsOfFile: imagUrl.path)
    }
}
class collectionViewCell: UICollectionViewCell{
    
    @IBOutlet weak var cellImgView: UIImageView!
}
extension collectionViewController: UICollectionViewDelegate, UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imgArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! collectionViewCell
        cell.cellImgView.image = UIImage(contentsOfFile: imgArr[indexPath.row])
        return cell
    }
}
extension collectionViewController: UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.layer.frame.width/2-5, height: collectionView.layer.frame.width/2-5)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
}
