//
//  ViewController.swift
//  DrawingPencileKitPkCanvas
//
//  Created by mac on 20/02/22.
//

import UIKit
import PencilKit
class ViewController: UIViewController{
    @IBOutlet weak var canvasView: PKCanvasView!
    var toolPicker: PKToolPicker!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.viewDidLoadw()
        print("mohan")
        
        // Do any additional setup after loading the view.
    }
    func viewDidLoadw(){
        print("mohanfjdjdh")
    }
    override func viewWillAppear(_ animated: Bool) {
            super.viewWillAppear(animated)
            if #available(iOS 14.0, *) {
                toolPicker = PKToolPicker()
            } else {
                let window = parent?.view.window
                toolPicker = PKToolPicker.shared(for: window!)
            }
            toolPicker.setVisible(true, forFirstResponder: canvasView)
            toolPicker.addObserver(canvasView)
            //toolPicker.addObserver(self)
            canvasView.becomeFirstResponder()
            canvasView.allowsFingerDrawing = true
    
    }
    @IBAction func btnCleartapped(_ sender: UIBarButtonItem) {
        canvasView.drawing = PKDrawing()
    }
    @IBAction func btnImagetapped(_ sender: UIBarButtonItem) {
        let imgVC = self.storyboard?.instantiateViewController(withIdentifier: "imageViewController") as? imageViewController
        let img = UIGraphicsImageRenderer(bounds: canvasView.bounds).image { _ in
            view.drawHierarchy(in: canvasView.bounds, afterScreenUpdates: true)
        }
        imgVC?.img = img
        self.navigationController?.pushViewController(imgVC!, animated: true)
    }
}
class UserViewController: UIViewController {
    override func viewDidLoad() {
    super.viewDidLoad()
    print("ram")
     // do view setup here
    }
    func ramn(){
        print("ddvhdgsvhgds")
    }
}
