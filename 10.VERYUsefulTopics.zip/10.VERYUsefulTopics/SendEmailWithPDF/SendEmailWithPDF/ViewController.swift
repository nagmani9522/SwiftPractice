//  ViewController.swift
//  SendEmailWithPDF
//  Created by mac on 26/02/22.
import UIKit
import MessageUI
import ContactsUI
class ViewController: UIViewController{
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func btnSendEmailClick(_ sender: UIButton) {
        guard MFMailComposeViewController.canSendMail() else{
            return
        }
        let composer = MFMailComposeViewController()
        composer.mailComposeDelegate = self
        composer.setToRecipients(["mk1838742@gmail.com"])
        composer.setSubject("Youtube Test !!")
        composer.setMessageBody("Todays Mail", isHTML: true)
        // many pdf use document directory first save pdf in document directory
        //then this path assign
        if let filePath = Bundle.main.path(forResource: "sample", ofType: "pdf"){
            if let fileData = NSData(contentsOfFile: filePath){
                composer.addAttachmentData(fileData as Data, mimeType: "application/pdf", fileName: "simple.pdf")
            }
        }
        self.present(composer, animated: true, completion: nil)
    }
}
extension ViewController : MFMailComposeViewControllerDelegate {
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        if let _ = error{
            controller.dismiss(animated: true, completion: nil)
        }
        switch result{
        case .cancelled:
        print("Cancelled")
        case .saved:
            print("saved")
        case .sent:
            print("send")
        case .failed:
            print("failed")
        @unknown default:
            print("default")
        }
        controller.dismiss(animated: true, completion: nil)
    }
}

