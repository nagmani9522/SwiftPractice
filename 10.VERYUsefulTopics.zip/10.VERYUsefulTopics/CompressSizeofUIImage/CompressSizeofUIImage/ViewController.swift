//
//  ViewController.swift
//  CompressSizeofUIImage
//
//  Created by mac on 20/02/22.
//

import UIKit
import MessageUI
class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        let compressData = #imageLiteral(resourceName: "watches").jpegData(compressionQuality: 1.0)
        let myImage = UIImage(data: compressData!)
        //MARK:- Large
        if let data = myImage?.jpegData(compressionQuality: 1.0){
            let fileSizeStr = ByteCountFormatter.string(fromByteCount: Int64(data.count), countStyle: ByteCountFormatter.CountStyle.memory)
            print(fileSizeStr)
        }
        let compressData1 = #imageLiteral(resourceName: "watches").jpegData(compressionQuality: 0.5)
        let myImage1 = UIImage(data: compressData1!)
        //MARK:- Medium
        if let data1 = myImage1?.jpegData(compressionQuality: 0.5){
            let fileSizeStr = ByteCountFormatter.string(fromByteCount: Int64(data1.count), countStyle: ByteCountFormatter.CountStyle.memory)
            print(fileSizeStr)
        }
        let compressData2 = #imageLiteral(resourceName: "watches").jpegData(compressionQuality: 0)
        let myImage2 = UIImage(data: compressData2!)
        //MARK:- Small
        if let data2 = myImage2?.jpegData(compressionQuality: 0){
            let fileSizeStr = ByteCountFormatter.string(fromByteCount: Int64(data2.count), countStyle: ByteCountFormatter.CountStyle.memory)
            print(fileSizeStr)
        }
    }


}

