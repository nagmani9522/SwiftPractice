
                            MAP
Loops over a collection and applies the same operation to each element in the collection.
                                               Filter
Loops over a collection and returns an array that contains elements that meet a condition.
                                               Reduce
Combines All items in a collection to create a single value.
                                               FilterMap
When implemented on sequences: Flattens a collection of collections.
                                
                            why use Higher Order Functions?
these Simplistic examples above sum up the reasons why we should use higher order functions in place of more commonly used methods.They Help us:
  1.    Read and understand complex functional programming
   2.   Write more elegantly and maintainable code that has better readability
