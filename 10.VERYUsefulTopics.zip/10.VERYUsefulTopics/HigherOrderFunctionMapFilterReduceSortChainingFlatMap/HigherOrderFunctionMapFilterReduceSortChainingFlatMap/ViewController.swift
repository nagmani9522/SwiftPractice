//
//  ViewController.swift
//  HigherOrderFunctionMapFilterReduceSortChainingFlatMap
//
//  Created by mac on 27/02/22.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        map()
        filter()
        reduce()
        sorting()
        flatMap()
        chaining()
    }
    func map(){
        let numberArray = [1,2,3,4,5]
        var emptyArray:[Int] = []
        for number in numberArray{
            emptyArray.append(number*2)
        }
        print("Array: ",emptyArray)
        //MARK:- MAP
        // method 1:-
        let m1 = numberArray.map { (value:Int) -> Int in
            return value * 2
        }
        print("m1",m1)
        
        // method 2:-
        let m2 = numberArray.map { (value:Int) in
            return value * 2
        }
        print("m2",m2)
        
        // method 3:-
        let m3 = numberArray.map { (value) in
            return value * 2
        }
        print("m3",m3)
        // method 4:-
        // One line Code
        let m4 = numberArray.map { $0 * 2 }
        print("m4",m4)
    }
    //MARK:- FILTER
    func filter(){
        let numberFilter = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]
        var arr1:[Int] = []
        for number in numberFilter{
            if number % 2 != 0{
                arr1.append(number)
            }
        }
        print("arr1",arr1)
        // method 1:-
        let filterData = numberFilter.filter { $0 % 2 == 0}
        print("filterData",filterData)
    }
    //MARK:- REDUCE
    func reduce(){
        let oneTwo = [1,2,3,4,5]
        var Sum:Int = 0
        for num in oneTwo{
            Sum += num
        }
        print("Sum",Sum)
        // method 1:-
        let sumReduce = oneTwo.reduce(0,{ $0 + $1})
        print("sumReduce",sumReduce)
        // method 2:-
        let sumReduce1 = oneTwo.reduce(0) { $0 + $1}
        print("sumReduce1",sumReduce1)
        // method 3:-
        let sumReduce2 = oneTwo.reduce(0, +) // +  indicate as $0 + $1
        print("sumReduce2",sumReduce2)
        // method 3:- for String merging
        let strArr = ["One","Two"]
        let str = strArr.reduce("", +)
        print(str)
    }
    //MARK:- SORTING
    func sorting(){
        // method 1:-
        let sortArr = [6,5,4,3,2,1]
        let arrSort = sortArr.sorted() // Accending order by default
        print("arrSort",arrSort)
        // method 2:-
        let sortArr1 = [1,2,3,4,5]
        let arrSort1 = sortArr1.sorted { $0>$1}
        print("arrSort1",arrSort1)
        // method 3:-
        var sortArr2 = [1,2,3,4,5]
        for i in 0..<sortArr2.count-1{
            var tmp = 0
            for j in i+1..<sortArr2.count{
                if sortArr2[i]<sortArr2[j]{
                    tmp = sortArr2[i]
                    sortArr2[i] = sortArr2[j]
                    sortArr2[j] = tmp
                }
            }
        }
        print("sortArr2",sortArr2)
    }
    //MARK:- FLATMAP
    func flatMap(){
        // method 1:-
        let arrayFlat = [[11,12,13],[14,15,16]]
        var mapArr:[Int] = []
        for arr in arrayFlat{
            //print("arr",arr)
            mapArr += arr // []+[11,12,13] = [11,12,13]
            // [11,12,13]+[14,15,16] = [11,12,13,14,15,16]
           // print(mapArr)
        }
        print("maparr",mapArr)
        // method 2:-
        let f1 = arrayFlat.flatMap {$0}
        print("f1",f1)
        let people = ["nagmani",nil,"nagmani1",nil,"","nagmani2"]
        let p1 = people.flatMap {$0}
        print("p1",p1)
        // method 3:-
        let p2 = people.compactMap {$0}
        print("p2",p2)
    }
    //MARK:- CHAINING
    func chaining(){
        let arrInArray = [[11,12,13],[14,15,16]]
        let arr123 = arrInArray.flatMap {$0}.filter { $0 % 2 == 0}.map {$0 * $0}.sorted{$0>$1}.reduce(0,{ $0 + $1})
        print("arr123",arr123)
        let arr1234 = arrInArray.flatMap {$0}.filter { $0 % 2 == 0}.map {$0 * $0}.sorted{$0>$1}
        let arrReduce1 = arr1234.reduce(0, +)
        print("arrReduce1",arrReduce1)
        let a11 = arrInArray.flatMap {$0}.map {"$\($0)"}
        print("a11",a11)
    }
}

