import Foundation
public class randomdatagenerator{
    public init() {}
    public static func string() -> String{
        //random String
        return UUID().uuidString
    }
    public static func integer() -> Int{
        return Int(arc4random()) // it generate random integer value
    }
    public static func fourDigit() -> Int{
        return Int(String(format:"%04d", arc4random_uniform(10000)))! // it generate random integer value
    }
}

