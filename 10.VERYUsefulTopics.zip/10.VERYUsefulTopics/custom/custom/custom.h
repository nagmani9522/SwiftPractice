//
//  custom.h
//  custom
//
//  Created by mac on 13/03/22.
//

#import <Foundation/Foundation.h>

//! Project version number for custom.
FOUNDATION_EXPORT double customVersionNumber;

//! Project version string for custom.
FOUNDATION_EXPORT const unsigned char customVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <custom/PublicHeader.h>


