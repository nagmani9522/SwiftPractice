//
//  FourViewController.swift
//  NavigateOneVCToOtherVCButtonSegueStorybod
//
//  Created by mac on 19/01/22.
//

import UIKit

class FourViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func detailVCAction(_ sender: UIButton) {
        
            for controller in self.navigationController!.viewControllers as Array {
//                if controller.isKind(of: ThirdViewController.self) {
//                    self.navigationController!.popToViewController(controller, animated: true)
//                    break
//                }
                print(controller)
                if controller.isKind(of: DetailViewController.self) {
                    self.navigationController!.popToViewController(controller, animated: true)
                    break
                }
            }
    }
    
    @IBAction func homeVCAction(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    @IBAction func thirdVC(_ sender: UIButton) {
//        var mulVC = self.navigationController?.viewControllers
//        mulVC?.remove(at: 2)
       // self.navigationController?.viewControllers = mulVC!
        self.navigationController?.viewControllers.remove(at: 2)
        
        self.navigationController?.popViewController(animated: true)
        
    }
}
