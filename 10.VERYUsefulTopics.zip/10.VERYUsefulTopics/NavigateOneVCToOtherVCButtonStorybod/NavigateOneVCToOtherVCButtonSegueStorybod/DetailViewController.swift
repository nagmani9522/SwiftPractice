//
//  DetailViewController.swift
//  NavigateOneVCToOtherVCButtonSegueStorybod
//
//  Created by mac on 19/01/22.
//

import UIKit

class DetailViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewWillDisappear(_ animated: Bool) {
        print(self.navigationController!.viewControllers)
    }
    
    @IBAction func btnHomeClick(_ sender: UIButton) {
        for controller in self.navigationController!.viewControllers as Array {
//                if controller.isKind(of: ThirdViewController.self) {
//                    self.navigationController!.popToViewController(controller, animated: true)
//                    break
//                }
            print(controller)
            if controller.isKind(of: DetailViewController.self) {
                self.navigationController!.popToViewController(controller, animated: true)
                break
            }
        }
    }
    @IBAction func btnThirdVCClick(_ sender: UIButton) {
        let thirdVC = self.storyboard?.instantiateViewController(withIdentifier: "ThirdViewController") as! ThirdViewController
        self.navigationController?.pushViewController(thirdVC, animated: true)
    }

}
