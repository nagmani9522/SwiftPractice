//
//  ViewController.swift
//  NavigateOneVCToOtherVCButtonSegueStorybod
//
//  Created by mac on 19/01/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        print(self.navigationController!.viewControllers)
        // Do any additional setup after loading the view.
    }

    override func viewWillAppear(_ animated: Bool) {
        print(self.navigationController!.viewControllers)
     print("hhhh")
    }
    override func viewDidAppear(_ animated: Bool) {
        print(self.navigationController!.viewControllers)
        print("hhhh")
    }
    @IBAction func btnDetailVC(_ sender: UIButton) {
        print("hhhh")
        let detailVC = self.storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        for controller in self.navigationController!.viewControllers as Array {
//                if controller.isKind(of: ThirdViewController.self) {
//                    self.navigationController!.popToViewController(controller, animated: true)
//                    break
//                }
            print(controller)
        self.navigationController?.pushViewController(detailVC, animated: true)
        }
    }
    
    @IBAction func thirdVCBtnAction(_ sender: UIButton) {
        let thirdVC = self.storyboard?.instantiateViewController(withIdentifier: "ThirdViewController") as! ThirdViewController
        self.navigationController?.pushViewController(thirdVC, animated: true)
    }
}

