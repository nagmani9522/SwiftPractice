//
//  ViewController.swift
//  CustomPopupView
//
//  Created by mac on 27/02/22.
//

import UIKit
import Popover
class ViewController: UIViewController,UIPopoverControllerDelegate {
   
    @IBOutlet weak var stackView: UIStackView!
    
    @IBOutlet weak var popoverView: UIView!
    @IBOutlet weak var btnPopover: UIButton!
    fileprivate var popover: Popover!
    fileprivate var popoverOptions: [PopoverOption] = [
      .type(.auto),
        .blackOverlayColor(.blue),
        .dismissOnBlackOverlayTap(false)
    ]
    var pop = Popover()
    override func viewDidLoad() {
        super.viewDidLoad()
        showInstructionView()
        // Do any additional setup after loading the view.
    }


}
extension ViewController:UIPopoverPresentationControllerDelegate {
    func nextDoneBtnAction(){
        popoverView.layer.frame.size = CGSize( width: 351, height: 223)
        btnPopover.addTarget(self, action: #selector(self.btnAction(_:)), for:.touchUpInside)
    }
        @objc func btnAction(_ sender : UIButton) {
            print("blank")
            self.pop.dismiss()

        }
    func showInstructionView(){
        nextDoneBtnAction()
        
        pop = Popover(options: popoverOptions, showHandler: nil, dismissHandler: { [self] in
            switch btnPopover.tag{
            case 2:

                self.showInstructionView()
                break
            default:
                //self.showInstructionView()
                break
            }
        })
        
        pop.show(popoverView, fromView: btnPopover)
      }
}

