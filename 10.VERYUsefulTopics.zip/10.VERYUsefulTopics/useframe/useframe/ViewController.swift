//
//  ViewController.swift
//  useframe
//
//  Created by mac on 13/03/22.
//

import UIKit
import custom
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(randomdatagenerator.fourDigit())
        print(randomdatagenerator.string())
        print(randomdatagenerator.integer())
    }


}

