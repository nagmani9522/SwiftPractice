//
//  ViewController.swift
//  DynamicScrollView
//
//  Created by mac on 26/01/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

