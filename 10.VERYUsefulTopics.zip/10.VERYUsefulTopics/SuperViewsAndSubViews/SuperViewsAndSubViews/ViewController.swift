//  ViewController.swift
//  SuperViewsAndSubViews
//  Created by mac on 26/02/22.
import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var myView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        myfunc()
    }
    func myfunc(){
        myView.superview?.backgroundColor = .lightGray
        if let textfields = myView.subviews as? [UITextField]{
            textfields[0].text = "Nagmani"
            textfields[0].superview?.backgroundColor = .red
            textfields[1].text = "Kumar"
            myView.subviews[1].backgroundColor = .brown
        }
    }
}

