//
//  ViewController.swift
//  EasytoCreateFloatingActionButton
//
//  Created by mac on 27/02/22.
//

import UIKit

class ViewController: UIViewController {
    var actionButton: ActionButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        setupButtons()
    }
    func setupButtons(){
        let Instagram = ActionButtonItem(title: "Instagram", image: #imageLiteral(resourceName: "instagram"))
        Instagram.action = {item in self.view.backgroundColor = UIColor.red}
        let Twitter = ActionButtonItem(title: "Twitter", image: #imageLiteral(resourceName: "twitter"))
        Twitter.action = {item in self.view.backgroundColor = UIColor.blue}
        let Gmail = ActionButtonItem(title: "Gmail", image: #imageLiteral(resourceName: "gmail"))
        let Massenger = ActionButtonItem(title: "Massenger", image: #imageLiteral(resourceName: "fbMessenger"))
        actionButton = ActionButton(attachedToView: self.view, items: [Instagram,Twitter,Gmail,Massenger])
        actionButton.setTitle("+", forState: UIControl.State())
        actionButton.backgroundColor = UIColor(red: 238/255, green: 130/255, blue: 130/255, alpha: 1)
        actionButton.action = {button in button.toggleMenu()}
        
    }

}

