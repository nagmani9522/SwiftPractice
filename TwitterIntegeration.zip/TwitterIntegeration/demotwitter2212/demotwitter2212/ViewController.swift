//
//  ViewController.swift
//  demotwitter2212
//
//  Created by Yogesh Patel on 26/12/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var btnlogin: UIButton!
    
    @IBOutlet var btnlogout: UIButton!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        FHSTwitterEngine.shared().permanentlySetConsumerKey("0C1KMEGi6Tp1L54q38mE8wqwo", andSecret: "oWxdtYgaKbfVjwPxdKLLpw13jtWR1VfcPuqTsJW5amOSGWfzMC")
    }

    @IBAction func loginbtnaction(_ sender: UIButton) {
     let login =   FHSTwitterEngine.shared().loginController { (success) in
            self.btnlogin.isHidden = true
            self.btnlogout.isHidden = false
        } as UIViewController
        self.present(login, animated: true, completion: nil)
    }
    
    @IBAction func logoutbtnaction(_ sender: UIButton) {
        FHSTwitterEngine.shared().clearAccessToken()
        
        self.btnlogin.isHidden = false
        self.btnlogout.isHidden = true
    }
    

}

