//
//  Student+CoreDataClass.swift
//  CreateAndUseCoreData
//
//  Created by mac on 14/11/21.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {

}
