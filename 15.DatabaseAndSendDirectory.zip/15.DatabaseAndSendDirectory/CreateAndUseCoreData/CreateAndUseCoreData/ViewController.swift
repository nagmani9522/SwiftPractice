//
//  ViewController.swift
//  CreateAndUseCoreData
//
//  Created by mac on 14/11/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtaddress: UITextField!
    @IBOutlet weak var txtCity: UITextField!
    @IBOutlet weak var txtMobile: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btnSaveClick(_ sender: Any) {
        let dict = ["name":txtName.text,"address":txtaddress.text,"city":txtCity.text,"mobile":txtMobile.text]
        DatabaseHelper.Instance.save(object: dict as [String : Any])
    }
    
}

