//
//  ViewController.swift
//  CreateAndUseCoreData
//
//  Created by mac on 14/11/21.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtaddress: UITextField!
    @IBOutlet weak var txtCity: UITextField!
    @IBOutlet weak var txtMobile: UITextField!
    var i = Int()
    var isUpdate = Bool()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btnSaveData(_ sender: Any) {
   
        let dict = ["name":txtName.text,"address":txtaddress.text,"city":txtCity.text,"mobile":txtMobile.text]
        if isUpdate  {
            DatabaseHelper.Instance.editData(object: dict as! [String:String], i: i)
            isUpdate = false
        }
        else{
            DatabaseHelper.Instance.save(object: dict as! [String:String])
        }
    }
    
    @IBAction func btnShowData(_ sender: Any) {
        let cell = storyboard?.instantiateViewController(withIdentifier: "ListViewController") as! ListViewController
        cell.delegate = self
        self.navigationController?.pushViewController(cell, animated: true)
    }
}
extension ViewController: DataPass{
    func data(object: [String : String], index: Int, isEdit: Bool) {
        txtName.text = object["name"]
        txtaddress.text = object["address"]
        txtCity.text = object["city"]
        txtMobile.text = object["mobile"]
        i = index
        isUpdate = isEdit
    }
 
}
