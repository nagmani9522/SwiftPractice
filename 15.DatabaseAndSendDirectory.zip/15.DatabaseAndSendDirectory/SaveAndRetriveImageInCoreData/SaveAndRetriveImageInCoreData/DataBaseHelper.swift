//
//  DataBasehelper.swift
//  SaveAndRetriveImageInCoreData
//
//  Created by mac on 20/11/21.
//

import Foundation
import CoreData
import UIKit
class DatabaseHelper {
    static let instance = DatabaseHelper()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func saveImageinCoredata(at imgData: Data){
        let profile = NSEntityDescription.insertNewObject(forEntityName: "Profile", into: context) as! Profile
        profile.img = imgData
        do{
            try context.save()
        }catch let error{
            print(error.localizedDescription)
        }
    }
    func getImage() -> [Profile]{
        var arrProfile = [Profile]()
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Profile")
        do{
            arrProfile = try context.fetch(fetchRequest) as! [Profile]
        }catch let error{
            print(error.localizedDescription)
        }
        return arrProfile
    }
}
