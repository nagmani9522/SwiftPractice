//
//  Profile+CoreDataProperties.swift
//  SaveAndRetriveImageInCoreData
//
//  Created by mac on 20/11/21.
//
//

import Foundation
import CoreData


extension Profile {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Profile> {
        return NSFetchRequest<Profile>(entityName: "Profile")
    }

    @NSManaged public var img: Data?

}

extension Profile : Identifiable {

}
