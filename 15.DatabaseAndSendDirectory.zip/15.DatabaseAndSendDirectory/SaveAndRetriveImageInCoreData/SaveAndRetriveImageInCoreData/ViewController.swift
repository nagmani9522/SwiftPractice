//
//  ViewController.swift
//  SaveAndRetriveImageInCoreData
//
//  Created by mac on 20/11/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var saveImg: UIImageView!
    @IBOutlet weak var getImg: UIImageView!
    var imagePicker = UIImagePickerController()
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.selectImage(gesture:)))
        tapGesture.numberOfTapsRequired = 1
        self.saveImg.isUserInteractionEnabled = true
        self.saveImg.addGestureRecognizer(tapGesture)
        // Do any additional setup after loading the view.
    }
    @objc func selectImage(gesture: UITapGestureRecognizer){
        self.openImagePicker()
    }
    @IBAction func btnClick(_ sender: Any) {
        
        
        guard let jpg = self.saveImg.image?.jpegData(compressionQuality: 0.75) else { return  }
        if let png = self.saveImg.image?.pngData(){
            DatabaseHelper.instance.saveImageinCoredata(at: png)
        }
//       // DatabaseHelper.instance.saveImageinCoredata(at: jpg)
        
    }
    
@IBAction func btnGetImg(_ sender: Any){
    var arr = DatabaseHelper.instance.getImage()
    
    self.getImg.image = UIImage(data: arr[arr.count - 1].img!)
  }
}
extension ViewController: UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    func openImagePicker(){
        if UIImagePickerController.isSourceTypeAvailable(.savedPhotosAlbum){
            imagePicker.delegate = self
            imagePicker.sourceType = .savedPhotosAlbum
            imagePicker.allowsEditing = false
            present(imagePicker, animated: true, completion: nil)
            
        }
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        dismiss(animated: true, completion: nil)
        if let img = info[.originalImage] as? UIImage{
            self.saveImg.image = img
        }
    }
}
