//
//  Profile+CoreDataClass.swift
//  SaveAndRetriveImageInCoreData
//
//  Created by mac on 20/11/21.
//
//

import Foundation
import CoreData

@objc(Profile)
public class Profile: NSManagedObject {

}
