//
//  ViewController.swift
//  ApiXmlToJson
//
//  Created by mac on 15/08/22.
//

import UIKit
import SwiftyJSON
import SWXMLHash
class ViewController: UIViewController {
     var channelName = ""
     var channelURL = ""
     var imageURL = ""
    var newsItems = [Item]()
    override func viewDidLoad() {
        super.viewDidLoad()
        getData()
    }
    func getData() {
        let url = NSURL(string: "https://www.nytimes.com/svc/collections/v1/publish/https://www.nytimes.com/section/world/rss.xml")

        let task = URLSession.shared.dataTask(with: url! as URL) {(data, response, error) in
            if data != nil
            {
                print("data not nil")
                let feed=NSString(data: data!, encoding: String.Encoding.utf8.rawValue)! as String
                print(feed)
                //let xml = SWXMLHash.parse(feed)
                let xml = XMLHash.parse(feed)//SWXMLHash.parse(feed as String)
                 print(xml)
                self.channelName = xml["rss"]["channel"]["title"].element!.text
                self.channelURL = xml["rss"]["channel"]["link"].element!.text
                self.imageURL = xml["rss"]["channel"]["image"]["url"].element!.text

                for elem in xml["rss"]["channel"]["item"].all
                {
                    let item = Item()
                    item.title = elem["title"].element!.text
                    item.url = elem["link"].element!.text
                    item.pubDate = self.cleanDate(date: elem["pubDate"].element!.text)
                    self.newsItems.append(item)

                    //Sort the news items by publication date
                    self.newsItems = self.newsItems.sorted{$0.pubDate.compare($1.pubDate) == .orderedDescending}
                }
            }else{
                print("data nill")
            }
        }
        task.resume()
    }
    func cleanDate(date: String) -> Date
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "E, d MMM yyyy HH:mm:ss Z"
        let pubDate = dateFormatter.date(from:date)!
        return pubDate
    }
}
class Item: Identifiable
{
    var title = ""
    var url = ""
    var pubDate = Date()
}
