//
//  ViewController.swift
//  rrrrr
//
//  Created by mac on 13/05/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var txtField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        txtField.textContentType = .oneTimeCode
    }


}

