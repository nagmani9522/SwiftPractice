//
//  globalvalue.swift
//  chatApp
//
//  Created by mac on 07/05/22.
//

import Foundation
