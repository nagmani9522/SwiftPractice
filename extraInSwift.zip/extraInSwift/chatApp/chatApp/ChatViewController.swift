//
//  ChatViewController.swift
//  chatApp
//
//  Created by mac on 07/05/22.
//

import UIKit

class ChatViewController: UIViewController,UITextViewDelegate {
    
    @IBOutlet var txtViewHC: NSLayoutConstraint!
    var message:[Any] = []
    @IBOutlet var txtView: UITextView!
    @IBOutlet var tblView: UITableView!
    var user_idChatMessage = ""
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        message = UserDefaults.standard.value(forKey: "\(user_idChatMessage)") as? [Any] ?? []
    }
    @IBAction func btnChatEnd(_ sender: UIButton) {
        tblView.delegate = self
        tblView.dataSource = self
        if txtView.text.isEmpty{
            return
        }
        message.append(txtView.text ?? "")
        UserDefaults.standard.set(message, forKey: "\(user_idChatMessage)")
        tblView.reloadData()
        txtView.text = ""
    }
    
}
extension ChatViewController: UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return message.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblView.dequeueReusableCell(withIdentifier: "Messagecell", for: indexPath) as! Messagecell
        cell.lblText.text = message[indexPath.row] as? String
        return cell
    }
    func textViewDidBeginEditing(_ textView: UITextView) {
        txtView.text = ""
        }
    func textViewDidEndEditing(_ textView: UITextView) {
        txtView.text = "Type Your Message"
        }
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        return true
    }
    func textViewDidChange(_ textView: UITextView) {
        if self.txtView.contentSize.height < 101.0{
            
            txtViewHC.constant = self.txtView.contentSize.height
        }else{
        }
    }
}
