//
//  ViewController.swift
//  chatApp
//
//  Created by mac on 07/05/22.
//

import UIKit

class ViewController: UIViewController {
    var dict = [String : [String : String]]()//[String:Any]()
    var profile = [String:String]()
    static var user_idvalue =  UserDefaults.standard.integer(forKey: "user_id")
    var emailExit:Bool?
    @IBOutlet var txtName: UITextField!
    @IBOutlet var txtEmail: UITextField!
    @IBOutlet var txtPassword: UITextField!
    var userID:String?
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        if UserDefaults.standard.value(forKey: "userSignUp") as? [String : [String:String]] ?? ["":[:]] == ["": [:]]{
            
        }else{
        dict = UserDefaults.standard.value(forKey: "userSignUp") as? [String : [String:String]] ?? ["":[:]]
        }
    }
    @IBAction func btnSignUp(_ sender: UIButton) {
        
        if txtName.text!.isEmpty || txtEmail.text!.isEmpty || txtPassword.text!.isEmpty {
            return
        }
        profile =           ["name":txtName.text!,"email":txtEmail.text!,"password":txtPassword.text!]
        _ = dict.filter {
            if (($0.value)["email"] == txtEmail.text!){
                userID = $0.key
                emailExit = true
            }
            return true
        }
        if emailExit == true{
            print("emailExit")
            emailExit = false
            return
        }
        if UserDefaults.standard.value(forKey: "userSignUp") as? [String : [String:String]] ?? ["":[:]] == ["": [:]]{
            
        }else{
        dict = UserDefaults.standard.value(forKey: "userSignUp") as? [String : [String:String]] ?? ["":[:]]
        }
        dict.updateValue(profile, forKey:"\(ViewController.user_idvalue)")
        print(dict)
        UserDefaults.standard.set(ViewController.user_idvalue, forKey: "user_id")
        
        UserDefaults.standard.set(dict, forKey: "userSignUp")
        let nextVC = self.storyboard?.instantiateViewController(withIdentifier: "ChatViewController") as! ChatViewController
        nextVC.user_idChatMessage = "\(ViewController.user_idvalue)"
        self.navigationController?.pushViewController(nextVC, animated: true)
        ViewController.user_idvalue = ViewController.user_idvalue + 1
        profile.removeAll()
    }
    @IBAction func btnLogin(_ sender: UIButton) {
        _ = dict.filter {
            if (($0.value)["email"] == txtEmail.text!){
                emailExit = true
                userID = $0.key
            }
            return true
        }
    if emailExit == true{
        emailExit = false
    let nextVC = self.storyboard?.instantiateViewController(withIdentifier: "ChatViewController") as! ChatViewController
        nextVC.user_idChatMessage = userID!
    self.navigationController?.pushViewController(nextVC, animated: true)
     }
    }
}

