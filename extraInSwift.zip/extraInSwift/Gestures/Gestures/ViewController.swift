//
//  ViewController.swift
//  Gestures
//
//  Created by mac on 28/04/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var TapGestureRecognizer: UILabel!
    @IBOutlet var PinchGestureRecognizer: UILabel!
    @IBOutlet var RotationGestureRecognizer: UILabel!
    @IBOutlet var SwipGestureRecognizer: UILabel!
    @IBOutlet var PanGestureRecognizer: UILabel!
    @IBOutlet var ScreenEdgeGestureRecognizer: UILabel!
    @IBOutlet var LongPressGestureRecognizer: UILabel!
    @IBOutlet var CustomGestureRecognizer: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.TapGestureRecognizer.isUserInteractionEnabled = true
        self.PinchGestureRecognizer.isUserInteractionEnabled = true
        self.RotationGestureRecognizer.isUserInteractionEnabled = true
        self.SwipGestureRecognizer.isUserInteractionEnabled = true
        self.PanGestureRecognizer.isUserInteractionEnabled = true
        self.ScreenEdgeGestureRecognizer.isUserInteractionEnabled = true
        self.LongPressGestureRecognizer.isUserInteractionEnabled = true
        self.CustomGestureRecognizer.isUserInteractionEnabled = true
        addGestures()
    }
    @IBAction func TapGestureRecognizer(_ sender: UITapGestureRecognizer) {
            print("Tap Gesture Recognizer")
        }
    @IBAction func PinchGestureRecognizer(_ sender: UIPinchGestureRecognizer) {
        print("Pinch Gesture Recognizer")
    }
    @IBAction func RotationGestureRecognizer(_ sender: UIRotationGestureRecognizer) {
        print("Rotation Gesture Recognizer")
    }
    
    @IBAction func SwipGestureRecognizer(_ sender: UISwipeGestureRecognizer) {
        print("Swip Gesture Recognizer")
    }
    
    @IBAction func PanGestureRecognizer(_ sender: UIPanGestureRecognizer) {
        print("Pan Gesture Recognizer")
    }
    
    @IBAction func ScreenEdgeGestureRecognizer(_ sender: UIScreenEdgePanGestureRecognizer) {
        print("Screen Edge Pan Gesture Recognizer")
    }
    
    @IBAction func LongPressGestureRecognizer(_ sender: UILongPressGestureRecognizer) {
        print("Long Press Gesture Recognizer")
    }
    
    @IBAction func CustomGestureRecognizer(_ sender: UIGestureRecognizer) {
        print("Custom Gesture Recognizer")
    }
    
    
    // MARK: Add Gestures to target view
        func addGestures()
        {
            // 1. Single Tap or Touch
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.tapGetstureDetected))
            tapGesture.numberOfTapsRequired = 1
            view.addGestureRecognizer(tapGesture)

            //2. Double Tap
            let doubleTapGesture = UITapGestureRecognizer(target: self, action: #selector(self.doubleTapGestureDetected))
            doubleTapGesture.numberOfTapsRequired = 2
            view.addGestureRecognizer(doubleTapGesture)

            //3. Swipe
            let swipeGesture = UISwipeGestureRecognizer(target: self, action: #selector(self.swipeGetstureDetected))
            view.addGestureRecognizer(swipeGesture)

            //4. Pinch
            let pinchGesture = UIPinchGestureRecognizer(target: self, action: #selector(self.pinchGetstureDetected))
            view.addGestureRecognizer(pinchGesture)

            //5. Long Press
            let longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector(self.longPressGetstureDetected))
            view.addGestureRecognizer(longPressGesture)

            //6. Pan
            let panGesture = UILongPressGestureRecognizer(target: self, action: #selector(self.panGestureDetected))
            view.addGestureRecognizer(panGesture)
            //6. Rotation
            let rotationGesture = UILongPressGestureRecognizer(target: self, action: #selector(self.rotationGestureDetected))
            view.addGestureRecognizer(rotationGesture)

        }

        // MARK: Handle Gesture detection
        @objc func swipeGetstureDetected() {
            print("Swipe Gesture detected!!")
        }

        @objc func tapGetstureDetected() {
            print("Touch/Tap Gesture detected!!")
        }

        @objc func pinchGetstureDetected() {
            print("Pinch Gesture detected!!")
        }

        @objc func longPressGetstureDetected() {
            print("Long Press Gesture detected!!")
        }

        @objc func doubleTapGestureDetected() {
            print("Double Tap Gesture detected!!")
        }

        @objc func panGestureDetected()
        {
            print("Pan Gesture detected!!")
        }
    @objc func rotationGestureDetected(){
        print("Rotation Gesture detected!!")
    }
    override func becomeFirstResponder() -> Bool {
            return true
        }
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?){
        if motion == .motionShake
        {
            print("Shake Gesture Detected")
        }
    }
    //Screenedge Custom view ka pan gesture
}

