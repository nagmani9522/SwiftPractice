//
//  ViewController.swift
//  floatyBtn
//
//  Created by mac on 06/07/22.
//

import UIKit
import Floaty
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let floaty = Floaty()
//        floaty.addItem("Hello, World!", icon: UIImage(named: "icon")!)
        self.view.addSubview(floaty)
    }


}

