//
//  InstructionView.swift
//  iDispatch_User
//
//  Created by mac on 01/04/22.
//  Copyright © 2022 Shubham MacBook Air. All rights reserved.
//

import UIKit
import Popover
protocol TapHandler {
    func tapped()
    func sendButtonTag(myTagBtn: String)
}
 class InstructionView: UIView {
    
    //@IBOutlet weak var popoverView: UIView!
    @IBOutlet weak var progressView: UIProgressView!
    //@IBOutlet weak var nextLblTxt: UILabel!
    @IBOutlet weak var imgIcon: UIImageView!
    @IBOutlet weak var backBtn: UIButton!
     @IBOutlet weak var nextBtn: UIButton!
     @IBOutlet weak var skipBtn: UIButton!
    @IBOutlet weak var lblTittle: UILabel!
    @IBOutlet weak var lblDescription: UILabel!
    @IBOutlet weak var numberNextLbl: UILabel!
     var tapHandler : TapHandler?
     fileprivate var popoverOptions: [PopoverOption] = [
         .type(.auto),
         .blackOverlayColor(UIColor(red: 0, green: 0, blue: 0, alpha: 0.9)),
         .dismissOnBlackOverlayTap(false)
     ]
     override init(frame: CGRect) {
         super.init(frame: frame)
        
     }
     required init?(coder aDecoder:NSCoder) {
         super.init(coder: aDecoder)
     }
     
     func loadViewFromNib() -> UIView {
        
         let bundle = Bundle(for: type(of: self))
         let nib = UINib(nibName: "InstructionView", bundle: bundle)
         let view = nib.instantiate(withOwner: nil, options: nil)[0] as! UIView
         return view
     }
     @IBAction func nextBtnAction(_ sender: UIButton) {
         self.tapHandler?.sendButtonTag(myTagBtn: "NextBtn")
         tapHandler?.tapped()
     }
     @IBAction func backBtnAction(_ sender: UIButton) {
         self.tapHandler?.sendButtonTag(myTagBtn: "backBtn")
         tapHandler?.tapped()
     }
     @IBAction func skipBtnAction(_ sender: UIButton) {
         kdefaults.set(false,forKey: "isLogin")
         self.tapHandler?.sendButtonTag(myTagBtn: "skipBtn")
         tapHandler?.tapped()
     }
 }
