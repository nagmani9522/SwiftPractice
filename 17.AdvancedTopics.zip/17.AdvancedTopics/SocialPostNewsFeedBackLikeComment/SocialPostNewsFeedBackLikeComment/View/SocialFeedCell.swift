//
//  SocialFeedCell.swift
//  SocialPostNewsFeedBackLikeComment
//
//  Created by mac on 10/04/22.
//

import UIKit
import Lightbox
class SocialFeedCell: UITableViewCell {
    @IBOutlet var collectionViewFeed: UICollectionView!
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var btnLike: UIButton!
    @IBOutlet var btnComment: UIButton!
    @IBOutlet var btnShare: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        collectionViewFeed.register(UINib(nibName: "SocialFeedImageCell", bundle: nil), forCellWithReuseIdentifier: "SocialFeedImageCell")
    }
    var ModelSocialFeed: SocialFeedModel?{
        didSet{
           updateData()
        }
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func updateData(){
        lblTitle.text = ModelSocialFeed?.title
        if (ModelSocialFeed?.media.count)! > 0{
            collectionViewFeed.isHidden = false
            collectionViewFeed.dataSource = self
            collectionViewFeed.delegate = self
//            collectionViewFeed.reloadData()
        }else{
            collectionViewFeed.isHidden = true
        }
    }
    func getLightboxImages() -> [LightboxImage]{
       var arrImage = [LightboxImage]()
        for media in ModelSocialFeed!.media{
            if media.mediaType == MediaType.photo{
                arrImage.append(LightboxImage(image: media.thumbnail))
            }else{
            arrImage.append(LightboxImage(image: media.thumbnail, text: "", videoURL: URL(string: media.url)!))
            }
        }
        return arrImage
    }
}
extension SocialFeedCell: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        (ModelSocialFeed?.media.count)!
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionViewFeed.dequeueReusableCell(withReuseIdentifier: "SocialFeedImageCell", for: indexPath) as? SocialFeedImageCell else { return UICollectionViewCell() }
        cell.feedImg.image = ModelSocialFeed?.media[indexPath.row].thumbnail
        return cell
    }
}
extension SocialFeedCell:UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        CGSize(width: collectionViewFeed.bounds.width/3, height: collectionViewFeed.bounds.height)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        0
    }
}
extension SocialFeedCell: UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let controller = LightboxController(images: getLightboxImages(), startIndex: indexPath.row)
        controller.modalPresentationStyle = .fullScreen
        UIApplication.getTopViewController()?.present(controller, animated: true)
    }
}
