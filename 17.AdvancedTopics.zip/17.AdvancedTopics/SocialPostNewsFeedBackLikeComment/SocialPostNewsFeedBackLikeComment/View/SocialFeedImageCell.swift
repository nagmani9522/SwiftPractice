//
//  SocialFeedImageCell.swift
//  SocialPostNewsFeedBackLikeComment
//
//  Created by mac on 09/04/22.
//

import UIKit

class SocialFeedImageCell: UICollectionViewCell {
    @IBOutlet var feedImg: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

}
