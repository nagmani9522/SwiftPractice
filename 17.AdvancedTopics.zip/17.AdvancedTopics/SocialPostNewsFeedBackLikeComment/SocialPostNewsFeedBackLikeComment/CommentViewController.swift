//
//  CommentViewController.swift
//  SocialPostNewsFeedBackLikeComment
//
//  Created by mac on 10/04/22.
//

import UIKit

class CommentViewController: UIViewController {
    
    @IBOutlet var txtComment: UITextField!
    @IBOutlet var tblCommentView: UITableView!
    let modelComment = CommentDataModel.shareInstance
    var modelSocialFeed = SocialFeedModel()
    var arrComments = [CommentModel]()
   // var arrComments = [CommentModel]()
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        arrComments = modelComment.arrComments.filter{ $0.socialFeedId == modelSocialFeed.id }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        txtComment.becomeFirstResponder()
    }
    @IBAction func btnSendTapped(_ sender: UIButton) {
        let modelData = CommentModel(socialFeedId: modelSocialFeed.id, commentID: "\(modelComment.arrComments.count + 1)", title: txtComment.text!)
        modelComment.arrComments.append(modelData)
        arrComments.append(modelData)
        tblCommentView.reloadData()
        txtComment.resignFirstResponder()
    }

}

extension CommentViewController:UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        arrComments.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = arrComments[indexPath.row].title
        return cell
    }
    
}
extension CommentViewController{
    static func shareInstance() -> CommentViewController{
        CommentViewController.instantiateFromStoryboard()
    }
}
