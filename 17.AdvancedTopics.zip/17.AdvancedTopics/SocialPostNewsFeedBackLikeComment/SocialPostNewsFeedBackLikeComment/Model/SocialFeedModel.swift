//
//  SocialFeedModel.swift
//  SocialPostNewsFeedBackLikeComment
//
//  Created by mac on 09/04/22.
//

import UIKit
struct SocialFeedModel {
    var id = ""
    var title = ""
    var media = [MediaModel]()
    var likeStatus = false
}
class SocialFeedDataModel{
    static let shareInstance = SocialFeedDataModel()
    var arrSocialFeed = [SocialFeedModel]()
}
struct MediaModel{
    var mediaType: MediaType?
    var thumbnail = UIImage()
    var url = ""
}
enum MediaType{
    case photo,video
}
struct CommentModel{
    var socialFeedId = ""
    var commentID = ""
    var title = ""
}
class CommentDataModel{
    static let shareInstance = CommentDataModel()
    var arrComments = [CommentModel]()
}
