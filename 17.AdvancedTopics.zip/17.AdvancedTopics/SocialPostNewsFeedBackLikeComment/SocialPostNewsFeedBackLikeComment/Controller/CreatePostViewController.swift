//
//  CreatePostViewController.swift
//  SocialPostNewsFeedBackLikeComment
//
//  Created by mac on 09/04/22.
//

import UIKit
import YPImagePicker
import AVKit
protocol SocialFeedData: class{
    func socialFeedDataParsing()
}
class CreatePostViewController: UIViewController {
    @IBOutlet weak var txtCreatePostView:UITextView!
    @IBOutlet weak var collectionVIew: UICollectionView!
    @IBOutlet weak var  btnPhotoVideo:UIButton!
    var selectedItems = [YPMediaItem]()
    var modelFeedSocial = SocialFeedModel()
    weak var delegate: SocialFeedData?
    var SocialFeedInstance = SocialFeedDataModel.shareInstance
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionVIew.isHidden = true
        collectionVIew.register(UINib(nibName: "SocialFeedImageCell", bundle: nil), forCellWithReuseIdentifier: "SocialFeedImageCell")
    }

    @IBAction func btnPhotoVideoTapped(_ sender: UIButton) {
        showPicker()
    }
    @IBAction func btnDoneTapped(sender: UIBarButtonItem){
        guard let txt = txtCreatePostView.text as? String else { return }
        modelFeedSocial.title = txt
        modelFeedSocial.id = "\(SocialFeedInstance.arrSocialFeed.count + 1)"
        SocialFeedInstance.arrSocialFeed.append(modelFeedSocial)
        delegate?.socialFeedDataParsing()
        print(modelFeedSocial)
        self.navigationController?.popViewController(animated: true)
    }
    
}
// MARK: - YPImagePickerController Configuration
extension CreatePostViewController{
    func showPicker() {

        var config = YPImagePickerConfiguration()
        config.library.mediaType = .photoAndVideo
        config.library.itemOverlayType = .grid
        config.shouldSaveNewPicturesToAlbum = false
        config.video.compression = AVAssetExportPresetPassthrough
        config.startOnScreen = .library
        config.screens = [.library, .photo, .video]
        config.library.minWidthForItem = UIScreen.main.bounds.width * 0.8
        config.video.libraryTimeLimit = 500.0
        config.showsCrop = .rectangle(ratio: (16/9))
        config.wordings.libraryTitle = "Gallery"
        config.hidesStatusBar = false
        config.hidesBottomBar = false
        config.maxCameraZoomFactor = 2.0
        config.library.maxNumberOfItems = 5
        config.gallery.hidesRemoveButton = false
        config.library.preselectedItems = selectedItems
        let picker = YPImagePicker(configuration: config)
        //picker.imagePickerDelegate = self
        picker.didFinishPicking { [weak picker] items, cancelled in
            if cancelled {
                print("Picker was canceled")
                picker?.dismiss(animated: true, completion: nil)
                return
            }
            _ = items.map { print("🧀 \($0)") }

            self.selectedItems = items
            for item in items{
           // if let firstItem = items.first {
                let firstItem = item
                switch firstItem {
                case .photo(let photo):
                    self.modelFeedSocial.media.append(MediaModel(mediaType: .photo, thumbnail: photo.image, url: ""))
                   // self.selectedImageV.image = photo.image
//                    picker?.dismiss(animated: true, completion: nil)
                case .video(let video):
                    //self.selectedImageV.image = video.thumbnail
                    self.modelFeedSocial.media.append(MediaModel(mediaType: .video, thumbnail: video.thumbnail, url: "\(video.url)"))
//                    let assetURL = video.url
//                    let playerVC = AVPlayerViewController()
//                    let player = AVPlayer(playerItem: AVPlayerItem(url:assetURL))
//                    playerVC.player = player

//                    picker?.dismiss(animated: true, completion: { [weak self] in
//
//                        self?.present(playerVC, animated: true, completion: nil)
//                        print("😀 \(String(describing: self?.resolutionForLocalVideo(url: assetURL)!))")
//                    })
                }
                picker?.dismiss(animated: true){
                    self.collectionVIew.isHidden = false
                    self.collectionVIew.reloadData()
                }
           // }
        }
    }
        present(picker, animated: true, completion: nil)
    }
}
extension CreatePostViewController: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        modelFeedSocial.media.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionVIew.dequeueReusableCell(withReuseIdentifier: "SocialFeedImageCell", for: indexPath) as? SocialFeedImageCell else{return UICollectionViewCell()}
        cell.feedImg.image = modelFeedSocial.media[indexPath.row].thumbnail
       return cell
    }
}
extension CreatePostViewController:UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        CGSize(width: collectionVIew.bounds.width/3, height: collectionVIew.bounds.height)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        0
    }
}
extension CreatePostViewController{
    static func shareInstance() -> CreatePostViewController{
        CreatePostViewController.instantiateFromStoryboard()
    }
}
