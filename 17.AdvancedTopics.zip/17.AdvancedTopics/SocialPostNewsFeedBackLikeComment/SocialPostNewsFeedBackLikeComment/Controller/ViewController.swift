//
//  ViewController.swift
//  SocialPostNewsFeedBackLikeComment
//
//  Created by mac on 03/04/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var tblSocialFeedView: UITableView!
   // var arrSocialFeed = [SocialFeedModel]()
    let socialFeedInstance = SocialFeedDataModel.shareInstance
    override func viewDidLoad() {
        super.viewDidLoad()
        tblSocialFeedView.register(UINib(nibName: "SocialFeedCell", bundle: nil), forCellReuseIdentifier: "SocialFeedCell")
       // tblSocialFeedView.delegate = self
    }
    @IBAction func btnAddFeedTapped(_ sender: UIBarButtonItem) {
        let createPost = CreatePostViewController.shareInstance()
        createPost.delegate = self
        self.navigationController?.pushViewController(createPost, animated: true
        )
    }
    @objc func btnLikeTapped(sender:UIButton){
        sender.isSelected = !sender.isSelected
        if sender.isSelected == true{
            socialFeedInstance.arrSocialFeed[sender.tag].likeStatus = true
            }else {
                socialFeedInstance.arrSocialFeed[sender.tag].likeStatus = false

            }
        if sender.isSelected {
            UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut, animations: {
                sender.transform = CGAffineTransform(scaleX: 1.6, y: 1.6)
                // sender.alpha = 0.0
            }) { finished in
                // sender.alpha = 1.0
                UIView.animate(withDuration: 0.3) {
                    sender.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
                    self.tblSocialFeedView.reloadData()
                }
            }
        }
    }
    @objc func btnCommentTapped(sender:UIButton){
        let commentVC = CommentViewController.shareInstance()
        commentVC.modelSocialFeed = socialFeedInstance.arrSocialFeed[sender.tag]
        self.navigationController?.pushViewController(commentVC, animated: true)
    }
}
extension ViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        socialFeedInstance.arrSocialFeed.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tblSocialFeedView.dequeueReusableCell(withIdentifier: "SocialFeedCell", for: indexPath) as? SocialFeedCell else { return UITableViewCell() }
        cell.ModelSocialFeed = socialFeedInstance.arrSocialFeed[indexPath.row]
        cell.btnLike.tag = indexPath.row
        if socialFeedInstance.arrSocialFeed[indexPath.row].likeStatus == true{
            cell.btnLike.setImage(UIImage(named : "SF_suit_heart"), for: UIControl.State.normal)
            }else {
                cell.btnLike.setImage(UIImage(named : "SF_suit_heart_fill"), for: UIControl.State.normal)

            }
        cell.btnLike.addTarget(self, action: #selector(btnLikeTapped(sender:)), for: .touchUpInside)
        cell.ModelSocialFeed = socialFeedInstance.arrSocialFeed[indexPath.row]
        cell.btnComment.tag = indexPath.row
        cell.btnComment.addTarget(self, action: #selector(btnCommentTapped(sender:)), for: .touchUpInside)
        return cell
    }
}
extension ViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if ((socialFeedInstance.arrSocialFeed[indexPath.row].media.count) != 0){
          return 330
        }
      return 100
    }
}

extension ViewController:SocialFeedData{
    func socialFeedDataParsing() {
        tblSocialFeedView.reloadData()
    }
}
