//
//  ViewController.swift
//  TableViewDiffableAndGenericDataSource
//
//  Created by mac on 03/11/21.
//

import UIKit
struct UserModel: Hashable{
    var name = ""
}
class ViewController: UIViewController {
    typealias UserDataSource = UITableViewDiffableDataSource<TblSection, UserModel>
    @IBOutlet weak var tableView: UITableView!
    let searchController = UISearchController(searchResultsController: nil)
    var datasource: UserDataSource!
    var arrData = [UserModel]()
    override func viewDidLoad() {
        super.viewDidLoad()
        addSearchbar()
        configureDatasource()
        arrData = getAllData()
        createSnapshot(users: arrData)
        // Do any additional setup after loading the view.
    }
    func configureDatasource(){
        datasource = UITableViewDiffableDataSource<TblSection,UserModel>(tableView: tableView, cellProvider: {(tableView,indexPath,user) -> UITableViewCell? in
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            cell.textLabel?.text = user.name
            return cell
        })
    }
    func addUser(Name: String){
        //self.arrData.append(UserModel(name: Name))
        self.arrData.append(UserModel(name: Name))
        createSnapshot(users: arrData)
    }
    func createSnapshot(users:[UserModel]){
     var snapshot = NSDiffableDataSourceSnapshot<TblSection,UserModel>()
        snapshot.appendSections([.first])
        snapshot.appendItems(users)
        datasource.apply(snapshot, animatingDifferences: true)
    }
    func getAllData() -> [UserModel]{
       return [
        UserModel(name: "Yogesh"),
        UserModel(name: "mukesh"),
        UserModel(name: "nikhil"),
        UserModel(name: "pratap"),
        UserModel(name: "nagmani"),
        UserModel(name: "Chiraj")
       ]
    }
    func addSearchbar(){
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Search User"
        self.navigationItem.searchController = searchController
        self.definesPresentationContext = true
    }
    
    @IBAction func btnAddClick(_ sender: Any) {
        let alert = UIAlertController(title: "", message: "Add User", preferredStyle: .alert)
        let ok = UIAlertAction(title: "Okey", style: .default){ (okTarget) in
            if let txt = alert.textFields?.first?.text{
                self.addUser(Name: txt)
            }
        }
            alert.addTextField{(txtUser) in
                txtUser.placeholder = "Enter username"
        }
        alert.addAction(ok)
        self.present(alert, animated: true)
    }
}
enum TblSection{
    case first
}
extension ViewController: UISearchResultsUpdating{
    func updateSearchResults(for searchController: UISearchController) {
        let searchText = searchController.searchBar.text
        searchController.searchBar.autocapitalizationType = .none
        if searchText == ""{
            createSnapshot(users: arrData)
        }
        else{
            let updateddata = arrData.filter{
                $0.name.contains(searchText!)
            }
            createSnapshot(users: updateddata)
        }
    }
}
extension ViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //let user = arrData[indexPath.row].self
        let user = datasource.itemIdentifier(for: indexPath)
        print(user!)
        
    }
}
