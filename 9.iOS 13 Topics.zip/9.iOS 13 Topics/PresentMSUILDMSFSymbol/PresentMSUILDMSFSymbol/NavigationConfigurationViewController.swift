//
//  NavigationConfigurationViewController.swift
//  PresentMSUILDMSFSymbol
//
//  Created by mac on 13/02/22.
//

import UIKit

class NavigationConfigurationViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let navigationBarAppearance = UINavigationBarAppearance()
        navigationBarAppearance.configureWithOpaqueBackground()
        navigationBarAppearance.backgroundColor = self.view.tintColor//system color
        navigationBarAppearance.titleTextAttributes = [.foregroundColor: UIColor.white]
        navigationBarAppearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
        self.navigationController?.navigationBar.standardAppearance = navigationBarAppearance
        self.navigationController?.navigationBar.scrollEdgeAppearance = navigationBarAppearance
    }
    @IBAction func btnCancel(_ sender: UIBarButtonItem) {
        self.dismiss(animated: true, completion: nil)
    }
}
extension NavigationConfigurationViewController{   
    static func getNCVC() -> NavigationConfigurationViewController{
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        guard let ncVC = storyboard.instantiateViewController(identifier: "NavigationConfigurationViewController") as? NavigationConfigurationViewController else{
            fatalError("PresentationVC Not Found in Storyboard")
        }
        return ncVC
    }
}
