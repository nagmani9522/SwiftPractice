//
//  ViewController.swift
//  PresentMSUILDMSFSymbol
//
//  Created by mac on 13/02/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var Segmented: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()
        Segmented.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: self.view.tintColor ?? .blue], for: .normal)
        Segmented.setTitleTextAttributes([NSAttributedString.Key.foregroundColor:  UIColor.white], for: .selected)
        Segmented.selectedSegmentTintColor = view.tintColor
        Segmented.backgroundColor = .lightText
    }
    @IBAction func btnSimplePresentation(_ sender: UIButton) {
        let pVC = PresentationViewController.getPVC()
        pVC.modelPresentation = false
        let navVC = UINavigationController(rootViewController: pVC)
        self.present(navVC, animated: true, completion: nil)
    }
    @IBAction func btnPreventDismissPresentation(_ sender: UIButton) {
        let pVC = PresentationViewController.getPVC()
        pVC.modelPresentation = true
        let navVC = UINavigationController(rootViewController: pVC)
        self.present(navVC, animated: true, completion: nil)
    }
    @IBAction func btnFullSheetPresentation(_ sender: UIButton) {
        let pVC = PresentationViewController.getPVC()
        pVC.modelPresentation = false
        let navVC = UINavigationController(rootViewController: pVC)
        navVC.modalPresentationStyle = .fullScreen
        self.present(navVC, animated: true, completion: nil)
    }
    @IBAction func btnNavigationConfiguration(_ sender: UIButton) {
        let ncVC = NavigationConfigurationViewController.getNCVC()
        let navVC = UINavigationController(rootViewController: ncVC)
        navVC.modalPresentationStyle = .fullScreen
        self.present(navVC, animated: true, completion: nil)
    }
    @IBAction func btnSFSymbol(_ sender: UIButton) {
        let sfsVC = SFSymbolViewController.getSFSVC()
        let navVC = UINavigationController(rootViewController: sfsVC)
        self.present(navVC, animated: true, completion: nil)
    }
}

