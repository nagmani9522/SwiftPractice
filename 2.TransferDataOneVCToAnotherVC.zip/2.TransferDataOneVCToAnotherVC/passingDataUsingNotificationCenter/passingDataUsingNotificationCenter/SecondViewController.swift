//
//  SecondViewController.swift
//  passingDataUsingNotificationCenter
//
//  Created by mac on 13/04/22.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewDidDisappear(true)
        NotificationCenter.default.removeObserver(self)
    }
    @IBAction func btnFBClick(_ sender: Any) {
        NotificationCenter.default.post(name: .facebook, object: nil)
    }
    
    @IBAction func btnTwitterClick(_ sender: UIButton) {
        NotificationCenter.default.post(name: .Twitter, object: nil)
    }
    
}
