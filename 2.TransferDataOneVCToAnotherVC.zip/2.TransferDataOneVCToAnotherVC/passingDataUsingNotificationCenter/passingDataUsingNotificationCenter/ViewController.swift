//
//  ViewController.swift
//  passingDataUsingNotificationCenter
//
//  Created by mac on 13/04/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var lbl: UILabel!
    @IBOutlet var img: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(facebook(notification:)), name: .facebook, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(twitter(notification:)), name: .Twitter, object: nil)
    }
    @IBAction func btnSelectClick(_ sender: UIButton) {
        let nextVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    @objc func facebook(notification:Notification){
        lbl.text = "Facebook"
        img.image = #imageLiteral(resourceName: "fbMessenger")
    }
    @objc func twitter(notification:Notification){
        lbl.text = "Twitter"
        img.image = #imageLiteral(resourceName: "twitter")
    }
}
extension Notification.Name{
    static let facebook = Notification.Name("Facebook")
    static let Twitter = Notification.Name("Twitter")
}
