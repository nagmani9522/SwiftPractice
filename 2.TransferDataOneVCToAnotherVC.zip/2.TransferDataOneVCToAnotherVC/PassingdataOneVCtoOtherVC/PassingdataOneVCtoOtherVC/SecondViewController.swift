//
//  SecondViewController.swift
//  PassingdataOneVCtoOtherVC
//
//  Created by mac on 12/04/22.
//

import UIKit

class SecondViewController: UIViewController {
    @IBOutlet var lblName: UILabel!
    @IBOutlet var lblEmail: UILabel!
    var strname = ""
    var strEmail = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        lblName.text = strname
        lblEmail.text = strEmail
    }

}
