//
//  ViewController.swift
//  PassingdataOneVCtoOtherVC
//
//  Created by mac on 12/04/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var txtName: UITextField!
    @IBOutlet var txtEmail: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func Continue(_ sender: UIButton) {
        let nextVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController

        nextVC.strname = txtName.text ?? ""
        nextVC.strEmail = txtEmail.text ?? ""
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    
}

