//
//  ThirdViewController.swift
//  NavigateOneVCToOtherVCButtonSegueStorybod
//
//  Created by mac on 19/01/22.
//

import UIKit

class ThirdViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewWillDisappear(_ animated: Bool) {
      print(self.navigationController!.viewControllers)
    }
    
    @IBAction func btndetailVCClick(_ sender: Any) {
        for controller in self.navigationController!.viewControllers as Array {
//                if controller.isKind(of: ThirdViewController.self) {
//                    self.navigationController!.popToViewController(controller, animated: true)
//                    break
//                }
            print(controller)
            if controller.isKind(of: DetailViewController.self) {
                self.navigationController!.popToViewController(controller, animated: true)
                break
            }
        }
//        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnHomeVC(_ sender: UIButton) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    @IBAction func fourVcAction(_ sender: UIButton) {
        
        let fourVC = self.storyboard?.instantiateViewController(withIdentifier: "FourViewController") as! FourViewController
        self.navigationController?.pushViewController(fourVC, animated: true)
    }
    
}
