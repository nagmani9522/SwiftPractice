//
//  ViewController.swift
//  dataPassUsingClosureTwoVC
//
//  Created by mac on 15/04/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var lblName: UILabel!
    @IBOutlet var lblPassword: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    @IBAction func btnHomeClick(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        vc.completion = { dict in
            self.lblName.text = dict["name"] as? String
            self.lblPassword.text = dict["password"] as? String
        }
        vc.comp = { dicp in
            print(dicp["name"]!)
            
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

