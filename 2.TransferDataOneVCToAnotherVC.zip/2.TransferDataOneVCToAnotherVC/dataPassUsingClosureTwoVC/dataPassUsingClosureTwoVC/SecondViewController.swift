//
//  SecondViewController.swift
//  dataPassUsingClosureTwoVC
//
//  Created by mac on 15/04/22.
//

import UIKit

class SecondViewController: UIViewController {
    typealias completionHandler = ([String:Any]) -> Void
    @IBOutlet var txtName: UITextField!
    @IBOutlet var txtPassword: UITextField!
    var completion: completionHandler?
    var comp: (([String:Any]) -> Void)?
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    @IBAction func btnSaveclick(_ sender: UIButton) {
        guard let name = txtName.text else {return}
        guard let password = txtPassword.text else {return}
        let dict = ["name":name,"password":password]
        guard let completionBlock = completion else{return}
        completionBlock(dict)
        let compBlock = comp
        compBlock!(dict)
        self.navigationController?.popViewController(animated: true)
    }
    
}
