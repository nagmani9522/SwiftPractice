//
//  ViewController.swift
//  ProtocolAndDelegate
//
//  Created by mac on 13/04/22.
//

import UIKit

class ViewController: UIViewController,DataPass {
    
    @IBOutlet var lblName: UILabel!
    @IBOutlet var lblAddress: UILabel!    
    @IBOutlet var lblCity: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }

    @IBAction func GoForm(_ sender: UIButton) {
        let secondVC = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
        secondVC.delegate = self
        self.navigationController?.pushViewController(secondVC, animated: true)
    }
//    func dataPassing(name: String, address: String, city: String) {
//        lblName.text = name
//        lblAddress.text = address
//        lblCity.text = city
//    }
    func data(object: [String : String]) {
        lblName.text = object["name"]
        lblAddress.text = object["address"]
        lblCity.text = object["city"]
    }
    
}

