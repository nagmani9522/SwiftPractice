//
//  SecondViewController.swift
//  ProtocolAndDelegate
//
//  Created by mac on 14/04/22.
//

import UIKit
protocol DataPass{
//func dataPassing(name:String,address:String,city:String)
    func data(object:[String:String])
}
class SecondViewController: UIViewController {

    @IBOutlet var txtName: UITextField!
    @IBOutlet var txtAddress: UITextField!
    @IBOutlet var txtCity: UITextField!
    var delegate:DataPass?
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func saveAction(_ sender: UIButton) {
        if txtName.text == ""{
            alert(titles: "Enter Name", msg: "")
        }else if txtAddress.text! .isEmpty {
            alert(titles: "Enter Address", msg: "")
        }else if txtCity.text!.isEmpty{
            alert(titles: "Enter City", msg: "")
        }else{
//        delegate?.dataPassing(name: txtName.text ?? "", address: txtAddress.text ?? "", city: txtCity.text ?? "")
            let dict:[String:String] = ["name":txtName.text!,"address":txtAddress.text!,"city":txtCity.text!]
            delegate?.data(object: dict)
        }
    }
    func alert(titles:String,msg:String){
        let alert = UIAlertController(title: titles, message: msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }

}
