//
//  ViewController.swift
//  GoogleLoginSignInIntegeration
//
//  Created by mac on 15/03/22.
//

import UIKit
import GoogleSignIn
class ViewController: UIViewController {
    @IBOutlet var googlesLoginBtn: UIButton!
    let signInConfig = GIDConfiguration.init(clientID: "811397942196-i188fh8nbp9pcnn5cc8sbcvbime18lqa.apps.googleusercontent.com")
    var googleSignIn = GIDSignIn.sharedInstance
//    var googleId = ""
//    var googleIdToken = ""
//    var googleFirstName = ""
//    var googleLastName = ""
//    var googleEmail = ""
//    var googleProfileURL = ""
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func googleLoginAction(_ sender: UIButton) {
        self.googleAuthLogin()
    }
//    func googleAuthLogin(){
//        let googleConfig = GIDConfiguration(clientID: "811397942196-i188fh8nbp9pcnn5cc8sbcvbime18lqa.apps.googleusercontent.com")
//        self.googleSignIn.signIn(with: googleConfig, presenting: self) { user, error in
//            if error == nil {
//                guard let user = user else {
//                    print("Uh oh. The user cancelled the Google login.")
//                    return
//                }
//                let userId = user.userID ?? ""
//                print("Google User ID: \(userId)")
//                self.googleId = userId
//
//                let userIdToken = user.authentication.idToken ?? ""
//                print("Google ID Token: \(userIdToken)")
//                self.googleIdToken = userIdToken
//
//                let userFirstName = user.profile?.givenName ?? ""
//                print("Google User First Name: \(userFirstName)")
//                self.googleFirstName = userFirstName
//
//                let userLastName = user.profile?.familyName ?? ""
//                print("Google User Last Name: \(userLastName)")
//                self.googleLastName = userLastName
//
//                let userEmail = user.profile?.email ?? ""
//                print("Google User Email: \(userEmail)")
//                self.googleEmail = userEmail
//
//                let googleProfilePicURL = user.profile?.imageURL(withDimension: 150)?.absoluteString ?? ""
//                print("Google Profile Avatar URL: \(googleProfilePicURL)")
//                self.googleProfileURL = googleProfilePicURL
//
//                self.performSegue(withIdentifier: "detailseg", sender: self)
//            }
//        }
//    }
//
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if segue.identifier == "detailseg" {
//            let DestView = segue.destination as! DetailsViewController
//            DestView.googleId = self.googleId
//            DestView.googleIDToken = self.googleIdToken
//            DestView.googleFirstName = self.googleFirstName
//            DestView.googleLastName = self.googleLastName
//            DestView.googleEmail = self.googleEmail
//            DestView.googleProfilePicURL = self.googleProfileURL
//        }
//    }
    func googleAuthLogin() {
        let googleConfig = GIDConfiguration(clientID: "811397942196-i188fh8nbp9pcnn5cc8sbcvbime18lqa.apps.googleusercontent.com")
        self.googleSignIn.signIn(with: googleConfig, presenting: self) { user, error in
            if error == nil {
                guard let user = user else {
                    print("Uh oh. The user cancelled the Google login.")
                    return
                }

                let userId = user.userID ?? ""
                print("Google User ID: \(userId)")

                let userIdToken = user.authentication.idToken ?? ""
                print("Google ID Token: \(userIdToken)")

                let userFirstName = user.profile?.givenName ?? ""
                print("Google User First Name: \(userFirstName)")

                let userLastName = user.profile?.familyName ?? ""
                print("Google User Last Name: \(userLastName)")

                let userEmail = user.profile?.email ?? ""
                print("Google User Email: \(userEmail)")

                let googleProfilePicURL = user.profile?.imageURL(withDimension: 150)?.absoluteString ?? ""
                print("Google Profile Avatar URL: \(googleProfilePicURL)")

            }
        }
    }

}

