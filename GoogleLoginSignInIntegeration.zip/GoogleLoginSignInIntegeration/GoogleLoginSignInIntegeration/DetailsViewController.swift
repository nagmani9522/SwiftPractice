//
//  DetailsViewController.swift
//  GoogleLoginSignInIntegeration
//
//  Created by mac on 16/03/22.
//

import UIKit

class DetailsViewController: UIViewController {

    var googleId = ""
    var googleFirstName = ""
    var googleLastName = ""
    var googleEmail = ""
    var googleProfilePicURL = ""
    var googleIDToken = ""

    override func viewDidLoad() {
        super.viewDidLoad()
//        googleIdLabel.text = googleId
//        googleFirstNameLabel.text = googleFirstName
//        googleLastNameLabel.text = googleLastName
//        googleEmailLabel.text = googleEmail
//        googleProfilePicUrlLabel.text = googleProfilePicURL
//        googleIDTokenLabel.text = googleIDToken
    }
}
